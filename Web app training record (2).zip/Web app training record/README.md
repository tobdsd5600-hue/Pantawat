# Training Record Web App — Ciena / Celestica (Phase 1 MVP)

ระบบบันทึก/ติดตามการเทรนพนักงาน (Fiber Optic Splice) เปลี่ยนจากการส่งไฟล์ Excel เป็น Web App แบบ Ticketing
สร้างด้วย **Google Apps Script + Google Sheets** (แต่ละแท็บของ Sheet = 1 ตารางในฐานข้อมูล), หน้าเว็บเป็น HtmlService SPA

> 📌 ข้อความใน UI / error เป็น **ภาษาอังกฤษ** (เวอร์ชันโค้ดปัจจุบัน) — เอกสารนี้เป็นภาษาไทย

---

## ✨ ฟีเจอร์ (Phase 1)

- 🔐 **4 Roles** — STAFF / SUPERVISOR (ไม่ใช้ PIN) / TRAINER / ADMIN (ใช้ PIN)
  - **ผู้ใช้ทั่วไปที่ยังไม่มีข้อมูลในระบบ** ล็อกอินด้วย EN เข้าได้เลยในฐานะ STAFF (เปิด Ticket เพื่อลงทะเบียนตัวเองได้)
  - **STAFF เข้าถึงได้เหมือน SUPERVISOR** (เห็น Skill Matrix) — สิทธิ์ "แก้ไข/บันทึกผล" สงวนให้ TRAINER/ADMIN (admin มอบหมายเอง)
- 🗂️ **Skill Matrix** — ตาราง พนักงาน × 5 คอร์ส แสดงสีสถานะ (วันหมดอายุแบบ `01 Jun 2026`) พร้อมกรองตามหน้างาน + **ค้นหา EN / ชื่อ / ชื่อเล่น** (กรองทันทีฝั่ง browser)
  - ✏️ **TRAINER/ADMIN แก้ไขในตารางได้เลย** — คลิกที่เซลล์เพื่อแก้ผล (สถานะ/Training Date/Qualified/Expiry/Score) หรือคลิก ✎ ข้าง EN เพื่อแก้ข้อมูลพนักงาน (ชื่อ/ชื่อเล่น/หน้างาน/หัวหน้า)
- 🎫 **Ticketing** — เปิดคำขอเทรน (เพิ่มพนักงานใหม่เข้าระบบอัตโนมัติถ้ายังไม่มี), จัดคิว, มอบหมายเทรนเนอร์, ปิดงานพร้อมบันทึกผล
  - **เปิด Ticket ได้เฉพาะ 4 คอร์ส HFO** (ตัด `BASIC` ออก — เป็น prerequisite ติดตามแยก) คุมจาก `NON_TICKET_COURSES`
  - 🔁 **เปิด Ticket ที่ COMPLETED แล้วซ้ำได้** (แก้ไขผล) — หน้า Manage จะดึง Training Date / Qualified Date / Score / Result จาก record ปัจจุบันมาเติมให้อัตโนมัติ
  - 📥 **Bulk Import** — ดาวน์โหลด Template **xlsx ที่มี dropdown CourseID จริง** (server สร้างผ่าน Drive) + อัปโหลด CSV/Excel เปิดคำขอทีละหลายคน (สูงสุด **200 แถว/ครั้ง**) + หน้า **preview ตรวจก่อนนำเข้า** (แถวที่ทุกแถว error ปุ่มจะเป็น "Close" ปิด modal ทันทีโดยไม่แสดง error)
  - 📋 **CourseID Reference sheet** ใน template แสดงเฉพาะ **4 คอร์ส HFO** ที่เปิด Ticket ได้ (ไม่มี `BASIC`) — กันผู้ใช้ copy CourseID ที่ import ไม่ได้
  - 🔧 **Parse ไฟล์ฝั่ง server** (`.csv` = `Utilities.parseCsv`, `.xlsx` = แปลงผ่าน Drive REST) → **ไม่พึ่ง CDN/SheetJS** ใช้ได้แม้เน็ตบริษัทบล็อก CDN
- 📊 **Dashboard** — KPI สรุป real-time + กราฟ 3 ตัว (Google Charts):
  - **เส้นแนวโน้ม (area)** จำนวนใบเซอร์ active ย้อนหลัง เลือกช่วง 1/3/6/12 เดือน
  - **โดนัท** สัดส่วนสถานะใบเซอร์ปัจจุบัน
  - **แท่ง stacked แยกตามคอร์ส** (Qualified / Near Expiry / Expired / In Training / Not Trained — รวมเท่าจำนวนคนเสมอ)
- 👥 **จัดการผู้ใช้** (ADMIN) — สร้าง/แก้บัญชี trainer/หัวหน้า/admin ผ่านเว็บ ไม่ต้องเปิด Sheet
- 📧 **Email Notifications** — ส่งจากบัญชีที่ deploy, ตั้งชื่อผู้ส่ง+Reply-To = คนทำรายการ:
  - **Event-driven (ทันที):** เปิด Ticket → TRAINER+ADMIN · นัดวัน (SCHEDULED) → พนักงาน+หัวหน้า · ปิดงานมีผล (COMPLETED) → พนักงาน+หัวหน้า · Bulk import → สรุป+ตารางรายการ
  - **รายงวด (trigger):** Cert ใกล้หมด/หมดอายุ ทุกวัน 07:00 + **สรุปรายสัปดาห์** (จันทร์ ~07:30) ให้ ADMIN (ทั้งระบบ) + หัวหน้า (เฉพาะทีม)
  - ทุกฉบับผ่าน `sendMailSafe_` (try/catch — อีเมลล้มเหลวไม่ทำให้ flow หลักพัง) + `esc_` กัน HTML แตก
- 🧾 **Auto Record** — ปิด Ticket พร้อมผล → อัปเดต Skill Matrix + คำนวณวันหมดอายุอัตโนมัติ
- 🗄️ **เปลี่ยน DB Sheet ได้** — ตั้ง `APP.SPREADSHEET_ID` (ว่าง = Sheet ที่ผูกอยู่ / ใส่ ID = ชี้ Sheet อื่น)

---

## 📚 คอร์ส (5 คอร์ส, อายุใบเซอร์ 12 เดือน)

| ลำดับ | CourseID | ชื่อแสดงผล | หมายเหตุ |
|---|---|---|---|
| 1 | `BASIC` | Basic Fiber Optic | **prerequisite** — ต้องผ่านก่อน, **ไม่เปิดผ่าน Ticket** (ติดตามแยก) |
| 2 | `HFO144-NEW` | "New" HFO_144 (CP20433) Ribbon | คอร์สใหม่ (Hands-on) |
| 3 | `HFO145-NEW` | "New" HFO_145 (CP43997) SM, PM | คอร์สใหม่ (Hands-on) |
| 4 | `HFO144-REF` | REFRESHER HFO_144 (CP20433) | ทบทวน |
| 5 | `HFO145-REF` | REFRESHER HFO_145 (CP43997) | ทบทวน |

> **BASIC:** ในไฟล์ Excel คอลัมน์ "Basic FIBER OPTIC Training" = **วันหมดอายุ Basic** (วันที่ต้องไป refresh) ไม่ใช่วันที่ผ่าน
> ระบบจึงใช้ค่านั้นเป็น **ExpiryDate** โดยตรง และประมาณ QualifiedDate = หมดอายุ − 12 เดือน
> → คนที่ Basic หมดอายุแล้วจะขึ้น 🔴 แดง (ต้อง refresh ก่อนเทรน splice ต่อ)

### สีใน Skill Matrix
🟢 **Qualified** · 🟡 **ใกล้หมดอายุ** (≤30 วัน) · 🔴 **หมดอายุ / ไม่ผ่าน** · 🔵 **กำลังเทรน** · ⚪ **ยังไม่เทรน**

---

## 📁 โครงสร้างไฟล์ (`apps-script/`)

| ไฟล์ | หน้าที่ |
|---|---|
| `Code.gs` | โค้ดฝั่ง server ทั้งหมดในไฟล์เดียว — Config, Lib, Setup, Auth, Records, Tickets, SkillMatrix, Dashboard, Api, WebApp(`doGet`), Alerts, SeedData (**ข้อมูลจริง 90 พนักงาน / 195 records** = HFO 106 + BASIC 89) |
| `Index.html` / `Styles.html` / `JavaScript.html` | หน้าเว็บ SPA (รวมผ่าน `<?!= include() ?>`) |
| `appsscript.json` | manifest + ตั้งค่า Web App |
| `.clasp.json` / `.claspignore` | ตั้งค่า clasp (ไม่ต้องเอาไปวางใน Apps Script) |

> `tools/generate_seed.py` ใช้สร้าง seed จากไฟล์ Excel ใหม่ — รัน `python tools/generate_seed.py` แล้ว splice ส่วน `SEED_EMPLOYEES`/`SEED_RECORDS` เข้า `Code.gs`

---

## 🚀 วิธี Deploy (clasp — แนะนำ)

```powershell
clasp login                       # ครั้งแรกครั้งเดียว
cd "apps-script"
clasp push -f                     # อัปโหลดโค้ดขึ้น Apps Script
```
จากนั้นใน Apps Script editor:

0. (ถ้าจะใช้ Sheet อื่นเป็น DB) ตั้ง `APP.SPREADSHEET_ID` = ID ของ Sheet นั้น (บัญชีที่รันต้องมีสิทธิ์ edit) — เว้นว่าง = ใช้ Sheet ที่ผูกกับโปรเจกต์
1. รัน **`initWithData`** ครั้งเดียว → สร้างชีตทั้งหมด + 5 คอร์ส + admin (`admin`/PIN `1234`) + หัวหน้างาน 8 คน **และเขียนข้อมูลจริง 90 พนักงาน / 195 records** (รันซ้ำได้ — ใช้ clearContent ไม่ลบแถว)
2. รัน **`installDailyAlertTrigger`** + **`installWeeklySummaryTrigger`** → เปิดอีเมลแจ้งเตือน
3. **Deploy ▸ New deployment ▸ Web app** → ได้ URL (`/exec`)
   - ระหว่างพัฒนาใช้ **Test deployment (`/dev`)** จะเห็นโค้ดล่าสุดทันทีหลัง `clasp push`
   - ⚠️ ครั้งแรกที่ใช้ Bulk import/Template จะขอ authorize **Drive + UrlFetch** เพิ่ม

> วางมือ (ไม่ใช้ clasp): สร้าง Google Sheet เปล่า ▸ Extensions ▸ Apps Script → ก๊อปเนื้อหา `Code.gs` + HTML 3 ไฟล์ (ชื่อ `Index`/`Styles`/`JavaScript`) → ทำขั้นตอน 1–3

### 🛡️ ความปลอดภัยตอน import (กันลบข้อมูลจริง)
ถ้ามี **Ticket อยู่แล้ว** (ระบบใช้งานจริง) → `initWithData()` / `importSeedData()` จะ **ข้ามการ import** เพื่อไม่ลบข้อมูลพนักงาน/records ทิ้ง
→ ถ้าต้องการเขียนทับจริง ให้รัน **`initWithData(true)`** หรือ **`importSeedData(true)`**

---

## 👤 บทบาท / การล็อกอิน

หน้า login แยก 2 แท็บ: **ผู้ใช้ทั่วไป** (EN อย่างเดียว) / **Trainer / Admin** (EN + PIN)

| Role | PIN | ต้องมีใน `Users`? | เข้าถึงอะไร |
|---|---|---|---|
| **STAFF** | ❌ | ❌ (EN อะไรก็เข้าได้) | Dashboard, **Skill Matrix (เห็นทั้งหมด, ดูอย่างเดียว — แก้ไม่ได้)**, Tickets (ของตัวเอง), ผลการเทรนของฉัน |
| **SUPERVISOR** | ❌ | ✅ | เหมือน STAFF แต่ Skill Matrix/Tickets เห็นเฉพาะ **ทีมตัวเอง** + รับอีเมลแจ้งเตือนทีม |
| **TRAINER** | ✅ | ✅ | + **จัดการ Ticket / บันทึกผลเทรน** |
| **ADMIN** | ✅ | ✅ | ทุกอย่าง + **จัดการผู้ใช้** + รัน setup/import |

- บัญชี **admin** เริ่มต้น: EN `admin` / PIN `1234` (เปลี่ยน PIN ได้ในชีต `Users` หรือหน้าจัดการผู้ใช้)
- **หัวหน้างานเริ่มต้น 8 คน** (จากคอลัมน์ Sup): `fang` ฟาง, `pu` ปู, `moo` หมู, `lek` เล็ก, `tuk` ตุ๊ก, `nong` นง, `aoy` อ้อย, `tak` พี่ตั๊ก — Role SUPERVISOR, ล็อกอินด้วย EN อย่างเดียว
  - `Users.Name` ตั้งให้ตรงชื่อเล่นในคอลัมน์ `Supervisor` ของ Employees เพื่อให้ผูกทีม + อีเมลถูกคน
  - อยากให้หัวหน้าคนใดบันทึกผลได้ → เปลี่ยน Role เป็น `TRAINER` + ตั้ง PIN (ผ่านหน้า "จัดการผู้ใช้" หรือชีต `Users`)

---

## 🛠️ ฟังก์ชันที่รันจาก Apps Script editor (เมนู Run)

| ฟังก์ชัน | ทำอะไร |
|---|---|
| `initWithData()` / `initWithData(true)` | setup + เขียนข้อมูลจริงลง DB (`true` = ยืนยันเขียนทับเมื่อมี Ticket แล้ว) |
| `importSeedData()` / `importSeedData(true)` | เขียนเฉพาะ Employees + TrainingRecords + คอร์ส |
| `setupDatabase()` | สร้างชีต + คอร์ส + admin + หัวหน้างาน (ไม่เขียนข้อมูลพนักงาน) |
| `resyncCourses()` | อัปเดตชีต `Courses` ให้ตรง 5 คอร์สปัจจุบัน (กันคอร์สเก่าค้าง) |
| `seedSupervisors()` | เพิ่มบัญชีหัวหน้างานเริ่มต้น (idempotent) |
| `installDailyAlertTrigger()` | เปิดอีเมลแจ้งเตือน Cert ใกล้หมดอายุ รายวัน 07:00 |
| `installWeeklySummaryTrigger()` | เปิดอีเมลสรุปรายสัปดาห์ (จันทร์ ~07:30) |
| `importBasicRecords()` | เติมเฉพาะ BASIC records แบบ additive (ไม่ลบของเดิม, รันซ้ำได้) |

> `apiBootstrap` (ตอน login) เรียก `ensureCourses_()` อัตโนมัติ — ถ้าชีต `Courses` ไม่ตรง 5 คอร์ส จะ resync ให้เอง
> Bulk import (xlsx) + Template ต้องการ scope **Drive + UrlFetch** → ครั้งแรกต้อง authorize เพิ่ม (รันฟังก์ชันใดก็ได้ใน editor 1 ครั้ง)

---

## 🔒 ความปลอดภัย / ข้อควรรู้

- ✅ **`withLock_`** ครอบทุก API ที่เขียนข้อมูล (เปิด/แก้ Ticket, บันทึกผล, จัดการผู้ใช้) — กัน ID ชนเมื่อทำพร้อมกัน
- ✅ **STAFF ดูข้อมูลพนักงานได้เฉพาะ EN ตัวเอง** (`apiFindEmployee`) — กันสุ่ม EN ดูคนอื่น
- ✅ Skill Matrix / จัดการผู้ใช้ จำกัดสิทธิ์ตาม role; การ "แก้ไข" ต้องเป็น TRAINER/ADMIN (มี PIN)
- ✅ Bulk import จำกัด 200 แถว/ครั้ง (กัน timeout) + มี preview ตรวจก่อนเขียนจริง
- ⚠️ **PIN เก็บแบบ plaintext** ในชีต `Users` — เหมาะกับ internal tool (ชีตควบคุมสิทธิ์เข้าถึงอยู่แล้ว) ถ้าต้องการ hash ทำเพิ่มได้
- ⚠️ **Web App access = ANYONE_ANONYMOUS** — ใครมี URL + พิมพ์ EN ก็เข้าเป็น STAFF ได้ (เห็นภาพรวม view-only) ถ้าอยากจำกัดเฉพาะโดเมน Celestica → ตอน Deploy เลือก "Who has access: [โดเมน]"
- ✅ หน้า login **ไม่โชว์รหัส admin/PIN** แล้ว (กันพนักงานสับสน) — admin/`1234` ยังใช้ได้ แต่ควรเปลี่ยน PIN ก่อนใช้งานจริง

---

## ⚙️ หมายเหตุการปรับแต่ง

- อายุใบเซอร์ตั้งต่อคอร์สได้ที่ชีต `Courses` คอลัมน์ `ValidityMonths` (ปัจจุบันทุกคอร์ส = **12 เดือน**)
- เกณฑ์ "ใกล้หมดอายุ" (สีเหลือง) = `APP.NEAR_EXPIRY_DAYS` ใน Config (ดีฟอลต์ **30 วัน**)
- ข้อมูลต้นทางมี typo: บางคน Supervisor เป็น `ปูู`/`อ้้อย` (สระซ้ำ) จะไม่ match `ปู`/`อ้อย` — แก้ในชีต `Employees` ถ้าต้องการให้อีเมลแจ้งเตือนทีมครบ
- เอกสารแนะนำเลี่ยง LINE Notify (จะปิดบริการ) — ระบบใช้ Email ก่อน, ต่อยอด LINE Messaging API ได้ใน Phase ถัดไป
- **ศัพท์ UI:** ฟิลด์วันเริ่มเทรนใช้คำว่า **"Training Date"** เหมือนกันทุกหน้า · สถานะ `IN_PROGRESS` แสดง **"In Training"** สำหรับ record แต่แสดง **"In Progress"** สำหรับ Ticket (ฟังก์ชัน `ticketStatusText`)
- **Manage COMPLETED Ticket:** เมื่อเปิดหน้า Manage ticket ที่ปิดงานไปแล้ว ฟอร์มผลการเทรนจะโหลดข้อมูลล่าสุดจากชีต `TrainingRecords` มาเติมให้ทุกครั้ง — บันทึกซ้ำ = แก้ไขผลใน Skill Matrix (ใช้ได้กรณีแก้วันที่/คะแนนผิด)

---

## 🗺️ Roadmap ที่ยังไม่ทำ (Phase 2+)
QR e-Certificate · Booking calendar (จองคิวเทรน) · Export รายงาน PDF/Excel · Audit trail UI · Digital signature ตอนปิด Ticket · Hash PIN · จำกัด access ตามโดเมน

---

## 👨‍💻 Developer

| | |
| --- | --- |
| **Developer** | Pantawat Tantem |
| **Department** | OE Center |

> Footer credit แสดงที่ขอบล่างขวาของหน้าเว็บหลัง login ทุกหน้า
