# -*- coding: utf-8 -*-
"""
อ่านไฟล์ Excel ต้นฉบับ -> สร้างไฟล์ Apps Script `11_SeedData.gs`
ที่ฝังข้อมูล Employees + TrainingRecords ไว้พร้อม importSeedData()
รันครั้งเดียว: python tools/generate_seed.py
"""
import openpyxl, json, datetime, os

SRC = 'Copy of Target Plan to Support Ciena 2026.xlsx'
SHEET = 'Complete Name lis_2026'
OUT = os.path.join('apps-script', '11_SeedData.gs')
VALIDITY_MONTHS = 12
DATA_START_ROW = 4  # แถวข้อมูลแรก (1, 2-3 เป็น header)

# course -> list ของคู่คอลัมน์ (overview_idx, qualified_idx)
# โครงสร้างใหม่: แยก New (Hands-on) และ REFRESHER ของ HFO_144 / HFO_145
COURSE_COLS = {
    'HFO144-NEW': [(11, 12)],   # HFO-144 Hands-on Ribbonize
    'HFO145-NEW': [(17, 18)],   # HFO-145 Hands-on Single & PM
    'HFO144-REF': [(14, 15)],   # HFO-144 Refresher Ribbon
    'HFO145-REF': [(25, 26)],   # HFO-145 Refresher Single
}

def iso(d):
    if isinstance(d, datetime.datetime):
        return d.strftime('%Y-%m-%d')
    if isinstance(d, datetime.date):
        return d.strftime('%Y-%m-%d')
    return ''

def add_months(d, m):
    y = d.year + (d.month - 1 + m) // 12
    mo = (d.month - 1 + m) % 12 + 1
    day = min(d.day, [31,29 if y%4==0 and (y%100!=0 or y%400==0) else 28,31,30,31,30,31,31,30,31,30,31][mo-1])
    return datetime.date(y, mo, day)

def clean(v):
    if v is None:
        return ''
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()

wb = openpyxl.load_workbook(SRC, data_only=True)
ws = wb[SHEET]

from collections import OrderedDict

# จัดกลุ่มทุกแถวตาม EN (พนักงานคนเดียวอาจมีหลายแถว = คนละคอร์ส)
rows_by_en = OrderedDict()
for row in ws.iter_rows(min_row=DATA_START_ROW, values_only=True):
    en = clean(row[5])
    if not en:
        continue
    rows_by_en.setdefault(en, []).append(row)

def first_nonempty(rows, idx):
    for r in rows:
        v = clean(r[idx])
        if v:
            return v
    return ''

employees = []   # [EN,NameEN,NameTH,Nickname,WorkingArea,Supervisor,SplicingExp,Email,Active]
records = []     # [RecordID,EN,CourseID,OverviewDate,QualifiedDate,ExpiryDate,Status,Score,Trainer,UpdatedBy,UpdatedAt]
rec_no = 0

for en, rows in rows_by_en.items():
    # ข้อมูลพนักงาน: เอาค่าที่ไม่ว่างตัวแรกจากทุกแถวของ EN นี้
    employees.append([
        en, first_nonempty(rows, 6), first_nonempty(rows, 7), first_nonempty(rows, 8),
        first_nonempty(rows, 9), first_nonempty(rows, 28), first_nonempty(rows, 29), '', True,
    ])

    # รวมวันที่ของแต่ละคอร์สจาก "ทุกแถว" ของพนักงานคนนี้
    for course, pairs in COURSE_COLS.items():
        overviews, qualifieds = [], []
        for row in rows:
            for ov_i, q_i in pairs:
                if ov_i is not None and isinstance(row[ov_i], (datetime.date, datetime.datetime)):
                    overviews.append(row[ov_i])
                if q_i is not None and isinstance(row[q_i], (datetime.date, datetime.datetime)):
                    qualifieds.append(row[q_i])
        ov = min([o.date() if isinstance(o, datetime.datetime) else o for o in overviews], default=None)
        ql = max([q.date() if isinstance(q, datetime.datetime) else q for q in qualifieds], default=None)
        if not ov and not ql:
            continue  # ไม่มีข้อมูลคอร์สนี้ -> ปล่อยเป็น GRAY ใน matrix
        rec_no += 1
        rid = 'RC-%06d' % rec_no
        if ql:
            status = 'QUALIFIED'
            exp = iso(add_months(ql, VALIDITY_MONTHS))
            ql_s = iso(ql)
        else:
            status = 'IN_PROGRESS'
            exp = ''
            ql_s = ''
        records.append([rid, en, course, iso(ov) if ov else '', ql_s, exp,
                        status, '', '', 'import', ''])

    # BASIC (prerequisite): col10 = วันหมดอายุ -> Qualified ประมาณ = หมดอายุ - 12 เดือน
    basic_dates = []
    for row in rows:
        v = row[10]
        if isinstance(v, (datetime.date, datetime.datetime)):
            basic_dates.append(v.date() if isinstance(v, datetime.datetime) else v)
    if basic_dates:
        b_exp = max(basic_dates)
        rec_no += 1
        records.append(['RC-%06d' % rec_no, en, 'BASIC', '',
                        iso(add_months(b_exp, -12)), iso(b_exp), 'QUALIFIED', '', '', 'import', ''])

# ---- เขียนไฟล์ .gs ----
def js_rows(rows):
    out = []
    for r in rows:
        cells = []
        for v in r:
            if v is True:
                cells.append('true')
            elif v is False:
                cells.append('false')
            else:
                cells.append(json.dumps(v, ensure_ascii=False))
        out.append('  [' + ','.join(cells) + ']')
    return ',\n'.join(out)

header = '''/**
 * 11_SeedData.gs : ข้อมูลจริงนำเข้าจากไฟล์ Excel (สร้างอัตโนมัติด้วย tools/generate_seed.py)
 *   - พนักงาน %d คน, training records %d รายการ
 * วิธีใช้: รัน setupDatabase() ก่อน แล้วรัน importSeedData() หนึ่งครั้ง
 *          (เขียนทับข้อมูลเดิมในตาราง Employees / TrainingRecords)
 */

// คอลัมน์ตรงกับ SCHEMA.Employees.header
var SEED_EMPLOYEES = [
%s
];

// คอลัมน์ตรงกับ SCHEMA.TrainingRecords.header
var SEED_RECORDS = [
%s
];

/** แปลง 'yyyy-MM-dd' -> Date ; ค่าว่างคงเดิม */
function seedParseDate_(v) {
  if (!v || typeof v !== 'string') return v;
  var m = v.match(/^(\\d{4})-(\\d{2})-(\\d{2})$/);
  if (!m) return v;
  return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
}

/** นำเข้าข้อมูล seed (bulk setValues — เร็ว ไม่ชน execution limit) */
function importSeedData() {
  var dateColsEmp = [];                 // Employees ไม่มีคอลัมน์วันที่
  var dateColsRec = [3, 4, 5];          // OverviewDate, QualifiedDate, ExpiryDate
  var now = new Date();

  // Employees
  var emp = SEED_EMPLOYEES.map(function (r) { return r.slice(); });
  _bulkWrite_('Employees', emp, dateColsEmp, -1);

  // TrainingRecords (เติม UpdatedAt = now ที่คอลัมน์สุดท้าย)
  var rec = SEED_RECORDS.map(function (r) {
    var c = r.slice(); c[c.length - 1] = now; return c;
  });
  _bulkWrite_('TrainingRecords', rec, dateColsRec, -1);

  SpreadsheetApp.getActiveSpreadsheet().toast(
    'นำเข้า ' + emp.length + ' พนักงาน, ' + rec.length + ' records', 'Import', 6);
  return { employees: emp.length, records: rec.length };
}

function _bulkWrite_(tableKey, rows, dateCols, _unused) {
  var sh = getSheet_(tableKey);
  var header = SCHEMA[tableKey].header;
  // ล้างข้อมูลเดิม (เก็บ header)
  if (sh.getLastRow() > 1) sh.deleteRows(2, sh.getLastRow() - 1);
  if (!rows.length) return;
  // แปลงคอลัมน์วันที่
  rows.forEach(function (r) {
    dateCols.forEach(function (ci) { r[ci] = seedParseDate_(r[ci]); });
  });
  sh.getRange(2, 1, rows.length, header.length).setValues(rows);
}
''' % (len(employees), len(records), js_rows(employees), js_rows(records))

with open(OUT, 'w', encoding='utf-8') as f:
    f.write(header)

print('employees:', len(employees))
print('records  :', len(records))
print('written  :', OUT)
