# -*- coding: utf-8 -*-
"""ตรวจสอบ: ข้อมูลใน DB (SEED arrays ใน Code.gs) ตรงกับไฟล์ .xlsx ต้นฉบับไหม"""
import openpyxl, datetime, re, json, os
from collections import OrderedDict

SRC = 'Copy of Target Plan to Support Ciena 2026.xlsx'
SHEET = 'Complete Name lis_2026'
CODE = os.path.join('apps-script', 'Code.gs')
VALIDITY = 24
DATA_START = 4
COURSE_COLS = {
    'HFO144-NEW': (11, 12), 'HFO145-NEW': (17, 18),
    'HFO144-REF': (14, 15), 'HFO145-REF': (25, 26),
}

def clean(v):
    if v is None: return ''
    if isinstance(v, float) and v.is_integer(): return str(int(v))
    if isinstance(v, (datetime.date, datetime.datetime)): return v.strftime('%Y-%m-%d')
    return str(v).strip()

def add_months(d, m):
    y = d.year + (d.month - 1 + m) // 12
    mo = (d.month - 1 + m) % 12 + 1
    leap = y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)
    day = min(d.day, [31,29 if leap else 28,31,30,31,30,31,31,30,31,30,31][mo-1])
    return datetime.date(y, mo, day)

# ---------- 1) อ่าน xlsx ใหม่ (อิสระ) ----------
wb = openpyxl.load_workbook(SRC, data_only=True)
ws = wb[SHEET]
rows_by_en = OrderedDict()
for row in ws.iter_rows(min_row=DATA_START, values_only=True):
    en = clean(row[5])
    if not en: continue
    rows_by_en.setdefault(en, []).append(row)

def first_nonempty(rows, idx):
    for r in rows:
        v = clean(r[idx])
        if v: return v
    return ''

xlsx_emp = {}      # EN -> [NameEN,NameTH,Nick,Area,Sup,Splice]
xlsx_rec = {}      # (EN,course) -> (overview, qualified)
for en, rows in rows_by_en.items():
    xlsx_emp[en] = [first_nonempty(rows,6), first_nonempty(rows,7), first_nonempty(rows,8),
                    first_nonempty(rows,9), first_nonempty(rows,28), first_nonempty(rows,29)]
    for course,(oi,qi) in COURSE_COLS.items():
        ovs, qls = [], []
        for r in rows:
            if isinstance(r[oi], (datetime.date, datetime.datetime)): ovs.append(r[oi])
            if isinstance(r[qi], (datetime.date, datetime.datetime)): qls.append(r[qi])
        ov = min([o.date() if isinstance(o,datetime.datetime) else o for o in ovs], default=None)
        ql = max([q.date() if isinstance(q,datetime.datetime) else q for q in qls], default=None)
        if ov or ql:
            xlsx_rec[(en,course)] = (ov.strftime('%Y-%m-%d') if ov else '',
                                     ql.strftime('%Y-%m-%d') if ql else '')

# ---------- 2) อ่าน SEED จาก Code.gs ----------
code = open(CODE, encoding='utf-8').read()
def parse_arr(name):
    m = re.search(r'var '+name+r' = \[(.*?)\n\];', code, re.S)
    rows = []
    for line in m.group(1).splitlines():
        line = line.strip().rstrip(',')
        if line.startswith('['):
            rows.append(json.loads(line))
    return rows
seed_emp_rows = parse_arr('SEED_EMPLOYEES')
seed_rec_rows = parse_arr('SEED_RECORDS')
seed_emp = {r[0]: r[1:7] for r in seed_emp_rows}                  # EN -> [NameEN..Splice]
seed_rec = {(r[1], r[2]): (r[3], r[4]) for r in seed_rec_rows}    # (EN,course)->(ov,ql)

# ---------- 3) เทียบ ----------
print('=== สรุปจำนวน ===')
print(f'  พนักงาน: xlsx={len(xlsx_emp)}  seed/DB={len(seed_emp)}  {"✅ตรง" if len(xlsx_emp)==len(seed_emp) else "❌ไม่ตรง"}')
print(f'  records: xlsx={len(xlsx_rec)}  seed/DB={len(seed_rec)}  {"✅ตรง" if len(xlsx_rec)==len(seed_rec) else "❌ไม่ตรง"}')

# พนักงานที่ขาด/เกิน
miss_emp = set(xlsx_emp) - set(seed_emp)
extra_emp = set(seed_emp) - set(xlsx_emp)
print(f'\n=== พนักงาน ===')
print(f'  อยู่ใน xlsx แต่ไม่อยู่ใน DB: {len(miss_emp)} {sorted(miss_emp)[:10]}')
print(f'  อยู่ใน DB แต่ไม่อยู่ใน xlsx: {len(extra_emp)} {sorted(extra_emp)[:10]}')
# ฟิลด์ไม่ตรง
field_names = ['NameEN','NameTH','Nickname','WorkingArea','Supervisor','SplicingExp']
emp_mismatch = 0
for en in set(xlsx_emp) & set(seed_emp):
    if xlsx_emp[en] != seed_emp[en]:
        emp_mismatch += 1
        if emp_mismatch <= 5:
            diffs = [f'{field_names[i]}: xlsx="{xlsx_emp[en][i]}" vs DB="{seed_emp[en][i]}"'
                     for i in range(6) if xlsx_emp[en][i] != seed_emp[en][i]]
            print(f'  ⚠️ {en}: ' + ' | '.join(diffs))
print(f'  ฟิลด์ไม่ตรง: {emp_mismatch} คน')

# records
print(f'\n=== records (วัน overview/qualified) ===')
miss_rec = set(xlsx_rec) - set(seed_rec)
extra_rec = set(seed_rec) - set(xlsx_rec)
print(f'  อยู่ใน xlsx แต่ไม่อยู่ใน DB: {len(miss_rec)} {sorted(miss_rec)[:5]}')
print(f'  อยู่ใน DB แต่ไม่อยู่ใน xlsx: {len(extra_rec)} {sorted(extra_rec)[:5]}')
rec_mismatch = 0
for k in set(xlsx_rec) & set(seed_rec):
    if xlsx_rec[k] != seed_rec[k]:
        rec_mismatch += 1
        if rec_mismatch <= 5:
            print(f'  ⚠️ {k}: xlsx={xlsx_rec[k]} vs DB={seed_rec[k]}')
print(f'  วันที่ไม่ตรง: {rec_mismatch} records')

# ตรวจ expiry = qualified + 24m
print(f'\n=== ตรวจสูตร ExpiryDate (= Qualified + 24 เดือน) ===')
exp_bad = 0
for r in seed_rec_rows:
    ql, exp = r[4], r[5]
    if ql:
        m = re.match(r'(\d{4})-(\d{2})-(\d{2})', ql)
        expect = add_months(datetime.date(int(m[1]),int(m[2]),int(m[3])), VALIDITY).strftime('%Y-%m-%d')
        if exp != expect: exp_bad += 1
print(f'  Expiry ผิดสูตร: {exp_bad} records')

print('\n=== ผลรวม ===')
ok = (len(xlsx_emp)==len(seed_emp) and len(xlsx_rec)==len(seed_rec)
      and not miss_emp and not extra_emp and emp_mismatch==0
      and not miss_rec and not extra_rec and rec_mismatch==0 and exp_bad==0)
print('  ✅ DB ตรงกับ xlsx ทุกประการ' if ok else '  ⚠️ พบความต่าง (ดูด้านบน)')
