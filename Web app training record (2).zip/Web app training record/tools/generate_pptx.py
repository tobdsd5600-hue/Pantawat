"""
สร้างไฟล์ Presentation (.pptx) สำหรับ Training Record Web App
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt
import os

# ── Colors (ตรงกับ app theme) ──────────────────────────────────────────────
NAVY   = RGBColor(0x1F, 0x38, 0x64)
NAVY2  = RGBColor(0x2E, 0x4D, 0x8E)
GREEN  = RGBColor(0x22, 0xA5, 0x59)
YELLOW = RGBColor(0xF4, 0xB4, 0x00)
RED    = RGBColor(0xE0, 0x49, 0x2F)
BLUE   = RGBColor(0x3A, 0x7A, 0xFE)
GRAY   = RGBColor(0xC2, 0xC7, 0xD0)
BG     = RGBColor(0xF4, 0xF6, 0xFB)
WHITE  = RGBColor(0xFF, 0xFF, 0xFF)
TEXT   = RGBColor(0x1F, 0x2A, 0x3D)
MUTED  = RGBColor(0x6B, 0x78, 0x91)
LIGHT  = RGBColor(0xEE, 0xF1, 0xF8)

W = Inches(13.33)   # widescreen 16:9
H = Inches(7.5)

prs = Presentation()
prs.slide_width  = W
prs.slide_height = H

BLANK = prs.slide_layouts[6]   # completely blank


# ── Helpers ────────────────────────────────────────────────────────────────

def add_rect(slide, x, y, w, h, fill=None, line=None, line_w=Pt(0)):
    shape = slide.shapes.add_shape(1, x, y, w, h)   # MSO_SHAPE_TYPE.RECTANGLE = 1
    shape.line.fill.background()
    if fill:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill
    else:
        shape.fill.background()
    if line:
        shape.line.color.rgb = line
        shape.line.width = line_w
    else:
        shape.line.fill.background()
    return shape

def add_text(slide, text, x, y, w, h,
             size=18, bold=False, color=TEXT, align=PP_ALIGN.LEFT,
             wrap=True, italic=False):
    txb = slide.shapes.add_textbox(x, y, w, h)
    tf  = txb.text_frame
    tf.word_wrap = wrap
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size  = Pt(size)
    run.font.bold  = bold
    run.font.italic = italic
    run.font.color.rgb = color
    return txb

def navy_header(slide, title, subtitle=None):
    """Dark navy top bar with white title."""
    add_rect(slide, 0, 0, W, Inches(1.3), fill=NAVY)
    add_text(slide, title,
             Inches(0.5), Inches(0.15), Inches(12), Inches(0.8),
             size=28, bold=True, color=WHITE, align=PP_ALIGN.LEFT)
    if subtitle:
        add_text(slide, subtitle,
                 Inches(0.5), Inches(0.85), Inches(12), Inches(0.4),
                 size=13, color=RGBColor(0xCD, 0xD6, 0xEA), align=PP_ALIGN.LEFT)

def accent_bar(slide, x, y, h, color=GREEN):
    """Thin vertical accent bar."""
    add_rect(slide, x, y, Inches(0.06), h, fill=color)

def bullet_box(slide, items, x, y, w, h, icon_color=NAVY2, size=14):
    """Simple bulleted list in a text box."""
    txb = slide.shapes.add_textbox(x, y, w, h)
    tf  = txb.text_frame
    tf.word_wrap = True
    for i, item in enumerate(items):
        p = tf.add_paragraph() if i > 0 else tf.paragraphs[0]
        p.space_before = Pt(4)
        p.alignment = PP_ALIGN.LEFT
        run = p.add_run()
        run.text = item
        run.font.size  = Pt(size)
        run.font.color.rgb = TEXT

def card(slide, x, y, w, h, title, body_lines,
         accent=NAVY2, title_size=15, body_size=12.5):
    """White card with colored top border."""
    add_rect(slide, x, y, w, h, fill=WHITE,
             line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
    add_rect(slide, x, y, w, Inches(0.07), fill=accent)   # top accent line
    add_text(slide, title,
             x + Inches(0.15), y + Inches(0.1), w - Inches(0.3), Inches(0.35),
             size=title_size, bold=True, color=accent)
    body = "\n".join(body_lines)
    add_text(slide, body,
             x + Inches(0.15), y + Inches(0.44), w - Inches(0.3), h - Inches(0.55),
             size=body_size, color=TEXT)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 1 — TITLE
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=NAVY)
# decorative circles
add_rect(sl, Inches(10.2), Inches(-0.8), Inches(3.5), Inches(3.5),
         fill=NAVY2)
add_rect(sl, Inches(11.5), Inches(5.5), Inches(2.5), Inches(2.5),
         fill=RGBColor(0x16, 0x2B, 0x55))

add_text(sl, "Training Record Web App",
         Inches(0.7), Inches(1.8), Inches(9.5), Inches(1.1),
         size=40, bold=True, color=WHITE)
add_rect(sl, Inches(0.7), Inches(3.05), Inches(1.8), Inches(0.07), fill=GREEN)
add_text(sl, "Ciena Optical / Celestica  —  Phase 1 MVP",
         Inches(0.7), Inches(3.2), Inches(10), Inches(0.55),
         size=20, color=RGBColor(0xCD, 0xD6, 0xEA))
add_text(sl, "Google Apps Script  +  Google Sheets",
         Inches(0.7), Inches(3.85), Inches(8), Inches(0.45),
         size=15, color=MUTED, italic=True)
add_text(sl, "Developer: Pantawat Tantem  |  OE Center",
         Inches(0.7), Inches(6.8), Inches(10), Inches(0.45),
         size=12, color=RGBColor(0x6B, 0x78, 0x91))


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 2 — CONCEPT  (ปัญหา → ทางแก้)
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=BG)
navy_header(sl, "Concept", "Why we built this system")

# LEFT — Problem
add_rect(sl, Inches(0.4), Inches(1.5), Inches(5.8), Inches(5.4),
         fill=WHITE, line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
add_rect(sl, Inches(0.4), Inches(1.5), Inches(5.8), Inches(0.08), fill=RED)
add_text(sl, "❌  Before  (Pain Points)",
         Inches(0.55), Inches(1.58), Inches(5.5), Inches(0.45),
         size=16, bold=True, color=RED)
bullet_box(sl, [
    "•  ส่งไฟล์ Excel ทาง email  →  ข้อมูลกระจาย",
    "•  ไม่มี central tracking — ไม่รู้ใครหมดอายุ",
    "•  ต้องรวบรวมข้อมูลด้วยมือทุกครั้ง",
    "•  ไม่มีระบบแจ้งเตือน cert ใกล้หมดอายุ",
    "•  ยืนยันผลเทรนผ่าน Line/email ไม่มี record",
], Inches(0.55), Inches(2.1), Inches(5.5), Inches(4.5), size=14)

# Arrow
add_text(sl, "➜", Inches(6.35), Inches(3.7), Inches(0.7), Inches(0.7),
         size=32, bold=True, color=NAVY2, align=PP_ALIGN.CENTER)

# RIGHT — Solution
add_rect(sl, Inches(7.2), Inches(1.5), Inches(5.7), Inches(5.4),
         fill=WHITE, line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
add_rect(sl, Inches(7.2), Inches(1.5), Inches(5.7), Inches(0.08), fill=GREEN)
add_text(sl, "✅  After  (This System)",
         Inches(7.35), Inches(1.58), Inches(5.5), Inches(0.45),
         size=16, bold=True, color=GREEN)
bullet_box(sl, [
    "•  Web App — เข้าได้ทุกที่ ไม่ต้องติดตั้ง",
    "•  Ticketing System — ติดตามทุกขั้นตอน",
    "•  Skill Matrix แบบ real-time อัปเดตอัตโนมัติ",
    "•  แจ้งเตือน Email อัตโนมัติทุกเหตุการณ์",
    "•  Bulk Import CSV/Excel สำหรับข้อมูลจำนวนมาก",
], Inches(7.35), Inches(2.1), Inches(5.5), Inches(4.5), size=14)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 3 — SYSTEM ARCHITECTURE
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=BG)
navy_header(sl, "System Architecture", "Google Apps Script  +  Google Sheets as Database")

boxes = [
    (Inches(0.4),  "🌐 Browser\n(HTML SPA)",        BLUE,  "HtmlService\nSingle Page App"),
    (Inches(3.5),  "⚙️ Apps Script\n(Code.gs)",      NAVY,  "Server Logic\nAPI / Auth / Email"),
    (Inches(6.6),  "🗄️ Google Sheets\n(Database)",   GREEN, "6 Sheets\nEmployees / Records\nTickets / Courses\nUsers / AuditLog"),
    (Inches(9.7),  "📧 Gmail\n(Notifications)",      MUTED, "Event-driven\n+ Daily / Weekly\nTriggers"),
]
for bx, label, color, sub in boxes:
    add_rect(sl, bx, Inches(2.0), Inches(2.8), Inches(2.4), fill=color)
    add_text(sl, label, bx + Inches(0.1), Inches(2.1), Inches(2.6), Inches(0.8),
             size=14, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    add_text(sl, sub,  bx + Inches(0.1), Inches(2.95), Inches(2.6), Inches(1.4),
             size=11, color=WHITE, align=PP_ALIGN.CENTER)

# arrows between boxes
for ax in [Inches(3.2), Inches(6.3), Inches(9.4)]:
    add_text(sl, "→", ax, Inches(2.9), Inches(0.4), Inches(0.5),
             size=22, bold=True, color=NAVY2, align=PP_ALIGN.CENTER)

# Stack label
add_rect(sl, Inches(0.4), Inches(4.8), Inches(12.5), Inches(2.3),
         fill=WHITE, line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
add_text(sl, "Stack Highlights",
         Inches(0.6), Inches(4.9), Inches(6), Inches(0.4),
         size=13, bold=True, color=NAVY)
bullet_box(sl, [
    "•  ไม่ต้องตั้งค่า server / hosting — รันบน Google Infrastructure",
    "•  Google Sheets = Database (แต่ละ Sheet = 1 Table)   •  Parse CSV/XLSX ฝั่ง server — ไม่พึ่ง CDN",
    "•  Session token + Role-based access control   •  withLock_() กัน race condition ทุก write API",
], Inches(0.6), Inches(5.35), Inches(12), Inches(1.6), size=12.5)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 4 — FEATURES OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=BG)
navy_header(sl, "Features Overview", "Phase 1 MVP — 6 core modules")

feature_cards = [
    (NAVY2,  "🔐  Roles & Auth",
     ["4 roles: STAFF / SUPERVISOR", "TRAINER / ADMIN",
      "PIN login (TRAINER/ADMIN)", "EN-only (STAFF/SUP)"]),
    (GREEN,  "🗂️  Skill Matrix",
     ["พนักงาน × 5 คอร์ส", "สีสถานะ real-time",
      "กรอง Work Area", "ค้นหา EN / ชื่อ"]),
    (BLUE,   "🎫  Ticketing",
     ["เปิด / จัดคิว / ปิดงาน", "มอบหมาย Trainer",
      "บันทึกผลอัตโนมัติ", "ปิด → Matrix อัปเดต"]),
    (YELLOW, "📥  Bulk Import",
     ["Template xlsx (dropdown)", "Upload CSV / Excel",
      "Preview ก่อน import", "สูงสุด 200 แถว/ครั้ง"]),
    (RED,    "📊  Dashboard",
     ["KPI 6 ตัว", "Area trend chart",
      "Donut สัดส่วน", "Stacked bar per course"]),
    (MUTED,  "📧  Email Alerts",
     ["Event-driven (ทันที)", "Daily cert expiry",
      "Weekly summary", "Reply-To = คนทำรายการ"]),
]

cols = 3
for i, (color, title, lines) in enumerate(feature_cards):
    col = i % cols
    row = i // cols
    cx = Inches(0.35) + col * Inches(4.3)
    cy = Inches(1.45) + row * Inches(2.8)
    card(sl, cx, cy, Inches(4.1), Inches(2.6),
         title, lines, accent=color, title_size=14, body_size=12)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 5 — FILE STRUCTURE
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=BG)
navy_header(sl, "File Structure", "apps-script/  (4 files — ก๊อปวางใน Apps Script ได้เลย)")

files = [
    ("Code.gs",         NAVY,   [
        "Server logic ทั้งหมดในไฟล์เดียว",
        "Config · Auth · Records · Tickets · Skill Matrix",
        "Dashboard · Alerts · Seed Data (90 พนักงาน / 195 records)",
        "doGet() — serve หน้าเว็บ",
    ]),
    ("Index.html",      BLUE,   [
        "HTML shell — login card + sidebar layout",
        "รวม Styles.html + JavaScript.html ผ่าน include()",
        "Google Charts loader + SheetJS fallback",
    ]),
    ("Styles.html",     GREEN,  [
        "CSS ทั้งหมด — variables, layout, components",
        "Responsive: sidebar → top bar (≤720px)",
        "Status colors, Skill Matrix cells, Modal, Toast",
    ]),
    ("JavaScript.html", YELLOW, [
        "Client SPA logic — routing, render functions",
        "google.script.run wrapper (Promise-based)",
        "Dashboard charts, Bulk import, Modal",
    ]),
]

for i, (fname, color, lines) in enumerate(files):
    cy = Inches(1.45) + i * Inches(1.38)
    add_rect(sl, Inches(0.35), cy, Inches(2.5), Inches(1.2), fill=color)
    add_text(sl, fname,
             Inches(0.42), cy + Inches(0.15), Inches(2.3), Inches(0.55),
             size=16, bold=True, color=WHITE, align=PP_ALIGN.CENTER)

    add_rect(sl, Inches(2.95), cy, Inches(10.0), Inches(1.2),
             fill=WHITE, line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
    add_rect(sl, Inches(2.95), cy, Inches(0.07), Inches(1.2), fill=color)
    body = "  ·  ".join(lines[:2]) + ("\n  ·  ".join([""] + lines[2:]) if len(lines) > 2 else "")
    add_text(sl, "  ·  ".join(lines),
             Inches(3.1), cy + Inches(0.15), Inches(9.6), Inches(1.0),
             size=12, color=TEXT)

add_text(sl, "appsscript.json  —  manifest, scopes, Web App settings  |  .clasp.json  —  deploy config (ไม่ต้องก๊อปไปใส่ Apps Script)",
         Inches(0.35), Inches(7.0), Inches(12.6), Inches(0.35),
         size=10.5, color=MUTED, italic=True)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 6 — ROLES & ACCESS
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=BG)
navy_header(sl, "Roles & Access Control", "4 roles — 2 login methods")

role_data = [
    (MUTED,  "STAFF",      "❌ ไม่ต้องมีใน Users",  "Dashboard · Skill Matrix (view) · Tickets (ของตัวเอง) · My Training Records"),
    (GREEN,  "SUPERVISOR", "❌ ไม่ต้องมี PIN",       "เหมือน STAFF + เห็นทีมตัวเอง + รับ Email แจ้งเตือนทีม"),
    (BLUE,   "TRAINER",    "✅ ต้องมี PIN",           "SUPERVISOR + จัดการ Ticket · บันทึกผล · แก้ Skill Matrix"),
    (NAVY,   "ADMIN",      "✅ ต้องมี PIN",           "ทุกอย่าง + จัดการผู้ใช้ + รัน setup · สรุปรายสัปดาห์ (ทั้งระบบ)"),
]

# header row
hx, hy = Inches(0.35), Inches(1.45)
for ci, (label, cw) in enumerate([("Role", 1.5), ("Login", 2.3), ("Requirement", 2.3), ("Access", 6.8)]):
    add_rect(sl, hx, hy, Inches(cw), Inches(0.45), fill=NAVY)
    add_text(sl, label, hx + Inches(0.1), hy + Inches(0.05),
             Inches(cw - 0.15), Inches(0.38),
             size=13, bold=True, color=WHITE)
    hx += Inches(cw)

for ri, (color, role, req, access) in enumerate(role_data):
    ry = Inches(1.9) + ri * Inches(1.18)
    rh = Inches(1.1)
    add_rect(sl, Inches(0.35), ry, Inches(1.5), rh, fill=color)
    add_text(sl, role, Inches(0.38), ry + Inches(0.3),
             Inches(1.4), Inches(0.5), size=14, bold=True,
             color=WHITE, align=PP_ALIGN.CENTER)
    for ci, (text, cw, cx) in enumerate([
        (req,    2.3, 1.85),
        ("",     2.3, 4.15),
        (access, 6.8, 6.45),
    ]):
        add_rect(sl, Inches(cx), ry, Inches(cw), rh,
                 fill=WHITE if ri % 2 == 0 else LIGHT,
                 line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
    add_text(sl, req,    Inches(1.95), ry + Inches(0.2), Inches(2.1), Inches(0.8), size=12, color=TEXT)
    add_text(sl, access, Inches(6.55), ry + Inches(0.2), Inches(6.5), Inches(0.8), size=12, color=TEXT)

add_text(sl, "* STAFF ที่ยังไม่มี record ในระบบ สามารถ login ด้วย EN ใดก็ได้ — เปิด Ticket เพื่อลงทะเบียนตัวเองได้ทันที",
         Inches(0.35), Inches(6.85), Inches(12.6), Inches(0.4),
         size=10.5, color=MUTED, italic=True)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 7 — TICKETING FLOW
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=BG)
navy_header(sl, "Ticketing Flow", "เปิดคำขอ → จัดคิว → เทรน → ปิดงาน → Skill Matrix อัปเดตอัตโนมัติ")

statuses = [
    (MUTED,  "OPEN",        "เปิดคำขอ\nSTAFF / ทุก role"),
    (YELLOW, "SCHEDULED",   "นัดวันเทรน\nมอบ Trainer"),
    (BLUE,   "IN PROGRESS", "กำลังเทรน\n"),
    (GREEN,  "COMPLETED",   "ปิดงาน\n+ บันทึกผล"),
    (RED,    "CANCELLED",   "ยกเลิก\n(optional)"),
]

bw = Inches(2.1)
for i, (color, label, sub) in enumerate(statuses):
    bx = Inches(0.3) + i * Inches(2.55)
    add_rect(sl, bx, Inches(2.0), bw, Inches(1.5), fill=color)
    add_text(sl, label, bx + Inches(0.1), Inches(2.1), bw - Inches(0.2), Inches(0.6),
             size=14, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    add_text(sl, sub,   bx + Inches(0.1), Inches(2.65), bw - Inches(0.2), Inches(0.7),
             size=11,  color=WHITE, align=PP_ALIGN.CENTER)
    if i < 3:
        add_text(sl, "→", bx + bw + Inches(0.1), Inches(2.55), Inches(0.35), Inches(0.5),
                 size=20, bold=True, color=NAVY2, align=PP_ALIGN.CENTER)

# Auto record note
add_rect(sl, Inches(7.7), Inches(2.0), Inches(5.25), Inches(1.5),
         fill=WHITE, line=GREEN, line_w=Pt(2))
add_text(sl, "⚡ Auto Record",
         Inches(7.85), Inches(2.05), Inches(5.0), Inches(0.45),
         size=13, bold=True, color=GREEN)
add_text(sl, "COMPLETED + ผลประเมิน\n→ เขียน TrainingRecords อัตโนมัติ\n→ Skill Matrix สีอัปเดตทันที",
         Inches(7.85), Inches(2.5),  Inches(5.0), Inches(0.9),
         size=12, color=TEXT)

# Bottom: email triggers
add_rect(sl, Inches(0.3), Inches(3.85), Inches(12.7), Inches(3.25),
         fill=WHITE, line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
add_text(sl, "📧  Email Notifications (Automatic)",
         Inches(0.5), Inches(3.9), Inches(8), Inches(0.4),
         size=13, bold=True, color=NAVY)
email_items = [
    ("เปิด Ticket (OPEN)",       "→  แจ้ง TRAINER + ADMIN ทุกคน"),
    ("นัดวัน (SCHEDULED)",        "→  แจ้ง พนักงาน + หัวหน้างาน"),
    ("ปิดงานมีผล (COMPLETED)",    "→  แจ้ง พนักงาน + หัวหน้างาน + แนบผลเทรน"),
    ("Bulk Import สำเร็จ",        "→  สรุปจำนวนรายการ + ตารางรายชื่อ"),
    ("Cert ใกล้หมด/หมดอายุ",      "→  ทุกวัน 07:00  (Trigger รายวัน)"),
    ("Weekly Summary",            "→  ทุกวันจันทร์ ~07:30  (ADMIN + หัวหน้าแยกทีม)"),
]
for i, (trigger, action) in enumerate(email_items):
    col = i % 2
    row = i // 2
    ex = Inches(0.5)  + col * Inches(6.3)
    ey = Inches(4.35) + row * Inches(0.7)
    add_text(sl, f"•  {trigger}", ex,              ey, Inches(2.8), Inches(0.6), size=12, bold=True,  color=NAVY2)
    add_text(sl, action,          ex + Inches(2.8), ey, Inches(3.2), Inches(0.6), size=12, color=TEXT)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 8 — COURSES
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=BG)
navy_header(sl, "Courses (5 Courses)", "อายุใบเซอร์ 12 เดือนทุกคอร์ส  |  เกณฑ์ใกล้หมดอายุ: ≤ 30 วัน")

courses = [
    ("BASIC",      "Basic Fiber Optic",              MUTED, "Prerequisite — ต้องผ่านก่อน  |  ❌ ไม่เปิดผ่าน Ticket"),
    ("HFO144-NEW", '"New" HFO_144 (CP20433) Ribbon', BLUE,  "คอร์สใหม่ Hands-on  |  ✅ เปิด Ticket ได้"),
    ("HFO145-NEW", '"New" HFO_145 (CP43997) SM, PM', BLUE,  "คอร์สใหม่ Hands-on  |  ✅ เปิด Ticket ได้"),
    ("HFO144-REF", "REFRESHER HFO_144 (CP20433)",    GREEN, "Refresher  |  ✅ เปิด Ticket ได้"),
    ("HFO145-REF", "REFRESHER HFO_145 (CP43997)",    GREEN, "Refresher  |  ✅ เปิด Ticket ได้"),
]
for i, (cid, name, color, note) in enumerate(courses):
    ry = Inches(1.5) + i * Inches(1.05)
    add_rect(sl, Inches(0.35), ry, Inches(2.0), Inches(0.9), fill=color)
    add_text(sl, cid,
             Inches(0.38), ry + Inches(0.2), Inches(1.9), Inches(0.5),
             size=13, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    add_rect(sl, Inches(2.45), ry, Inches(10.5), Inches(0.9),
             fill=WHITE if i % 2 == 0 else LIGHT,
             line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
    add_rect(sl, Inches(2.45), ry, Inches(0.06), Inches(0.9), fill=color)
    add_text(sl, name, Inches(2.6), ry + Inches(0.06), Inches(4.8), Inches(0.4),
             size=13, bold=True, color=color)
    add_text(sl, note, Inches(2.6), ry + Inches(0.46), Inches(10), Inches(0.38),
             size=11, color=MUTED)

# Status legend
legend_items = [
    (GREEN,  "🟢 Qualified"),
    (YELLOW, "🟡 Near Expiry (≤30d)"),
    (RED,    "🔴 Expired / Failed"),
    (BLUE,   "🔵 In Training"),
    (MUTED,  "⚪ Not Trained"),
]
add_rect(sl, Inches(0.35), Inches(6.8), Inches(12.6), Inches(0.5),
         fill=WHITE, line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
lx = Inches(0.55)
for color, label in legend_items:
    add_text(sl, label, lx, Inches(6.85), Inches(2.3), Inches(0.35),
             size=11, bold=False, color=TEXT)
    lx += Inches(2.4)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 9 — DASHBOARD & CHARTS
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=BG)
navy_header(sl, "Dashboard & Analytics", "Real-time overview — Google Charts")

kpis = [
    (NAVY,  "Total\nEmployees", "~90"),
    (GREEN, "Qualified",        "—"),
    (YELLOW,"Near Expiry",      "—"),
    (RED,   "Expired",          "—"),
    (BLUE,  "In Training",      "—"),
    (NAVY2, "Open Tickets",     "—"),
]
kw = Inches(2.0)
for i, (color, label, val) in enumerate(kpis):
    kx = Inches(0.35) + i * Inches(2.15)
    add_rect(sl, kx, Inches(1.45), kw, Inches(1.1), fill=WHITE,
             line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
    add_rect(sl, kx, Inches(1.45), Inches(0.07), Inches(1.1), fill=color)
    add_text(sl, val,   kx + Inches(0.15), Inches(1.5),  kw - Inches(0.2), Inches(0.5),
             size=22, bold=True, color=color)
    add_text(sl, label, kx + Inches(0.15), Inches(1.98), kw - Inches(0.2), Inches(0.5),
             size=10, color=MUTED)

charts = [
    (BLUE,  "📈  Area Chart\n(Historical Trend)",
     "จำนวน active certificates ย้อนหลัง\nเลือกช่วง 1 / 3 / 6 / 12 เดือน"),
    (NAVY,  "🍩  Donut Chart\n(Status Distribution)",
     "สัดส่วน Qualified / Near Expiry\nExpired / In Training ปัจจุบัน"),
    (GREEN, "📊  Stacked Bar\n(Per Course)",
     "จำนวนคนแต่ละสถานะ แยกตามคอร์ส\nรวม = จำนวนพนักงานเสมอ"),
]
for i, (color, title, desc) in enumerate(charts):
    cx = Inches(0.35) + i * Inches(4.3)
    add_rect(sl, cx, Inches(2.75), Inches(4.1), Inches(4.3),
             fill=WHITE, line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
    add_rect(sl, cx, Inches(2.75), Inches(4.1), Inches(0.07), fill=color)
    add_text(sl, title, cx + Inches(0.15), Inches(2.85), Inches(3.8), Inches(0.7),
             size=13, bold=True, color=color)
    add_text(sl, desc,  cx + Inches(0.15), Inches(3.6),  Inches(3.8), Inches(1.0),
             size=12, color=TEXT)
    add_rect(sl, cx + Inches(0.3), Inches(4.7), Inches(3.5), Inches(1.8),
             fill=LIGHT, line=RGBColor(0xE3, 0xE8, 0xF1), line_w=Pt(1))
    add_text(sl, "[ Chart Preview ]",
             cx + Inches(0.3), Inches(5.2), Inches(3.5), Inches(0.5),
             size=11, color=MUTED, align=PP_ALIGN.CENTER, italic=True)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 10 — UPDATE PLAN
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=BG)
navy_header(sl, "Update Plan  /  Roadmap", "Phase 1 → Phase 2+")

# Phase 1 (done)
add_rect(sl, Inches(0.35), Inches(1.5), Inches(5.9), Inches(5.6),
         fill=WHITE, line=GREEN, line_w=Pt(2))
add_rect(sl, Inches(0.35), Inches(1.5), Inches(5.9), Inches(0.08), fill=GREEN)
add_text(sl, "✅  Phase 1  —  Completed",
         Inches(0.5), Inches(1.58), Inches(5.6), Inches(0.45),
         size=15, bold=True, color=GREEN)
bullet_box(sl, [
    "✓  4 Roles + Auth (EN / PIN)",
    "✓  Skill Matrix (5 คอร์ส, สีสถานะ, แก้ไขได้)",
    "✓  Ticketing — เปิด / จัดคิว / ปิดงาน",
    "✓  Auto Record เมื่อ COMPLETED",
    "✓  Bulk Import CSV/Excel (200 แถว, preview)",
    "✓  Dashboard + 3 กราฟ (Google Charts)",
    "✓  Email — event + daily + weekly",
    "✓  User Management (ADMIN)",
    "✓  Responsive (mobile sidebar)",
    "✓  Template xlsx (dropdown CourseID)",
], Inches(0.5), Inches(2.1), Inches(5.6), Inches(4.8), size=13)

# Phase 2
add_rect(sl, Inches(6.6), Inches(1.5), Inches(6.4), Inches(5.6),
         fill=WHITE, line=BLUE, line_w=Pt(2))
add_rect(sl, Inches(6.6), Inches(1.5), Inches(6.4), Inches(0.08), fill=BLUE)
add_text(sl, "🚀  Phase 2+  —  Planned",
         Inches(6.75), Inches(1.58), Inches(6.1), Inches(0.45),
         size=15, bold=True, color=BLUE)
p2_items = [
    (BLUE,   "QR e-Certificate",        "QR code ใบเซอร์ดิจิทัล scan ยืนยันได้"),
    (NAVY2,  "Booking Calendar",         "จองคิวเทรน + ปฏิทินรวม"),
    (GREEN,  "Export PDF / Excel",       "ออกรายงานประจำเดือน"),
    (YELLOW, "Audit Trail UI",           "ดู log การแก้ไขทุกรายการจากหน้าเว็บ"),
    (RED,    "Digital Signature",        "ลายเซ็นดิจิทัลตอนปิด Ticket"),
    (MUTED,  "Hash PIN",                 "เปลี่ยน PIN storage เป็น hash"),
    (NAVY,   "Domain Access Control",    "จำกัดเฉพาะ @celestica.com"),
    (BLUE,   "LINE Messaging API",       "แจ้งเตือน LINE (ต่อยอดจาก Email)"),
]
for i, (color, title, desc) in enumerate(p2_items):
    iy = Inches(2.1) + i * Inches(0.62)
    add_rect(sl, Inches(6.75), iy, Inches(0.08), Inches(0.5), fill=color)
    add_text(sl, title, Inches(6.95), iy,           Inches(2.5), Inches(0.5),
             size=12, bold=True, color=color)
    add_text(sl, desc,  Inches(9.5),  iy + Inches(0.02), Inches(3.3), Inches(0.45),
             size=11, color=MUTED)


# ══════════════════════════════════════════════════════════════════════════════
# SLIDE 11 — CLOSING
# ══════════════════════════════════════════════════════════════════════════════
sl = prs.slides.add_slide(BLANK)
add_rect(sl, 0, 0, W, H, fill=NAVY)
add_rect(sl, 0, 0, W, Inches(0.1), fill=GREEN)
add_rect(sl, Inches(10.5), Inches(-1), Inches(4), Inches(4), fill=NAVY2)

add_text(sl, "Thank You",
         Inches(0.8), Inches(1.6), Inches(9), Inches(1.2),
         size=48, bold=True, color=WHITE)
add_rect(sl, Inches(0.8), Inches(2.95), Inches(2.5), Inches(0.07), fill=GREEN)
add_text(sl, "Training Record Web App — Phase 1 MVP",
         Inches(0.8), Inches(3.1), Inches(10), Inches(0.55),
         size=18, color=RGBColor(0xCD, 0xD6, 0xEA))

info = [
    "Developer  :  Pantawat Tantem",
    "Department :  OE Center",
    "Stack      :  Google Apps Script  +  Google Sheets",
    "Deploy     :  clasp push  →  Apps Script Web App (/exec)",
]
for i, line in enumerate(info):
    add_text(sl, line,
             Inches(0.8), Inches(3.85) + i * Inches(0.52), Inches(10), Inches(0.45),
             size=14, color=RGBColor(0xCD, 0xD6, 0xEA))

add_text(sl, "Q & A",
         Inches(0.8), Inches(6.5), Inches(4), Inches(0.7),
         size=24, bold=True, color=GREEN)


# ── Save ───────────────────────────────────────────────────────────────────
out = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                   "Training_Record_Presentation.pptx")
prs.save(out)
print(f"Saved: {out}")
