# บทบาทและสิทธิ์การใช้งาน (Roles & Access)

## วิธีล็อกอิน

| บทบาท | วิธีล็อกอิน |
| --- | --- |
| **STAFF** (ผู้ช่วย SUPERVISOR) | EN อย่างเดียว ไม่ต้องใช้ PIN |
| **OPERATOR** | EN อย่างเดียว ไม่ต้องใช้ PIN |
| **SUPERVISOR** (หัวหน้างาน) | EN อย่างเดียว ไม่ต้องใช้ PIN |
| **อพอๅ-** (วิทยากร) | Username + PIN |
| **ADMIN** | Username + PIN |

> STAFF, OPERATOR และ SUPERVISOR ไม่ต้องมีแถวใน sheet `Users` — ระบบ fallback ไปหา EN ใน sheet `Employees` ให้อัตโนมัติ

---

## เมนูที่เข้าถึงได้

| เมนู | STAFF | OPERATOR | SUPERVISOR | TRAINER | ADMIN |
| --- | :---: | :---: | :---: | :---: | :---: |
| Dashboard | ✓ | — | ✓ | ✓ | ✓ |
| Skill Matrix | ✓ ดูอย่างเดียว | — | ✓ ดูอย่างเดียว | ✓ แก้ไขได้ | ✓ แก้ไขได้ |
| Calendar | ✓ เฉพาะตัวเอง | ✓ เฉพาะตัวเอง | ✓ ทีมตัวเอง | ✓ ทั้งหมด | ✓ ทั้งหมด |
| Tickets | ✓ เฉพาะตัวเอง | ✓ เฉพาะตัวเอง | ✓ ทีมตัวเอง | ✓ ทั้งหมด | ✓ ทั้งหมด |
| My Training Records | ✓ | ✓ | — | — | — |
| Employees | — | — | — | ✓ | ✓ |
| Courses | — | — | — | ✓ | ✓ |
| User Management | — | — | — | ✓ | ✓ |

---

## สิทธิ์ละเอียดแต่ละเมนู

### Dashboard

- **STAFF / SUPERVISOR / TRAINER / ADMIN** — เห็น KPI summary, กราฟแนวโน้ม, โดนัท, แท่งต่อคอร์ส
- ข้อมูลที่แสดงเป็นภาพรวมทั้งองค์กร (ไม่กรองตาม role)

### Skill Matrix

- **STAFF / SUPERVISOR** — ดูตารางทักษะของทุกคนได้ แต่คลิก cell เพื่อแก้ไขไม่ได้
- **TRAINER / ADMIN** — คลิก cell เพื่อเปิด modal อัปเดต Training Record ได้ + ลบ Record ได้

### Calendar

- แสดง Tickets ที่มี PreferredDate เป็น event บนปฏิทินรายเดือน
- **STAFF / OPERATOR** — เห็นเฉพาะ ticket ของตัวเอง
- **SUPERVISOR** — เห็น ticket ของตัวเองและลูกทีม
- **TRAINER / ADMIN** — เห็นทุก ticket

### Tickets

- **STAFF / OPERATOR** — เห็นเฉพาะ ticket ของตัวเอง, สร้าง ticket ใหม่ได้
- **SUPERVISOR** — เห็น ticket ตัวเองและทีม, สร้างได้, อนุมัติ / แก้ status ได้
- **TRAINER / ADMIN** — เห็นทุก ticket, สร้างได้, แก้ status / assign trainer / ปิดงานได้

### My Training Records

- **STAFF / OPERATOR** — ดูประวัติ training ของตัวเอง (read-only)

### Employees

- **TRAINER / ADMIN** — เพิ่ม / แก้ไข / deactivate พนักงาน

### Courses

- **TRAINER / ADMIN** — เพิ่ม / แก้ไข / ลบคอร์ส
- ลบได้เฉพาะคอร์สที่ไม่มี active tickets (OPEN/SCHEDULED/IN_PROGRESS) และไม่มี Training Records

### User Management

- **TRAINER / ADMIN** — เพิ่ม / แก้ไข User (Username, PIN, Role)
