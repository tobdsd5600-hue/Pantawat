/**
 * ============================================================
 * Training Record Web App  Ciena Optical (Phase 1 MVP)
 * Code.gs  รวมโค้ดฝั่ง server ทั้งหมดไว้ในไฟล์เดียว
 *
 * ลำดับเนื้อหา:
 *   Config -> Lib -> Setup -> Auth -> Records -> Tickets ->
 *   SkillMatrix -> Dashboard -> Api -> WebApp -> Alerts -> SeedData
 *
 * (HTML อยู่แยกไฟล์: Index.html / Styles.html / JavaScript.html)
 * ============================================================
 */



/* ##################################################################
   ### 00_Config
   ################################################################## */

/**
 * ============================================================
 * Training Record Web App — Ciena Optical
 * 00_Config.gs : ค่าคงที่ส่วนกลาง + นิยาม schema ของชีต (Sheets-as-DB)
 * ============================================================
 * Phase 1 (MVP): Roles + Ticketing + Status tracking + Cert expiry alert
 *                + Dashboard + Skill Matrix
 *
 * แนวคิด: Google Sheet 1 ไฟล์ทำหน้าที่เป็นฐานข้อมูล โดยแต่ละ "แท็บ (sheet)"
 *         คือ 1 ตาราง. ไฟล์ Config นี้เป็น single source of truth ของ
 *         ชื่อตาราง + ลำดับคอลัมน์ เพื่อให้ Setup/Import/CRUD อ้างอิงตรงกัน.
 */

// ---- ตั้งค่าทั่วไป ----
const APP = {
  NAME: 'Training Record — Ciena Optical',
  TIMEZONE: 'Asia/Bangkok',
  NEAR_EXPIRY_DAYS: 30,          // สีเหลือง: ใกล้หมดอายุภายในกี่วัน
  DEFAULT_VALIDITY_MONTHS: 12,   // อายุใบเซอร์เริ่มต้น (เดือน) ถ้าคอร์สไม่ระบุ
  // DB (Google Sheet) ที่ใช้เป็นฐานข้อมูล:
  //   '' (ว่าง) = ใช้ Sheet ที่สคริปต์ผูกอยู่ (bound) — ค่าเริ่มต้น
  //   ใส่ Spreadsheet ID = ชี้ไป Sheet อื่น (ต้องมีสิทธิ์ edit + รัน setupDatabase() ใน Sheet นั้นก่อน)
  SPREADSHEET_ID: '1pOsggKWCnp_M1_63Xa2ht8bP5dvqr1AJiyz2c5AgSaQ',
};

// ---- บทบาทผู้ใช้ (3-tier + Admin) ----
const ROLES = {
  STAFF: 'STAFF',           // ผู้ช่วย SUPERVISOR: ดูสถานะตัวเอง, เปิด Ticket ขอเทรน
  OPERATOR: 'OPERATOR',     // ผู้ปฏิบัติงาน: เห็นเฉพาะ Calendar/Tickets/Records ของตัวเอง
  SUPERVISOR: 'SUPERVISOR', // หัวหน้างาน: เปิด Ticket แทนทีม, ดู Skill Matrix ทีม
  TRAINER: 'TRAINER',       // เทรนเนอร์: สิทธิ์เท่า ADMIN (จัดการพนักงาน/คอร์ส/ผู้ใช้)
  ADMIN: 'ADMIN',           // ผู้ดูแลระบบ: จัดการทุกอย่าง
};

// ---- สถานะของ Ticket ----
const TICKET_STATUS = {
  OPEN: 'OPEN',               // เปิดคำขอ รอจัดคิว
  SCHEDULED: 'SCHEDULED',     // นัดวันแล้ว
  IN_PROGRESS: 'IN_PROGRESS', // กำลังเทรน
  COMPLETED: 'COMPLETED',     // ปิดงาน (มีผลประเมินแล้ว)
  CANCELLED: 'CANCELLED',     // ยกเลิก
};

// ---- สถานะของ Training Record ----
const RECORD_STATUS = {
  NOT_TRAINED: 'NOT_TRAINED', // ยังไม่เทรน
  IN_PROGRESS: 'IN_PROGRESS', // ผ่าน overview แล้ว รอ qualified
  QUALIFIED: 'QUALIFIED',     // ผ่าน มีใบเซอร์
  EXPIRED: 'EXPIRED',         // ใบเซอร์หมดอายุ
  FAILED: 'FAILED',           // ประเมินไม่ผ่าน
};

// ---- นิยาม schema ของแต่ละชีต ----
// header = ลำดับคอลัมน์ที่ถูกต้อง (โค้ดทั้งระบบใช้ลำดับนี้)
const SCHEMA = {
  Users: {
    sheet: 'Users',
    header: ['EN', 'Name', 'Role', 'PIN', 'Email', 'Active'],
  },
  Employees: {
    sheet: 'Employees',
    header: ['EN', 'NameEN', 'NameTH', 'Nickname', 'WorkingArea',
             'Supervisor', 'SplicingExp', 'Email', 'Active'],
  },
  Courses: {
    sheet: 'Courses',
    header: ['CourseID', 'CourseName', 'ValidityMonths'],
  },
  TrainingRecords: {
    sheet: 'TrainingRecords',
    header: ['RecordID', 'EN', 'CourseID', 'OverviewDate', 'QualifiedDate',
             'ExpiryDate', 'Status', 'Score', 'Trainer', 'UpdatedBy', 'UpdatedAt'],
  },
  Tickets: {
    sheet: 'Tickets',
    header: ['TicketID', 'EN', 'CourseID', 'RequestedBy', 'RequestDate',
             'PreferredDate', 'Status', 'AssignedTrainer', 'Notes',
             'CreatedAt', 'UpdatedAt'],
  },
  AuditLog: {
    sheet: 'AuditLog',
    header: ['Timestamp', 'User', 'Action', 'Entity', 'EntityID', 'Detail'],
  },
};

// ---- คอร์สเริ่มต้น (อ้างอิงจากข้อมูลจริงในไฟล์ Excel) ----
// [CourseID, ชื่อแสดงผล, อายุใบเซอร์ (เดือน)]
const DEFAULT_COURSES = [
  ['BASIC',      'Basic Fiber Optic',              12],
  ['HFO144-NEW', '"New" HFO_144 (CP20433) Ribbon', 12],
  ['HFO145-NEW', '"New" HFO_145 (CP43997) SM, PM', 12],
  ['HFO144-REF', 'REFRESHER HFO_144 (CP20433)',    12],
  ['HFO145-REF', 'REFRESHER HFO_145 (CP43997)',    12],
];

// คอร์สที่ "ไม่เปิดผ่าน Ticket" (เป็น prerequisite ติดตามแยก ไม่ใช่คำขอเทรน)
// -> ไม่โชว์ในช่องเลือก Course ตอนเปิด Ticket / dropdown ใน template / และ import ไม่รับ
const NON_TICKET_COURSES = ['BASIC'];

// ---- บัญชีหัวหน้างานเริ่มต้น (มาจากคอลัมน์ "Sup" ในไฟล์ Excel) ----
// [loginEN, Name(ชื่อเล่น — ต้องตรงกับคอลัมน์ Supervisor ของ Employees), Email, Role]
// หมายเหตุ: SUPERVISOR ล็อกอินด้วย EN อย่างเดียว ไม่ต้องใช้ PIN (PIN = '')
//          ถ้าต้องการให้คนใดบันทึกผลเทรนได้ ให้เปลี่ยน Role เป็น TRAINER + ตั้ง PIN ในชีต Users
const DEFAULT_SUPERVISORS = [
  ['fang', 'ฟาง',    '', ROLES.SUPERVISOR],
  ['pu',   'ปู',     '', ROLES.SUPERVISOR],
  ['moo',  'หมู',    '', ROLES.SUPERVISOR],
  ['lek',  'เล็ก',   '', ROLES.SUPERVISOR],
  ['tuk',  'ตุ๊ก',   '', ROLES.SUPERVISOR],
  ['nong', 'นง',     '', ROLES.SUPERVISOR],
  ['aoy',  'อ้อย',   '', ROLES.SUPERVISOR],
  ['tak',  'พี่ตั๊ก', '', ROLES.SUPERVISOR],
];


/* ##################################################################
   ### 01_Lib
   ################################################################## */

/**
 * 01_Lib.gs : ฟังก์ชันช่วยจัดการ Sheet แบบ generic (mini-ORM)
 * ทุกการอ่าน/เขียนตารางผ่าน helper เหล่านี้ เพื่อให้โค้ด feature สั้นและปลอดภัย
 */

/**
 * คืน Spreadsheet ที่ใช้เป็นฐานข้อมูล
 *  - ถ้าตั้ง APP.SPREADSHEET_ID ไว้ -> เปิด Sheet นั้นด้วย openById (ต้องมีสิทธิ์ edit)
 *  - ถ้าเว้นว่าง -> ใช้ Sheet ที่สคริปต์ผูกอยู่ (container-bound)
 */
function getSpreadsheet_() {
  return APP.SPREADSHEET_ID
    ? SpreadsheetApp.openById(APP.SPREADSHEET_ID)
    : SpreadsheetApp.getActiveSpreadsheet();
}

/** คืน Sheet object ของตารางตาม SCHEMA (ต้องรัน Setup สร้างไว้ก่อน) */
function getSheet_(tableKey) {
  const def = SCHEMA[tableKey];
  if (!def) throw new Error('Unknown table: ' + tableKey);
  const ss = getSpreadsheet_();
  const sh = ss.getSheetByName(def.sheet);
  if (!sh) throw new Error('Sheet "' + def.sheet + '" does not exist yet. Please run setupDatabase() first.');
  return sh;
}

/** อ่านทั้งตารางเป็น array ของ object (key = ชื่อคอลัมน์) */
function readAll_(tableKey) {
  const sh = getSheet_(tableKey);
  const values = sh.getDataRange().getValues();
  if (values.length < 2) return [];
  const header = values[0];
  const rows = [];
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    if (row.join('') === '') continue; // ข้ามแถวว่าง
    const obj = { _row: i + 1 };        // _row = เลขแถวจริงใน sheet (ไว้ update)
    header.forEach((h, c) => { obj[h] = row[c]; });
    rows.push(obj);
  }
  return rows;
}

/** เพิ่มแถวใหม่จาก object (เรียงตาม header ใน SCHEMA) */
function appendRow_(tableKey, obj) {
  const sh = getSheet_(tableKey);
  const header = SCHEMA[tableKey].header;
  const row = header.map(h => (obj[h] !== undefined && obj[h] !== null) ? obj[h] : '');
  sh.appendRow(row);
  return obj;
}

/** อัปเดตแถว (ตามเลข _row) ด้วยค่าจาก patch object */
function updateRow_(tableKey, rowNumber, patch) {
  const sh = getSheet_(tableKey);
  const header = SCHEMA[tableKey].header;
  const range = sh.getRange(rowNumber, 1, 1, header.length);
  const current = range.getValues()[0];
  header.forEach((h, c) => {
    if (patch[h] !== undefined) current[c] = patch[h];
  });
  range.setValues([current]);
}

/**
 * ล้างข้อมูลใต้ header (แถว 2 ลงไป) โดย "ไม่ลบแถว"
 * ใช้ clearContent แทน deleteRows เพื่อเลี่ยง error "cannot delete all non-frozen rows"
 * เมื่อชีตมี frozen row 1 (header) — ทำให้ import/resync รันซ้ำได้ปลอดภัย
 */
function clearDataRows_(sh) {
  const last = sh.getLastRow();
  if (last > 1) sh.getRange(2, 1, last - 1, Math.max(1, sh.getLastColumn())).clearContent();
}

/** ค้นหาแถวแรกที่ตรงเงื่อนไข predicate (คืน object หรือ null) */
function findRow_(tableKey, predicate) {
  const all = readAll_(tableKey);
  for (const r of all) if (predicate(r)) return r;
  return null;
}

/** สร้างรหัสรันนิ่งแบบ prefix + เลขลำดับ (เช่น TK-000123) */
function genId_(prefix, tableKey, idField) {
  const all = readAll_(tableKey);
  let max = 0;
  all.forEach(r => {
    const v = String(r[idField] || '');
    const m = v.match(/(\d+)$/);
    if (m) max = Math.max(max, parseInt(m[1], 10));
  });
  return prefix + String(max + 1).padStart(6, '0');
}

/** บันทึก audit log (immutable-ish: append-only) */
function audit_(user, action, entity, entityId, detail) {
  try {
    appendRow_('AuditLog', {
      Timestamp: new Date(),
      User: user || 'system',
      Action: action,
      Entity: entity,
      EntityID: entityId,
      Detail: typeof detail === 'string' ? detail : JSON.stringify(detail || ''),
    });
  } catch (e) {
    // อย่าให้ audit ที่ล้มเหลวมาทำให้ business logic พัง
    console.warn('audit_ failed: ' + e);
  }
}

/** แปลง Date เป็น string yyyy-MM-dd ตาม timezone ของแอป (ว่าง = '') */
function fmtDate_(d) {
  if (!d) return '';
  if (!(d instanceof Date)) {
    const parsed = new Date(d);
    if (isNaN(parsed)) return String(d);
    d = parsed;
  }
  return Utilities.formatDate(d, APP.TIMEZONE, 'yyyy-MM-dd');
}

/** บวกเดือนเข้ากับวันที่ (คืน Date ใหม่) */
function addMonths_(date, months) {
  const d = new Date(date.getTime());
  d.setMonth(d.getMonth() + Number(months || 0));
  return d;
}

/** ครอบการเขียนข้อมูลด้วย ScriptLock — กัน ID ชน/แถวซ้อนเมื่อหลายคนทำพร้อมกัน */
function withLock_(fn) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(15000)) throw new Error('The system is processing another request. Please try again.');
  try { return fn(); }
  finally { lock.releaseLock(); }
}

/** ลบแถวเดียวออกจากชีต (ใช้สำหรับ CRUD delete — ต่างจาก clearDataRows_ ที่ล้างทั้งตาราง) */
function deleteSheetRow_(tableKey, rowNumber) {
  getSheet_(tableKey).deleteRow(rowNumber);
}

/**
 * แปลงค่าที่จะส่งกลับฝั่งเว็บให้ "ปลอดภัยต่อ google.script.run" เสมอ
 * (Date -> ISO string, ตัด undefined/ฟังก์ชันทิ้ง) กัน error ตอน serialize ค่ากลับ
 * ทุก response ผ่านตัวนี้ผ่าน withAuth_ -> ไม่มี endpoint ไหนคืน Date ดิบได้อีก
 */
function jsonSafe_(v) {
  if (v === undefined || v === null) return null;
  return JSON.parse(JSON.stringify(v));
}


/* ##################################################################
   ### 02_Setup
   ################################################################## */

/**
 * 02_Setup.gs : สร้าง/รีเซ็ตโครงสร้างฐานข้อมูล (ชีตทั้งหมด)
 *
 * วิธีใช้ครั้งแรก:
 *   1) เปิด Apps Script editor ที่ผูกกับ Google Sheet เปล่า 1 ไฟล์
 *   2) รันฟังก์ชัน setupDatabase()  (เมนู Run > setupDatabase)
 *   3) อนุญาตสิทธิ์ตามที่ระบบขอ
 *   4) จะได้ชีต Users/Employees/Courses/TrainingRecords/Tickets/AuditLog
 *      พร้อม header + คอร์สเริ่มต้น + บัญชี ADMIN ตัวอย่าง
 */

function setupDatabase() {
  const ss = getSpreadsheet_();
  ss.setSpreadsheetTimeZone(APP.TIMEZONE);

  Object.keys(SCHEMA).forEach(key => {
    const def = SCHEMA[key];
    let sh = ss.getSheetByName(def.sheet);
    if (!sh) sh = ss.insertSheet(def.sheet);
    // เขียน header เสมอ (idempotent)
    sh.getRange(1, 1, 1, def.header.length).setValues([def.header]);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, def.header.length).setFontWeight('bold')
      .setBackground('#1f3864').setFontColor('#ffffff');
    sh.autoResizeColumns(1, def.header.length);
  });

  // ลบชีตเริ่มต้น "Sheet1" ถ้ามีและว่าง
  const s1 = ss.getSheetByName('Sheet1');
  if (s1 && ss.getSheets().length > 1) {
    try { ss.deleteSheet(s1); } catch (e) {}
  }

  seedCourses_();
  seedAdminIfEmpty_();
  seedSupervisors_();

  getSpreadsheet_().toast('Database setup completed', 'Setup', 5);
  return 'OK: ' + Object.keys(SCHEMA).join(', ');
}

/** ใส่คอร์สเริ่มต้น (ถ้ายังไม่มี) */
function seedCourses_() {
  const existing = readAll_('Courses').map(c => String(c.CourseID));
  DEFAULT_COURSES.forEach(([id, name, months]) => {
    if (existing.indexOf(id) === -1) {
      appendRow_('Courses', { CourseID: id, CourseName: name, ValidityMonths: months });
    }
  });
}

/**
 * ล้างคอร์สเดิมทั้งหมดแล้วเขียนใหม่ให้ตรงกับ DEFAULT_COURSES
 * (ใช้แก้กรณีชีต Courses ยังเป็นคอร์สเก่า BASIC/HFO-144… ที่ไม่ตรงกับ records ใหม่)
 */
function resyncCourses_() {
  const sh = getSheet_('Courses');
  clearDataRows_(sh);
  DEFAULT_COURSES.forEach(([id, name, months]) => {
    appendRow_('Courses', { CourseID: id, CourseName: name, ValidityMonths: months });
  });
}

/** เรียกเองเพื่ออัปเดตรายการคอร์สให้ตรงปัจจุบัน (รันจากเมนู Run) */
function resyncCourses() {
  resyncCourses_();
  getSpreadsheet_().toast(
    'Courses updated to ' + DEFAULT_COURSES.length + ' items', 'Courses', 5);
  return DEFAULT_COURSES.map(c => c[0]);
}

/** สร้างบัญชี ADMIN ตัวอย่าง ถ้าตาราง Users ยังว่าง */
function seedAdminIfEmpty_() {
  if (findRow_('Users', u => String(u.EN).trim() === 'admin')) return;
  appendRow_('Users', {
    EN: 'admin', Name: 'System Admin', Role: ROLES.ADMIN,
    PIN: '1234', Email: Session.getActiveUser().getEmail() || '', Active: true,
  });
}

/** สร้างบัญชีหัวหน้างานจาก DEFAULT_SUPERVISORS (idempotent — ข้ามถ้ามี EN นั้นแล้ว) */
function seedSupervisors_() {
  const existing = {};
  readAll_('Users').forEach(u => { existing[String(u.EN).trim()] = true; });
  let added = 0;
  DEFAULT_SUPERVISORS.forEach(([en, name, email, role]) => {
    if (existing[en]) return;
    appendRow_('Users', {
      EN: en, Name: name, Role: role || ROLES.SUPERVISOR,
      PIN: '', Email: email || '', Active: true,
    });
    added++;
  });
  return added;
}

/** เรียกเองเพื่อเพิ่มบัญชีหัวหน้างานภายหลัง (รันได้จากเมนู Run) */
function seedSupervisors() {
  const n = seedSupervisors_();
  getSpreadsheet_().toast('Added ' + n + ' supervisor accounts', 'Supervisors', 5);
  return 'added ' + n + ' supervisor account(s)';
}

/** ⚠️ ล้างข้อมูลทุกตาราง (เก็บ header) — ใช้ตอนทดสอบเท่านั้น */
function resetAllData_DANGER() {
  Object.keys(SCHEMA).forEach(key => {
    clearDataRows_(getSheet_(key));
  });
  seedCourses_();
  seedAdminIfEmpty_();
  return 'cleared';
}


/* ##################################################################
   ### 03_Auth
   ################################################################## */

/**
 * 03_Auth.gs : การล็อกอินด้วยรหัสพนักงาน (EN) + PIN และตรวจสอบสิทธิ์ตาม role
 *
 * หมายเหตุความปลอดภัย:
 *  - STAFF (พนักงานทั่วไป) และ SUPERVISOR (หัวหน้างาน): ล็อกอินด้วย EN อย่างเดียว ไม่ต้องใช้ PIN
 *  - TRAINER / ADMIN (role ที่บันทึกผล/แก้ข้อมูลสำคัญ): ต้องมี PIN
 *  - token เก็บใน CacheService ฝั่ง user (อายุ 6 ชม.)
 */

const SESSION_TTL_SEC = 6 * 60 * 60;

/** ล็อกอิน: คืน {ok, token, user} หรือ {ok:false, error} */
function login(en, pin) {
  en = String(en || '').trim();
  pin = String(pin || '').trim();
  if (!en) return { ok: false, error: 'Please enter an employee ID' };

  let user = findRow_('Users', u => String(u.EN).trim() === en && u.Active !== false);

  // Fallback: ถ้าไม่มีใน Users แต่เป็นพนักงานในตาราง Employees -> ล็อกอินเป็น OPERATOR
  // (เห็นเฉพาะ Calendar / Tickets / My Records ของตัวเอง — ไม่เห็น Dashboard / Skill Matrix)
  if (!user) {
    const emp = findRow_('Employees', e => String(e.EN).trim() === en && e.Active !== false);
    if (emp) {
      user = { EN: String(emp.EN), Name: emp.NameEN || emp.NameTH || en,
               Role: ROLES.OPERATOR, PIN: '', Email: emp.Email || '', Active: true };
    }
  }
  // EN ที่ไม่มีในระบบเลย -> OPERATOR (เข้าได้เพื่อเปิด Ticket ลงทะเบียน)
  if (!user) {
    user = { EN: en, Name: en, Role: ROLES.OPERATOR, PIN: '', Email: '', Active: true };
  }

  // เฉพาะ TRAINER / ADMIN เท่านั้นที่ต้องตรวจ PIN
  // (STAFF, OPERATOR, SUPERVISOR ล็อกอินด้วย EN อย่างเดียว ไม่ต้องใช้ PIN)
  const needsPin = [ROLES.TRAINER, ROLES.ADMIN].indexOf(user.Role) !== -1;
  if (needsPin) {
    if (!user.PIN) return { ok: false, error: 'This account does not have a PIN yet. Please contact an administrator.' };
    if (String(user.PIN).trim() !== pin) return { ok: false, error: 'Incorrect PIN' };
  }

  const token = Utilities.getUuid();
  const session = { en: String(user.EN), name: user.Name, role: user.Role, email: user.Email };
  CacheService.getUserCache().put('sess_' + token, JSON.stringify(session), SESSION_TTL_SEC);
  audit_(user.EN, 'LOGIN', 'Users', user.EN, '');
  return { ok: true, token: token, user: session };
}

/** ตรวจ token -> คืน session object หรือ throw ถ้าไม่ valid */
function requireSession_(token) {
  const raw = CacheService.getUserCache().get('sess_' + token);
  if (!raw) throw new Error('Your session has expired. Please sign in again.');
  return JSON.parse(raw);
}

/** ตรวจว่า session มีสิทธิ์อยู่ในรายการ roles ที่อนุญาต */
function requireRole_(session, allowedRoles) {
  if (allowedRoles.indexOf(session.role) === -1) {
    throw new Error('You do not have permission to use this section (role: ' + session.role + ')');
  }
}

/** ออกจากระบบ */
function logout(token) {
  CacheService.getUserCache().remove('sess_' + token);
  return { ok: true };
}

/** ฟังก์ชันช่วย wrap action ที่ต้องล็อกอิน: คืน {ok,data}/{ok:false,error} */
function withAuth_(token, allowedRoles, fn) {
  try {
    const session = requireSession_(token);
    if (allowedRoles && allowedRoles.length) requireRole_(session, allowedRoles);
    return { ok: true, data: jsonSafe_(fn(session)) };
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
}


/* ##################################################################
   ### 04_Records
   ################################################################## */

/**
 * 04_Records.gs : จัดการ Training Records + คำนวณสถานะ/วันหมดอายุ
 * เป็นแหล่งข้อมูลหลักของ Skill Matrix และ Dashboard
 */

/** คำนวณสถานะ effective ของ record ณ วันนี้ (คืน RECORD_STATUS) */
function effectiveStatus_(record, now) {
  now = now || new Date();
  if (record.Status === RECORD_STATUS.FAILED) return RECORD_STATUS.FAILED;
  if (record.QualifiedDate) {
    const exp = record.ExpiryDate ? new Date(record.ExpiryDate) : null;
    if (exp && exp < now) return RECORD_STATUS.EXPIRED;
    return RECORD_STATUS.QUALIFIED;
  }
  if (record.OverviewDate) return RECORD_STATUS.IN_PROGRESS;
  return RECORD_STATUS.NOT_TRAINED;
}

/** สีของ skill matrix ตาม effective status + ระยะใกล้หมดอายุ */
function statusColor_(record, now) {
  now = now || new Date();
  const st = effectiveStatus_(record, now);
  if (st === RECORD_STATUS.QUALIFIED) {
    const exp = record.ExpiryDate ? new Date(record.ExpiryDate) : null;
    if (exp) {
      const days = Math.floor((exp - now) / 86400000);
      if (days <= APP.NEAR_EXPIRY_DAYS) return 'YELLOW'; // ใกล้หมดอายุ
    }
    return 'GREEN';
  }
  if (st === RECORD_STATUS.EXPIRED || st === RECORD_STATUS.FAILED) return 'RED';
  if (st === RECORD_STATUS.IN_PROGRESS) return 'BLUE';
  return 'GRAY'; // NOT_TRAINED / ไม่มี record
}


/**
 * บันทึก/อัปเดตผลการเทรน (เรียกโดย TRAINER/ADMIN ตอนปิด Ticket หรือแก้ผล)
 * payload: {en, courseId, overviewDate, qualifiedDate, score, status, trainer}
 * จัดการ ExpiryDate อัตโนมัติจาก qualifiedDate + ValidityMonths ของคอร์ส
 */
function upsertRecord_(payload, byUser) {
  const en = String(payload.en).trim();
  const courseId = String(payload.courseId).trim();
  if (!en || !courseId) throw new Error('EN and CourseID are required');

  const course = findRow_('Courses', c => String(c.CourseID) === courseId);
  const validity = course ? Number(course.ValidityMonths) || APP.DEFAULT_VALIDITY_MONTHS
                          : APP.DEFAULT_VALIDITY_MONTHS;

  const existing = findRow_('TrainingRecords',
    r => String(r.EN) === en && String(r.CourseID) === courseId);

  const status = payload.status || RECORD_STATUS.QUALIFIED;
  let qualified = payload.qualifiedDate ? new Date(payload.qualifiedDate) : null;
  let expiry = payload.expiryDate ? new Date(payload.expiryDate) : null;   // ตั้งวันหมดอายุตรงๆ ได้ (เช่น BASIC)

  if (status === RECORD_STATUS.QUALIFIED) {
    // ต้องมีอย่างน้อย qualified หรือ expiry (ถ้าไม่ส่งมาเลย ใช้ของเดิม)
    if (!qualified && !expiry && existing) {
      qualified = existing.QualifiedDate ? new Date(existing.QualifiedDate) : null;
      expiry = existing.ExpiryDate ? new Date(existing.ExpiryDate) : null;
    }
    if (!qualified && !expiry) throw new Error('A QUALIFIED result requires a Qualified Date or an Expiry Date');
    if (qualified && !expiry) expiry = addMonths_(qualified, validity);       // เติม expiry จาก qualified
    if (expiry && !qualified) qualified = addMonths_(expiry, -validity);      // เติม qualified ย้อนกลับจาก expiry
  }

  // OverviewDate: ใช้ที่ส่งมา ถ้าไม่มีใช้ของเดิม
  let overviewDate = payload.overviewDate ? new Date(payload.overviewDate) : (existing ? existing.OverviewDate : '');
  // IN_PROGRESS ต้องมี OverviewDate ไม่งั้น effectiveStatus_ จะกลายเป็น NOT_TRAINED (เซลล์ขึ้นสีเทาแทนสีน้ำเงิน)
  if (status === RECORD_STATUS.IN_PROGRESS && !overviewDate && !qualified) overviewDate = new Date();

  const patch = {
    EN: en,
    CourseID: courseId,
    OverviewDate: overviewDate,
    QualifiedDate: qualified || (existing ? existing.QualifiedDate : ''),
    ExpiryDate: expiry || (existing ? existing.ExpiryDate : ''),
    Status: status,
    // เก็บคะแนนเดิมถ้าไม่ได้กรอกมาใหม่ ('' = ไม่กรอก ไม่ใช่ล้างคะแนน)
    Score: (payload.score != null && payload.score !== '') ? payload.score : (existing ? existing.Score : ''),
    Trainer: payload.trainer || (existing ? existing.Trainer : ''),
    UpdatedBy: byUser,
    UpdatedAt: new Date(),
  };

  if (existing) {
    updateRow_('TrainingRecords', existing._row, patch);
    audit_(byUser, 'UPDATE_RECORD', 'TrainingRecords', existing.RecordID, patch);
    patch.RecordID = existing.RecordID;
  } else {
    patch.RecordID = genId_('RC-', 'TrainingRecords', 'RecordID');
    appendRow_('TrainingRecords', patch);
    audit_(byUser, 'CREATE_RECORD', 'TrainingRecords', patch.RecordID, patch);
  }
  return recordView_(patch); // คืน view ที่วันเป็น string (ไม่ส่ง Date ดิบกลับเว็บ)
}

/** แปลง record row/patch -> object ปลอดภัยส่งกลับเว็บ (วันเป็น yyyy-MM-dd) */
function recordView_(p) {
  return {
    recordId: p.RecordID || '', en: p.EN, courseId: p.CourseID,
    overviewDate: fmtDate_(p.OverviewDate), qualifiedDate: fmtDate_(p.QualifiedDate),
    expiryDate: fmtDate_(p.ExpiryDate), status: p.Status,
    score: p.Score, trainer: p.Trainer,
  };
}

/** ลบ training record รายแถว (TRAINER/ADMIN) — ไม่สามารถย้อนกลับได้ */
function deleteRecord_(recordId, session) {
  const rec = findRow_('TrainingRecords', r => String(r.RecordID) === String(recordId));
  if (!rec) throw new Error('Record not found: ' + recordId);
  deleteSheetRow_('TrainingRecords', rec._row);
  audit_(session.en, 'DELETE_RECORD', 'TrainingRecords', recordId,
    { en: rec.EN, courseId: rec.CourseID });
  return { recordId: String(recordId) };
}

/** ดึง records ของพนักงานคนเดียว (พร้อม effective status) */
function getRecordsByEn_(en) {
  const now = new Date();
  return readAll_('TrainingRecords')
    .filter(r => String(r.EN) === String(en))
    .map(r => ({
      recordId: r.RecordID, courseId: r.CourseID,
      overviewDate: fmtDate_(r.OverviewDate),
      qualifiedDate: fmtDate_(r.QualifiedDate),
      expiryDate: fmtDate_(r.ExpiryDate),
      score: r.Score, trainer: r.Trainer,
      status: effectiveStatus_(r, now),
      color: statusColor_(r, now),
    }));
}

/** แก้ไขข้อมูลพนักงาน (ชื่อ/ชื่อเล่น/หน้างาน/หัวหน้า) — TRAINER/ADMIN จากหน้า Skill Matrix */
function updateEmployee_(payload, session) {
  const en = String(payload.en || '').trim();
  const e = findRow_('Employees', x => String(x.EN) === en);
  if (!e) throw new Error('Employee not found: ' + en);
  const patch = {
    NameEN: (payload.name !== undefined) ? String(payload.name).trim() : e.NameEN,
    Nickname: (payload.nickname !== undefined) ? String(payload.nickname).trim() : e.Nickname,
    WorkingArea: (payload.workingArea !== undefined) ? String(payload.workingArea).trim() : e.WorkingArea,
    Supervisor: (payload.supervisor !== undefined) ? String(payload.supervisor).trim() : e.Supervisor,
  };
  updateRow_('Employees', e._row, patch);
  audit_(session.en, 'UPDATE_EMPLOYEE', 'Employees', en, patch);
  return { en: en };
}


/* ##################################################################
   ### 05_Tickets
   ################################################################## */

/**
 * 05_Tickets.gs : ระบบ Ticketing สำหรับขอเข้าเทรน
 * STAFF เปิดของตัวเอง / SUPERVISOR เปิดแทนทีม / TRAINER รับงาน+ปิดงาน
 */

/** คอร์สที่เปิดผ่าน Ticket ได้ (ตัด NON_TICKET_COURSES เช่น BASIC ออก) */
function ticketCourses_() {
  return readAll_('Courses')
    .filter(c => NON_TICKET_COURSES.indexOf(String(c.CourseID)) === -1)
    .map(c => ({ courseId: String(c.CourseID), courseName: c.CourseName }));
}

/** สร้าง Ticket ใหม่ (opts.notify=false เพื่อปิดอีเมล เช่นตอน bulk import) */
function createTicket_(payload, session, opts) {
  opts = opts || {};
  const en = String(payload.en || session.en).trim();
  const courseId = String(payload.courseId).trim();
  if (!en) throw new Error('Please enter an employee ID (EN)');
  if (!courseId) throw new Error('Please select a course');
  // คอร์สต้องเปิดผ่าน Ticket ได้ (กัน BASIC / CourseID ที่ไม่มีจริง)
  if (ticketCourses_().map(c => c.courseId).indexOf(courseId) === -1) {
    throw new Error('Course "' + courseId + '" cannot be requested via a ticket');
  }

  // STAFF / OPERATOR เปิดได้เฉพาะของตัวเอง
  if ((session.role === ROLES.STAFF || session.role === ROLES.OPERATOR) && en !== String(session.en)) {
    throw new Error('You can only open tickets for yourself');
  }

  // ถ้าไม่พบพนักงานในระบบ -> เพิ่มพนักงานใหม่จากข้อมูลที่กรอกมา (ต้องมีชื่ออย่างน้อย)
  let emp = findRow_('Employees', e => String(e.EN) === en);
  if (!emp) {
    const name = String(payload.name || '').trim();
    if (!name) {
      throw new Error('Employee ID ' + en + ' was not found. Please enter the employee name to add them to the system.');
    }
    appendRow_('Employees', {
      EN: en, NameEN: name, NameTH: '',
      Nickname: String(payload.nickname || '').trim(),
      WorkingArea: String(payload.workingArea || '').trim(),
      Supervisor: String(payload.supervisor || '').trim(),
      SplicingExp: '', Email: '', Active: true,
    });
    audit_(session.en, 'CREATE_EMPLOYEE', 'Employees', en, { via: 'ticket' });
    emp = findRow_('Employees', e => String(e.EN) === en);
  }

  const id = genId_('TK-', 'Tickets', 'TicketID');
  const now = new Date();
  const ticket = {
    TicketID: id, EN: en, CourseID: courseId,
    RequestedBy: session.en, RequestDate: now,
    PreferredDate: payload.preferredDate ? new Date(payload.preferredDate) : '',
    Status: TICKET_STATUS.OPEN, AssignedTrainer: '',
    Notes: payload.notes || '', CreatedAt: now, UpdatedAt: now,
  };
  appendRow_('Tickets', ticket);
  audit_(session.en, 'CREATE_TICKET', 'Tickets', id, { en: en, courseId: courseId });
  const view = ticketView_(ticket);
  if (opts.notify !== false) {
    try { notifyTicketOpened_(view, session); } catch (e) { console.warn('notifyTicketOpened_ failed: ' + e); }
  }
  return view;
}

/** เปลี่ยนสถานะ Ticket / มอบหมายเทรนเนอร์ (TRAINER/ADMIN) */
function updateTicket_(payload, session) {
  const t = findRow_('Tickets', x => String(x.TicketID) === String(payload.ticketId));
  if (!t) throw new Error('Ticket not found: ' + payload.ticketId);
  const oldPreferredDate = fmtDate_(t.PreferredDate);
  const isReschedule = payload.rescheduleNote !== undefined;
  if (isReschedule) {
    const reschedulable = [TICKET_STATUS.OPEN, TICKET_STATUS.SCHEDULED, TICKET_STATUS.IN_PROGRESS];
    if (reschedulable.indexOf(t.Status) === -1) {
      throw new Error('Cannot reschedule a ticket with status: ' + t.Status);
    }
  }

  // ตรวจผลก่อนแก้ไข (กันอัปเดต ticket สำเร็จแต่บันทึกผลพัง)
  if (payload.status === TICKET_STATUS.COMPLETED && payload.result) {
    const rs = payload.result.status || RECORD_STATUS.QUALIFIED;
    if (rs === RECORD_STATUS.QUALIFIED && !payload.result.qualifiedDate) {
      throw new Error('A QUALIFIED result requires a Qualified Date');
    }
  }

  const patch = { UpdatedAt: new Date() };
  if (payload.status) {
    if (!TICKET_STATUS[payload.status]) throw new Error('Invalid status');
    patch.Status = payload.status;
  }
  if (payload.assignedTrainer !== undefined) patch.AssignedTrainer = payload.assignedTrainer;
  if (payload.preferredDate !== undefined)
    patch.PreferredDate = payload.preferredDate ? new Date(payload.preferredDate) : '';
  if (payload.notes !== undefined) patch.Notes = payload.notes;

  updateRow_('Tickets', t._row, patch);

  // ปิดงาน + มีผลประเมิน -> บันทึก Training Record ให้อัตโนมัติ
  let rec = null;
  if (patch.Status === TICKET_STATUS.COMPLETED && payload.result) {
    rec = upsertRecord_({
      en: t.EN, courseId: t.CourseID,
      overviewDate: payload.result.overviewDate,
      qualifiedDate: payload.result.qualifiedDate,
      score: payload.result.score,
      status: payload.result.status || RECORD_STATUS.QUALIFIED,
      trainer: patch.AssignedTrainer || t.AssignedTrainer || session.name,
    }, session.en);
  }

  audit_(session.en, 'UPDATE_TICKET', 'Tickets', t.TicketID, patch);
  const view = ticketView_(Object.assign({}, t, patch));

  // อีเมลแจ้งเตือน (ส่งเฉพาะตอน "เปลี่ยนเข้า" สถานะนั้น เพื่อไม่ส่งซ้ำ)
  try {
    if (isReschedule && patch.PreferredDate !== undefined &&
        fmtDate_(patch.PreferredDate) !== oldPreferredDate) {
      // เลื่อนนัด: trainer เปลี่ยนวัน → ส่งอีเมล reschedule แทน scheduled
      notifyTicketRescheduled_(view, session, oldPreferredDate, payload.rescheduleNote);
    } else if (patch.Status === TICKET_STATUS.SCHEDULED && t.Status !== TICKET_STATUS.SCHEDULED) {
      // นัดครั้งแรก: OPEN/อื่นๆ → SCHEDULED
      notifyTicketScheduled_(view, session);
    } else if (patch.Status === TICKET_STATUS.CANCELLED && t.Status !== TICKET_STATUS.CANCELLED) {
      // ยกเลิก: แจ้งพนักงาน + หัวหน้า
      notifyTicketCancelled_(view, session);
    }
    if (rec && t.Status !== TICKET_STATUS.COMPLETED) {
      notifyTicketResult_(view, rec, session);
    }
  } catch (e) { console.warn('ticket notify failed: ' + e); }

  return view;
}

/** คืน array ของ EN ที่ SUPERVISOR มีสิทธิ์ดู (ตัวเอง + ลูกทีม) */
function getTeamENs_(session, empRows) {
  empRows = empRows || readAll_('Employees');
  const team = empRows
    .filter(e => String(e.Supervisor) === String(session.name) ||
                 String(e.Supervisor) === String(session.en))
    .map(e => String(e.EN));
  team.push(String(session.en));
  return team;
}

/** รายการ Ticket ตาม role: STAFF เห็นของตัวเอง / SUP เห็นทีม / TRAINER+ADMIN เห็นหมด */
function listTickets_(session, filter) {
  filter = filter || {};
  let rows = readAll_('Tickets');

  if (session.role === ROLES.STAFF || session.role === ROLES.OPERATOR) {
    rows = rows.filter(t => String(t.EN) === String(session.en));
  } else if (session.role === ROLES.SUPERVISOR) {
    const team = getTeamENs_(session, readAll_('Employees'));
    rows = rows.filter(t => team.indexOf(String(t.EN)) !== -1);
  }
  if (filter.status) rows = rows.filter(t => t.Status === filter.status);

  rows.sort((a, b) => new Date(b.CreatedAt) - new Date(a.CreatedAt));
  const recMap = {};
  readAll_('TrainingRecords').forEach(r => { recMap[String(r.EN) + '|' + String(r.CourseID)] = r; });
  return rows.map(t => ticketView_(t, recMap));
}

/** แปลง row เป็น view object (อ่านง่ายฝั่ง frontend)
 *  recMap: optional map ของ "EN|CourseID" -> TrainingRecord row (ป้องกัน N+1 ใน listTickets_) */
function ticketView_(t, recMap) {
  const emp = findRow_('Employees', e => String(e.EN) === String(t.EN));
  const course = findRow_('Courses', c => String(c.CourseID) === String(t.CourseID));
  const view = {
    ticketId: t.TicketID, en: t.EN,
    name: emp ? (emp.NameEN || emp.NameTH) : t.EN,
    nickname: emp ? emp.Nickname : '',
    workingArea: emp ? emp.WorkingArea : '',
    supervisor: emp ? emp.Supervisor : '',
    courseId: t.CourseID, courseName: course ? course.CourseName : t.CourseID,
    requestedBy: t.RequestedBy, requestDate: fmtDate_(t.RequestDate),
    preferredDate: fmtDate_(t.PreferredDate), status: t.Status,
    assignedTrainer: t.AssignedTrainer, notes: t.Notes,
  };
  if (t.Status === TICKET_STATUS.COMPLETED && recMap) {
    const rec = recMap[String(t.EN) + '|' + String(t.CourseID)];
    if (rec) {
      view.overviewDate = fmtDate_(rec.OverviewDate);
      view.qualifiedDate = fmtDate_(rec.QualifiedDate);
      view.score = rec.Score;
      view.resultStatus = rec.Status;
    }
  }
  return view;
}

/**
 * ตรวจความถูกต้องของแถวก่อนนำเข้า (ไม่เขียนข้อมูล) — คืนสถานะรายแถว
 * แต่ละ row = {en, name, nickname, workingArea, supervisor, courseId, preferredDate, notes, _row}
 */
function previewBulkTickets_(rows, session) {
  rows = rows || [];
  if (rows.length > 200) throw new Error('You can import up to 200 rows at a time. Found ' + rows.length + ' rows. Please split the file.');
  const courseSet = {};
  ticketCourses_().forEach(c => { courseSet[c.courseId] = true; }); // เฉพาะคอร์สที่เปิด Ticket ได้ (ไม่รวม BASIC)
  const empSet = {};
  readAll_('Employees').forEach(e => { empSet[String(e.EN)] = true; });

  return rows.map((r, i) => {
    const en = String(r.en || '').trim();
    const courseId = String(r.courseId || '').trim();
    const name = String(r.name || '').trim();
    const pref = String(r.preferredDate || '').trim();
    const errs = [];
    if (!en) errs.push('Missing EN');
    if (!courseId) errs.push('Missing course');
    else if (!courseSet[courseId]) errs.push('Invalid CourseID');
    const isNew = !!(en && !empSet[en]);
    if (isNew && !name) errs.push('New employee requires a name');
    if (pref && !/^\d{4}-\d{2}-\d{2}$/.test(pref) && isNaN(new Date(pref)))
      errs.push('Invalid preferred date (YYYY-MM-DD)');

    return {
      rowNum: r._row || (i + 2), en: en, name: name,
      nickname: String(r.nickname || '').trim(), workingArea: String(r.workingArea || '').trim(),
      supervisor: String(r.supervisor || '').trim(), courseId: courseId,
      preferredDate: pref, notes: String(r.notes || '').trim(),
      isNew: isNew, valid: errs.length === 0, message: errs.join(', '),
    };
  });
}

/**
 * สร้างไฟล์ Excel template สำหรับ Bulk Import ที่มี "dropdown CourseID จริง"
 *  - สร้าง Spreadsheet ชั่วคราว -> ใส่ data validation (requireValueInList) คอลัมน์ CourseID
 *  - export เป็น xlsx ผ่าน Drive export endpoint -> คืน base64
 *  - ลบไฟล์ชั่วคราวทิ้งทุกครั้ง (try/finally)
 */
function buildTicketTemplateXlsx_() {
  const coursesRows = ticketCourses_(); // เฉพาะคอร์สที่เปิด Ticket ได้ (ไม่รวม BASIC)
  const courseIds = coursesRows.map(c => c.courseId);
  const headers = ['EN', 'Employee Name', 'Nickname', 'Work Area', 'Supervisor',
                   'CourseID', 'Preferred Date (YYYY-MM-DD)', 'Notes'];
  const example = ['67012345', 'New Employee Example', 'Nick', 'Area A', 'Supervisor A',
                   courseIds[0] || '', '2026-07-01', 'Example row - delete before uploading'];

  const tmp = SpreadsheetApp.create('ticket_template_tmp_' + Date.now());
  try {
    const sh = tmp.getActiveSheet();
    sh.setName('Training Requests');
    // Row 1: headers
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    // Row 2: instruction note — EN (column A) ว่างเปล่า ดังนั้น aoaToObjs_ จะ skip row นี้ตอน import
    const noteRange = sh.getRange(2, 2, 1, headers.length - 1); // B2:H2
    noteRange.merge();
    noteRange.setValue('📌 กรุณาเปิดคำขอล่วงหน้าอย่างน้อย 7 วัน ก่อนวันฝึกอบรม  /  Please submit requests at least 7 days before the training date');
    sh.getRange(2, 1, 1, headers.length).setBackground('#fff8e1').setFontColor('#5a4500').setFontWeight('bold');
    // Row 3: example row
    sh.getRange(3, 1, 1, headers.length).setValues([example]);
    sh.getRange(3, 1, 1, headers.length).setBackground('#f0f3fa').setFontColor('#999999').setFontStyle('italic');
    sh.setFrozenRows(1);

    // dropdown บนคอลัมน์ CourseID (คอลัมน์ที่ 6) แถว 3 เป็นต้นไป (row 2 = note ไม่ต้องการ dropdown)
    if (courseIds.length) {
      const rule = SpreadsheetApp.newDataValidation()
        .requireValueInList(courseIds, true)
        .setAllowInvalid(false)
        .setHelpText('Select a CourseID from the list')
        .build();
      sh.getRange(3, 6, 500, 1).setDataValidation(rule);
    }

    // ชีตอ้างอิง CourseID -> ชื่อคอร์ส
    const ref = tmp.insertSheet('CourseID Reference');
    ref.getRange(1, 1, 1, 2).setValues([['CourseID', 'Course Name']]);
    const cdata = coursesRows.map(c => [c.courseId, c.courseName]);
    if (cdata.length) ref.getRange(2, 1, cdata.length, 2).setValues(cdata);

    SpreadsheetApp.flush();

    // export เป็น xlsx ผ่าน endpoint ของ Google Sheets (ใช้ OAuth token ของสคริปต์)
    const url = 'https://docs.google.com/spreadsheets/d/' + tmp.getId() + '/export?format=xlsx';
    const resp = UrlFetchApp.fetch(url, {
      headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
      muteHttpExceptions: true,
    });
    if (resp.getResponseCode() !== 200) throw new Error('Template export failed (' + resp.getResponseCode() + ')');
    return {
      filename: 'training_request_template.xlsx',
      b64: Utilities.base64Encode(resp.getBlob().getBytes()),
    };
  } finally {
    try { DriveApp.getFileById(tmp.getId()).setTrashed(true); } catch (e) {}
  }
}

/**
 * parse ไฟล์อัปโหลด (base64) -> array ของ {en,name,...} ฝั่ง server
 *  - .csv  : Utilities.parseCsv (ไม่ต้องใช้ไลบรารี)
 *  - .xlsx : แปลงเป็น Google Sheet ชั่วคราวด้วย Drive (convert) แล้วอ่าน -> ลบทิ้ง
 *  ทำให้ใช้ได้แม้เน็ตบริษัทบล็อก CDN ของ SheetJS
 */
function parseUploadToObjs_(b64, name) {
  const bytes = Utilities.base64Decode(b64);
  const lower = String(name || '').toLowerCase();
  if (lower.slice(-4) === '.csv') {
    return aoaToObjs_(Utilities.parseCsv(Utilities.newBlob(bytes).getDataAsString('UTF-8')));
  }
  // xlsx/xls -> upload + convert เป็น Google Sheet ผ่าน Drive REST (UrlFetch) แล้วอ่าน -> ลบ
  // ใช้ scope เดิม (Drive + UrlFetch) ไม่ต้องเปิด Advanced Drive Service
  const fileId = driveConvertToSheet_(bytes, lower);
  try {
    const aoa = SpreadsheetApp.openById(fileId).getSheets()[0].getDataRange().getValues();
    return aoaToObjs_(aoa);
  } finally {
    try { DriveApp.getFileById(fileId).setTrashed(true); } catch (e) {}
  }
}

/** อัปโหลด bytes (xlsx/xls) ไป Drive แบบ convert เป็น Google Sheet -> คืน fileId */
function driveConvertToSheet_(bytes, lower) {
  const mediaType = (lower.slice(-4) === '.xls')
    ? 'application/vnd.ms-excel'
    : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  const boundary = '----trxform' + Date.now();
  const meta = { name: 'tmp_import_' + Date.now(), mimeType: 'application/vnd.google-apps.spreadsheet' };
  const pre = Utilities.newBlob(
    '--' + boundary + '\r\n' +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(meta) + '\r\n' +
    '--' + boundary + '\r\n' +
    'Content-Type: ' + mediaType + '\r\n\r\n').getBytes();
  const post = Utilities.newBlob('\r\n--' + boundary + '--').getBytes();
  const payload = pre.concat(bytes).concat(post);
  const resp = UrlFetchApp.fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id', {
      method: 'post',
      contentType: 'multipart/related; boundary=' + boundary,
      payload: Utilities.newBlob(payload),
      headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
      muteHttpExceptions: true,
    });
  if (resp.getResponseCode() !== 200) {
    throw new Error('File conversion failed (' + resp.getResponseCode() + '). Please try a .csv file.');
  }
  return JSON.parse(resp.getContentText()).id;
}

/** แปลง 2D array (แถวแรก = header) -> array ของ object ตามคอลัมน์ template */
function aoaToObjs_(aoa) {
  const s = v => (v instanceof Date) ? fmtDate_(v) : String(v == null ? '' : v).trim();
  const out = [];
  for (let i = 1; i < (aoa || []).length; i++) {
    const r = aoa[i] || [];
    const en = s(r[0]);
    if (!en) continue;
    out.push({
      _row: i + 1, en: en, name: s(r[1]), nickname: s(r[2]), workingArea: s(r[3]),
      supervisor: s(r[4]), courseId: s(r[5]), preferredDate: s(r[6]), notes: s(r[7]),
    });
  }
  return out;
}

/** สร้าง Ticket จากหลายแถว (ใช้ createTicket_ เดิม ทีละแถว, เก็บ error รายแถว) */
function createBulkTickets_(rows, session) {
  rows = rows || [];
  if (rows.length > 200) throw new Error('You can import up to 200 rows at a time');
  const createdViews = [];
  const errors = [];
  rows.forEach((r, i) => {
    try { createdViews.push(createTicket_(r, session, { notify: false })); }   // ปิดอีเมลรายแถว เก็บ view ไว้
    catch (e) { errors.push({ rowNum: r.rowNum || r._row || (i + 2), error: String(e.message || e) }); }
  });
  const created = createdViews.length;
  if (created > 0) {
    try { notifyBulkTicketsOpened_(createdViews, session); } catch (e) { console.warn('bulk notify failed: ' + e); }
  }
  audit_(session.en, 'BULK_CREATE_TICKETS', 'Tickets', '',
    { created: created, failed: errors.length });
  return { created: created, failed: errors.length, errors: errors };
}


/* ##################################################################
   ### 06_SkillMatrix
   ################################################################## */

/**
 * 06_SkillMatrix.gs : Skill Matrix / Competency Map (ฟีเจอร์เด่นที่สุดของ Phase 1)
 * ตาราง พนักงาน × คอร์ส แสดงสีสถานะ เพื่อให้หัวหน้างานวางกำลังคนได้ทันที
 */

/**
 * คืนข้อมูล matrix:
 * {
 *   courses: [{courseId, courseName}],
 *   rows: [{en, name, nickname, workingArea, supervisor, cells:{courseId:{status,color,expiryDate}}}],
 *   legend: {...}
 * }
 * filter: {workingArea, supervisor, courseId, color}  (optional)
 */
function buildSkillMatrix_(session, filter) {
  filter = filter || {};
  const now = new Date();
  const courses = readAll_('Courses')
    .map(c => ({ courseId: String(c.CourseID), courseName: c.CourseName }));

  // index records: key = EN|CourseID
  const recIndex = {};
  readAll_('TrainingRecords').forEach(r => {
    recIndex[String(r.EN) + '|' + String(r.CourseID)] = r;
  });

  let employees = readAll_('Employees').filter(e => e.Active !== false);

  // SUPERVISOR เห็นเฉพาะทีมตัวเอง
  if (session.role === ROLES.SUPERVISOR) {
    employees = employees.filter(e =>
      String(e.Supervisor) === String(session.name) ||
      String(e.Supervisor) === String(session.en));
  }
  if (filter.workingArea) employees = employees.filter(e => String(e.WorkingArea) === filter.workingArea);
  if (filter.supervisor) employees = employees.filter(e => String(e.Supervisor) === filter.supervisor);

  const rows = employees.map(e => {
    const cells = {};
    courses.forEach(c => {
      const rec = recIndex[String(e.EN) + '|' + c.courseId];
      if (rec) {
        cells[c.courseId] = {
          recordId: rec.RecordID,
          status: effectiveStatus_(rec, now),
          color: statusColor_(rec, now),
          expiryDate: fmtDate_(rec.ExpiryDate),
          qualifiedDate: fmtDate_(rec.QualifiedDate),
          overviewDate: fmtDate_(rec.OverviewDate),
          score: rec.Score,
        };
      } else {
        cells[c.courseId] = { status: RECORD_STATUS.NOT_TRAINED, color: 'GRAY', expiryDate: '' };
      }
    });
    return {
      en: String(e.EN), name: e.NameEN || e.NameTH, nickname: e.Nickname,
      workingArea: e.WorkingArea, supervisor: e.Supervisor, cells: cells,
    };
  });

  // กรองตามคอร์ส+สี (เช่น อยากเห็นเฉพาะคนที่ HFO-145 ใกล้หมดอายุ)
  let outRows = rows;
  if (filter.courseId && filter.color) {
    outRows = rows.filter(r => r.cells[filter.courseId] &&
      r.cells[filter.courseId].color === filter.color);
  }

  return {
    courses: courses,
    rows: outRows,
    total: outRows.length,
    legend: {
      GREEN: 'Qualified', YELLOW: 'Near expiry (≤' + APP.NEAR_EXPIRY_DAYS + ' days)',
      RED: 'Expired / failed', BLUE: 'In training', GRAY: 'Not trained',
    },
  };
}

/** ตัวเลือกฟิลเตอร์ (working area / supervisor) สำหรับ dropdown */
function matrixFilterOptions_() {
  const emps = readAll_('Employees').filter(e => e.Active !== false);
  const areas = {}, sups = {};
  emps.forEach(e => {
    if (e.WorkingArea) areas[String(e.WorkingArea)] = true;
    if (e.Supervisor) sups[String(e.Supervisor)] = true;
  });
  return { workingAreas: Object.keys(areas).sort(), supervisors: Object.keys(sups).sort() };
}


/* ##################################################################
   ### 07_Dashboard
   ################################################################## */

/**
 * 07_Dashboard.gs : สรุปตัวเลขแบบ real-time สำหรับหน้า Dashboard
 */

function buildDashboard_(session) {
  const now = new Date();
  const employees = readAll_('Employees').filter(e => e.Active !== false);
  const records = readAll_('TrainingRecords');
  const tickets = readAll_('Tickets');
  const courses = readAll_('Courses');

  // นับสถานะใบเซอร์รวมทุก record (แยก in-progress เป็น New/Refresher สำหรับกราฟโดนัท)
  const certCount = { QUALIFIED: 0, EXPIRED: 0, NEAR_EXPIRY: 0, IN_PROGRESS: 0, FAILED: 0 };
  records.forEach(r => {
    const st = effectiveStatus_(r, now);
    const color = statusColor_(r, now);
    if (st === RECORD_STATUS.QUALIFIED && color === 'YELLOW') certCount.NEAR_EXPIRY++;
    else if (certCount[st] !== undefined) certCount[st]++;
  });

  // นับ ticket ตามสถานะ
  const ticketCount = {};
  Object.keys(TICKET_STATUS).forEach(k => ticketCount[k] = 0);
  tickets.forEach(t => { if (ticketCount[t.Status] !== undefined) ticketCount[t.Status]++; });

  // สรุปต่อคอร์ส: qualified / near / expired / nottrained
  const perCourse = courses.map(c => {
    const cid = String(c.CourseID);
    let q = 0, near = 0, exp = 0, inProgress = 0;
    const trained = {};
    records.filter(r => String(r.CourseID) === cid).forEach(r => {
      trained[String(r.EN)] = true;
      const st = effectiveStatus_(r, now);
      const color = statusColor_(r, now);
      if (st === RECORD_STATUS.QUALIFIED && color === 'YELLOW') near++;
      else if (st === RECORD_STATUS.QUALIFIED) q++;
      else if (st === RECORD_STATUS.EXPIRED || st === RECORD_STATUS.FAILED) exp++;
      else if (st === RECORD_STATUS.IN_PROGRESS) inProgress++; // กำลังเทรน — ต้องนับด้วย ไม่งั้นหายไปจากสรุป
    });
    const notTrained = employees.filter(e => !trained[String(e.EN)]).length;
    return { courseId: cid, courseName: c.CourseName, qualified: q,
             nearExpiry: near, expired: exp, inProgress: inProgress, notTrained: notTrained };
  });

  return {
    totals: {
      employees: employees.length,
      records: records.length,
      openTickets: ticketCount.OPEN + ticketCount.SCHEDULED + ticketCount.IN_PROGRESS,
    },
    certCount: certCount,
    ticketCount: ticketCount,
    perCourse: perCourse,
    generatedAt: fmtDate_(now),
  };
}

/**
 * ข้อมูลกราฟย้อนหลังสำหรับหน้า Dashboard
 *  - series : เส้นแนวโน้ม "จำนวนใบเซอร์ Qualified ที่ยัง active" ตามช่วงเวลา (sample เป็นจุดๆ)
 *  - pie    : สัดส่วนสถานะใบเซอร์ปัจจุบัน (Qualified/ใกล้หมด/หมดอายุ/กำลังเทรน)
 * months : จำนวนเดือนย้อนหลัง (1/3/6/12)
 */
function buildDashboardCharts_(months) {
  months = Number(months) || 1;
  const now = new Date();
  const start = addMonths_(now, -months);
  const records = readAll_('TrainingRecords');

  // เก็บเฉพาะ record ที่เคย qualified (มีวัน qualified) และไม่ FAILED
  const certs = [];
  records.forEach(r => {
    if (r.Status === RECORD_STATUS.FAILED || !r.QualifiedDate) return;
    certs.push({
      q: new Date(r.QualifiedDate),
      e: r.ExpiryDate ? new Date(r.ExpiryDate) : null,
    });
  });

  // นับ "ใบเซอร์ที่ active" ณ วันที่ d (qualified แล้ว และยังไม่หมดอายุ)
  function activeAt(d) {
    let n = 0;
    for (let i = 0; i < certs.length; i++) {
      const c = certs[i];
      if (c.q <= d && (!c.e || c.e > d)) n++;
    }
    return n;
  }

  // sample เป็นจุดๆ ตามช่วง (ถี่ขึ้นเมื่อช่วงสั้น) -> เส้นแนวโน้มเรียบ ดูง่าย
  const stepDays = months <= 1 ? 2 : (months <= 3 ? 5 : (months <= 6 ? 10 : 15));
  const series = [];
  let cur = new Date(start.getTime());
  while (cur < now) {
    series.push({ label: fmtDate_(cur), value: activeAt(cur) });
    cur = new Date(cur.getTime() + stepDays * 86400000);
  }
  series.push({ label: fmtDate_(now), value: activeAt(now) }); // จุดสุดท้าย = ปัจจุบันเสมอ

  // pie: สถานะปัจจุบัน
  const pie = { QUALIFIED: 0, NEAR_EXPIRY: 0, EXPIRED: 0, IN_PROGRESS: 0 };
  records.forEach(r => {
    const st = effectiveStatus_(r, now);
    const color = statusColor_(r, now);
    if (st === RECORD_STATUS.QUALIFIED && color === 'YELLOW') pie.NEAR_EXPIRY++;
    else if (st === RECORD_STATUS.QUALIFIED) pie.QUALIFIED++;
    else if (st === RECORD_STATUS.EXPIRED) pie.EXPIRED++;
    else if (st === RECORD_STATUS.IN_PROGRESS) pie.IN_PROGRESS++;
  });

  return {
    months: months, series: series, pie: pie,
    rangeStart: fmtDate_(start), rangeEnd: fmtDate_(now),
  };
}


/* ##################################################################
   ### 08_Api
   ################################################################## */

/**
 * 08_Api.gs : จุดเชื่อมต่อสาธารณะที่ frontend เรียกผ่าน google.script.run
 * ทุก endpoint คืนรูปแบบ {ok:true, data} หรือ {ok:false, error}
 * (login/logout อยู่ใน 03_Auth.gs)
 */

// ---------- ข้อมูลตั้งต้นหลังล็อกอิน ----------
function apiBootstrap(token) {
  return withAuth_(token, [], (s) => {
    ensureCourses_(); // กันชีต Courses ค้างคอร์สเก่า -> sync ให้ตรง DEFAULT_COURSES อัตโนมัติ
    return {
      user: s,
      courses: readAll_('Courses').map(c => ({ courseId: String(c.CourseID), courseName: c.CourseName })),
      ticketCourses: ticketCourses_(), // คอร์สที่เปิด Ticket ได้ (ไม่รวม BASIC)
      filterOptions: matrixFilterOptions_(),
    };
  });
}

/** เพิ่มเฉพาะคอร์สใน DEFAULT_COURSES ที่ขาดหายไป — ไม่ลบคอร์สที่ Admin เพิ่มเอง */
function ensureCourses_() {
  const existing = new Set(readAll_('Courses').map(c => String(c.CourseID)));
  DEFAULT_COURSES.forEach(function(row) {
    if (!existing.has(String(row[0]))) {
      appendRow_('Courses', { CourseID: row[0], CourseName: row[1], ValidityMonths: row[2] });
    }
  });
}

// ---------- Dashboard ----------
function apiDashboard(token) {
  return withAuth_(token, [], (s) => buildDashboard_(s));
}
function apiDashboardCharts(token, months) {
  return withAuth_(token, [], () => buildDashboardCharts_(months));
}

// ---------- Skill Matrix ----------
function apiSkillMatrix(token, filter) {
  // STAFF เข้าถึงได้เหมือน SUPERVISOR (เห็นภาพรวมทั้งหมด — สิทธิ์แก้ไขยังจำกัด TRAINER/ADMIN)
  return withAuth_(token, [ROLES.STAFF, ROLES.SUPERVISOR, ROLES.TRAINER, ROLES.ADMIN],
    (s) => buildSkillMatrix_(s, filter));
}

// ---------- Tickets ----------
function apiListTickets(token, filter) {
  return withAuth_(token, [], (s) => listTickets_(s, filter));
}
function apiCreateTicket(token, payload) {
  return withAuth_(token, [ROLES.STAFF, ROLES.OPERATOR, ROLES.SUPERVISOR, ROLES.TRAINER, ROLES.ADMIN],
    (s) => withLock_(() => createTicket_(payload, s)));
}
function apiUpdateTicket(token, payload) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN],
    (s) => withLock_(() => updateTicket_(payload, s)));
}
// นำเข้า Ticket หลายแถวจากไฟล์ CSV/Excel (parse ฝั่ง browser แล้วส่ง rows มา)
function apiBulkPreviewTickets(token, rows) {
  return withAuth_(token, [ROLES.SUPERVISOR, ROLES.TRAINER, ROLES.ADMIN],
    (s) => previewBulkTickets_(rows, s));
}
function apiBulkCreateTickets(token, rows) {
  return withAuth_(token, [ROLES.SUPERVISOR, ROLES.TRAINER, ROLES.ADMIN],
    (s) => withLock_(() => createBulkTickets_(rows, s)));
}
// สร้างไฟล์ template (.xlsx) ที่มี dropdown CourseID จริง -> คืน base64 ให้เว็บดาวน์โหลด
function apiTicketTemplateXlsx(token) {
  return withAuth_(token, [ROLES.SUPERVISOR, ROLES.TRAINER, ROLES.ADMIN],
    () => buildTicketTemplateXlsx_());
}
// parse ไฟล์ที่อัปโหลด (base64) ฝั่ง server -> คืน rows (ไม่ต้องพึ่ง SheetJS/CDN ฝั่ง browser)
function apiBulkParseFile(token, b64, name) {
  return withAuth_(token, [ROLES.SUPERVISOR, ROLES.TRAINER, ROLES.ADMIN],
    () => parseUploadToObjs_(b64, name));
}

// ---------- Training Records ----------
function apiMyRecords(token, en) {
  return withAuth_(token, [], (s) => {
    let target = en || s.en;
    if (s.role === ROLES.STAFF || s.role === ROLES.OPERATOR) {
      target = s.en;                       // STAFF / OPERATOR ดูได้เฉพาะตัวเอง
    } else if (s.role === ROLES.SUPERVISOR && String(target) !== String(s.en)) {
      // SUPERVISOR ดูได้เฉพาะคนในทีมตัวเอง
      const emp = findRow_('Employees', e => String(e.EN) === String(target));
      const inTeam = emp && (String(emp.Supervisor) === String(s.name) ||
                             String(emp.Supervisor) === String(s.en));
      if (!inTeam) throw new Error('You can only view employees in your team');
    }
    return getRecordsByEn_(target);
  });
}
function apiUpsertRecord(token, payload) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN],
    (s) => withLock_(() => upsertRecord_(payload, s.en)));
}
function apiDeleteRecord(token, recordId) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN],
    (s) => withLock_(() => deleteRecord_(recordId, s)));
}
function apiUpdateEmployee(token, payload) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN],
    (s) => withLock_(() => updateEmployee_(payload, s)));
}

// ---------- Employees (lookup) ----------
function apiFindEmployee(token, en) {
  return withAuth_(token, [], (s) => {
    en = String(en).trim();
    if ((s.role === ROLES.STAFF || s.role === ROLES.OPERATOR) && en !== String(s.en)) {
      throw new Error('You can only view your own employee data');
    }
    const e = findRow_('Employees', x => String(x.EN) === en);
    if (!e) throw new Error('Employee ID not found: ' + en);
    return { en: String(e.EN), nameEN: e.NameEN, nameTH: e.NameTH,
             nickname: e.Nickname, workingArea: e.WorkingArea, supervisor: e.Supervisor };
  });
}

// ---------- Users management (TRAINER / ADMIN) ----------
function apiListUsers(token) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN], () => listUsers_());
}
function apiCreateUser(token, payload) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN], (s) => withLock_(() => createUser_(payload, s)));
}
function apiUpdateUser(token, payload) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN], (s) => withLock_(() => updateUser_(payload, s)));
}


/* ##################################################################
   ### 08b_Users (ADMIN จัดการบัญชีผู้ใช้ — สร้างเทรนเนอร์/หัวหน้า/แอดมิน)
   ################################################################## */

/** ตรวจรูปแบบ PIN: ตัวเลข 4–6 หลัก */
function validatePin_(pin) {
  return /^\d{4,6}$/.test(String(pin || '').trim());
}

/** role นี้ต้องมี PIN ไหม (TRAINER/ADMIN ต้องมี) */
function roleNeedsPin_(role) {
  return role === ROLES.TRAINER || role === ROLES.ADMIN;
}

/** รายชื่อผู้ใช้ทั้งหมด (ไม่ส่ง PIN จริงออกไป — บอกแค่ว่ามี/ไม่มี) */
function listUsers_() {
  return readAll_('Users').map(u => ({
    en: String(u.EN), name: u.Name, role: u.Role,
    hasPin: !!String(u.PIN || '').trim(),
    email: u.Email || '', active: u.Active !== false,
  }));
}

/** สร้างผู้ใช้ใหม่ */
function createUser_(payload, session) {
  const en = String(payload.en || '').trim();
  const name = String(payload.name || '').trim();
  const role = String(payload.role || '').trim();
  const pin = String(payload.pin || '').trim();
  const email = String(payload.email || '').trim();

  if (!en) throw new Error('Please enter a user ID (EN)');
  if (!name) throw new Error('Please enter a name');
  if (!ROLES[role]) throw new Error('Invalid role');
  if (role === ROLES.ADMIN && session.role !== ROLES.ADMIN) {
    throw new Error('Only ADMIN can create ADMIN accounts');
  }
  if (findRow_('Users', u => String(u.EN).trim() === en)) {
    throw new Error('User ID ' + en + ' already exists');
  }
  if (roleNeedsPin_(role) && !validatePin_(pin)) {
    throw new Error('Role ' + role + ' requires a 4-6 digit PIN');
  }

  appendRow_('Users', {
    EN: en, Name: name, Role: role,
    PIN: roleNeedsPin_(role) ? pin : '', Email: email, Active: true,
  });
  audit_(session.en, 'CREATE_USER', 'Users', en, { role: role });
  return { en: en, name: name, role: role, hasPin: roleNeedsPin_(role), email: email, active: true };
}

/** แก้ไขผู้ใช้ (ค้นด้วย EN เดิม; EN เปลี่ยนไม่ได้) */
function updateUser_(payload, session) {
  const en = String(payload.en || '').trim();
  const u = findRow_('Users', x => String(x.EN).trim() === en);
  if (!u) throw new Error('User not found: ' + en);

  const role = payload.role ? String(payload.role).trim() : u.Role;
  if (!ROLES[role]) throw new Error('Invalid role');
  if (role === ROLES.ADMIN && session.role !== ROLES.ADMIN) {
    throw new Error('Only ADMIN can assign the ADMIN role');
  }
  const newActive = (payload.active === undefined) ? (u.Active !== false) : !!payload.active;

  // กันล็อกตัวเองออกจากระบบ: ต้องเหลือ ADMIN ที่ใช้งานได้ ≥ 1 บัญชีเสมอ
  const activeAdmins = readAll_('Users')
    .filter(x => x.Role === ROLES.ADMIN && x.Active !== false);
  const isLastAdmin = (u.Role === ROLES.ADMIN && activeAdmins.length <= 1);
  if (isLastAdmin && (role !== ROLES.ADMIN || !newActive)) {
    throw new Error('At least one active ADMIN account is required');
  }

  // จัดการ PIN: ถ้าใส่ค่ามาใหม่ = เปลี่ยน, ถ้าเว้นว่าง = คงเดิม
  let pin = String(u.PIN || '');
  if (payload.pin !== undefined && String(payload.pin).trim() !== '') {
    if (roleNeedsPin_(role) && !validatePin_(payload.pin)) {
      throw new Error('PIN must be 4-6 digits');
    }
    pin = String(payload.pin).trim();
  }
  if (roleNeedsPin_(role) && !pin.trim()) {
    throw new Error('Role ' + role + ' requires a PIN. Please set one.');
  }
  if (!roleNeedsPin_(role)) pin = ''; // STAFF/SUPERVISOR ไม่ใช้ PIN

  const patch = {
    Name: (payload.name !== undefined) ? String(payload.name).trim() : u.Name,
    Role: role, PIN: pin,
    Email: (payload.email !== undefined) ? String(payload.email).trim() : u.Email,
    Active: newActive,
  };
  updateRow_('Users', u._row, patch);
  audit_(session.en, 'UPDATE_USER', 'Users', en, { role: role, active: newActive });
  return { en: en, name: patch.Name, role: patch.Role,
           hasPin: !!String(patch.PIN).trim(), email: patch.Email, active: patch.Active };
}


/* ##################################################################
   ### 08e_Calendar (ปฏิทินแผนการเทรน)
   ################################################################## */

/**
 * รวบรวม event จาก Tickets ที่มี PreferredDate ในเดือน year/month ที่ระบุ
 * (year=0 / month=0 = ดึงทุกเดือน)
 * กรองตาม role เหมือน listTickets_ (STAFF เห็นตัวเอง, SUPERVISOR เห็นทีม, TRAINER/ADMIN เห็นหมด)
 */
function buildCalendar_(year, month, session) {
  year  = Number(year)  || 0;
  month = Number(month) || 0;

  const empIndex = {};
  readAll_('Employees').forEach(e => { empIndex[String(e.EN)] = e; });
  const courseIndex = {};
  readAll_('Courses').forEach(c => { courseIndex[String(c.CourseID)] = c; });

  let tickets = readAll_('Tickets').filter(t => {
    if (!t.PreferredDate) return false;
    const d = new Date(t.PreferredDate);
    if (isNaN(d)) return false;
    if (year && month) {
      if (d.getFullYear() !== year || d.getMonth() + 1 !== month) return false;
    }
    return true;
  });

  // กรองตาม role (เหมือน listTickets_) — ส่ง empIndex ที่โหลดไว้แล้วเพื่อเลี่ยง readAll_ ซ้ำ
  if (session.role === ROLES.STAFF || session.role === ROLES.OPERATOR) {
    tickets = tickets.filter(t => String(t.EN) === String(session.en));
  } else if (session.role === ROLES.SUPERVISOR) {
    const team = getTeamENs_(session, Object.values(empIndex));
    tickets = tickets.filter(t => team.indexOf(String(t.EN)) !== -1);
  }

  const events = tickets.map(t => {
    const emp = empIndex[String(t.EN)] || {};
    const course = courseIndex[String(t.CourseID)] || {};
    return {
      type:            'ticket',
      date:            fmtDate_(new Date(t.PreferredDate)),
      ticketId:        t.TicketID,
      en:              t.EN,
      name:            emp.NameEN || emp.NameTH || t.EN,
      nickname:        emp.Nickname || '',
      workingArea:     emp.WorkingArea || '',
      courseId:        t.CourseID,
      courseName:      course.CourseName || t.CourseID,
      status:          t.Status,
      assignedTrainer: t.AssignedTrainer || '',
      notes:           t.Notes || '',
    };
  });

  // STAFF/OPERATOR: เพิ่ม event จาก Training Records ส่วนตัว (วันเทรน + วันหมดอายุ)
  if (session.role === ROLES.STAFF || session.role === ROLES.OPERATOR) {
    const now = new Date();
    readAll_('TrainingRecords')
      .filter(r => String(r.EN) === String(session.en))
      .forEach(r => {
        const course = courseIndex[String(r.CourseID)] || {};
        const courseName = course.CourseName || r.CourseID;

        // วันเทรน (OverviewDate)
        if (r.OverviewDate) {
          const d = new Date(r.OverviewDate);
          if (!isNaN(d)) {
            const inRange = !year || (d.getFullYear() === year && d.getMonth() + 1 === month);
            if (inRange) events.push({
              type: 'trained',
              date: fmtDate_(d),
              en: r.EN,
              courseId: r.CourseID,
              courseName: courseName,
              trainStatus: r.Status,
              qualifiedDate: fmtDate_(r.QualifiedDate),
              score: r.Score || '',
            });
          }
        }

        // วันหมดอายุ (ExpiryDate)
        if (r.ExpiryDate) {
          const d = new Date(r.ExpiryDate);
          if (!isNaN(d)) {
            const inRange = !year || (d.getFullYear() === year && d.getMonth() + 1 === month);
            if (inRange) {
              const daysLeft = Math.floor((d - now) / 86400000);
              events.push({
                type: 'expiry',
                date: fmtDate_(d),
                en: r.EN,
                courseId: r.CourseID,
                courseName: courseName,
                expiryColor: daysLeft < 0 ? 'RED' : (daysLeft <= APP.NEAR_EXPIRY_DAYS ? 'YELLOW' : 'GREEN'),
                expiryDate: fmtDate_(d),
              });
            }
          }
        }
      });
  }

  events.sort((a, b) => a.date.localeCompare(b.date));
  return { year: year, month: month, events: events };
}

function apiCalendar(token, year, month) {
  return withAuth_(token, [], (s) => buildCalendar_(year, month, s));
}


/* ##################################################################
   ### 08c_EmployeesCrud (ADMIN จัดการพนักงาน — list/create/update/deactivate)
   ################################################################## */

/** แปลง row -> view object (ฝั่ง frontend) */
function empView_(e) {
  return {
    en: String(e.EN), nameEN: e.NameEN || '', nameTH: e.NameTH || '',
    nickname: e.Nickname || '', workingArea: e.WorkingArea || '',
    supervisor: e.Supervisor || '', splicingExp: e.SplicingExp || '',
    email: e.Email || '', active: e.Active !== false,
  };
}

/** ดึงรายชื่อพนักงานทั้งหมด (TRAINER/ADMIN); filter.active กรองตามสถานะ */
function listEmployeesAll_(filter) {
  const userIndex = {};
  readAll_('Users').forEach(u => { userIndex[String(u.EN).trim()] = u; });

  let rows = readAll_('Employees');
  filter = filter || {};
  if (filter.active !== undefined) {
    const want = !!filter.active;
    rows = rows.filter(e => (e.Active !== false) === want);
  }
  return rows.map(e => {
    const v = empView_(e);
    const u = userIndex[String(e.EN).trim()];
    v.loginRole = u ? String(u.Role) : ROLES.OPERATOR; // default = OPERATOR ถ้าไม่มีใน Users
    return v;
  });
}

/** ตั้งสิทธิ์ login ให้พนักงาน (OPERATOR / STAFF / SUPERVISOR เท่านั้น — TRAINER/ADMIN ใช้ User Management)
 *  - ถ้ามี Users entry อยู่แล้ว (ไม่ใช่ TRAINER/ADMIN) -> update Role
 *  - ถ้าไม่มี Users entry และ role != OPERATOR -> สร้างใหม่ (ไม่ต้องมี PIN)
 *  - role = OPERATOR และมี entry อยู่ -> update กลับเป็น OPERATOR (คงไว้เพื่อความชัดเจน)
 */
function setEmployeeRole_(en, role, session) {
  en = String(en || '').trim();
  if (!en) throw new Error('EN is required');
  const allowed = [ROLES.OPERATOR, ROLES.STAFF, ROLES.SUPERVISOR];
  if (allowed.indexOf(role) === -1) {
    throw new Error('TRAINER / ADMIN roles must be managed via User Management (requires PIN)');
  }
  const emp = findRow_('Employees', e => String(e.EN).trim() === en);
  if (!emp) throw new Error('Employee not found: ' + en);

  const existing = findRow_('Users', u => String(u.EN).trim() === en);
  if (existing) {
    if ([ROLES.TRAINER, ROLES.ADMIN].indexOf(existing.Role) !== -1) {
      throw new Error('Cannot change role: this account is ' + existing.Role + '. Please use User Management.');
    }
    updateRow_('Users', existing._row, { Role: role, UpdatedAt: new Date() });
  } else if (role !== ROLES.OPERATOR) {
    appendRow_('Users', {
      EN: en, Name: emp.NameEN || emp.NameTH || en,
      Role: role, PIN: '', Email: emp.Email || '', Active: true,
    });
  }
  audit_(session.en, 'SET_EMPLOYEE_ROLE', 'Users', en, { role });
  return role;
}

function apiSetEmployeeRole(token, en, role) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN],
    (s) => withLock_(() => setEmployeeRole_(en, role, s)));
}

/** สร้างพนักงานใหม่โดยตรง (ADMIN) */
function createEmployeeAdmin_(payload, session) {
  const en = String(payload.en || '').trim();
  const nameEN = String(payload.nameEN || '').trim();
  if (!en) throw new Error('Please enter an employee ID (EN)');
  if (!nameEN) throw new Error('Please enter an employee name (EN)');
  if (findRow_('Employees', e => String(e.EN).trim() === en)) {
    throw new Error('Employee ID ' + en + ' already exists');
  }
  appendRow_('Employees', {
    EN: en, NameEN: nameEN, NameTH: String(payload.nameTH || '').trim(),
    Nickname: String(payload.nickname || '').trim(),
    WorkingArea: String(payload.workingArea || '').trim(),
    Supervisor: String(payload.supervisor || '').trim(),
    SplicingExp: String(payload.splicingExp || '').trim(),
    Email: String(payload.email || '').trim(), Active: true,
  });
  audit_(session.en, 'CREATE_EMPLOYEE_ADMIN', 'Employees', en, {});
  const created = findRow_('Employees', e => String(e.EN).trim() === en);
  if (!created) throw new Error('Employee was created but could not be retrieved. Please refresh the page.');
  return empView_(created);
}

/** แก้ไขพนักงาน (ADMIN) — ครอบคลุมทุก field รวมถึง Active */
function updateEmployeeAdmin_(payload, session) {
  const en = String(payload.en || '').trim();
  const e = findRow_('Employees', x => String(x.EN) === en);
  if (!e) throw new Error('Employee not found: ' + en);
  const patch = {
    NameEN: payload.nameEN !== undefined ? String(payload.nameEN).trim() : e.NameEN,
    NameTH: payload.nameTH !== undefined ? String(payload.nameTH).trim() : e.NameTH,
    Nickname: payload.nickname !== undefined ? String(payload.nickname).trim() : e.Nickname,
    WorkingArea: payload.workingArea !== undefined ? String(payload.workingArea).trim() : e.WorkingArea,
    Supervisor: payload.supervisor !== undefined ? String(payload.supervisor).trim() : e.Supervisor,
    SplicingExp: payload.splicingExp !== undefined ? String(payload.splicingExp).trim() : e.SplicingExp,
    Email: payload.email !== undefined ? String(payload.email).trim() : e.Email,
    Active: payload.active !== undefined ? !!payload.active : (e.Active !== false),
  };
  updateRow_('Employees', e._row, patch);
  audit_(session.en, 'UPDATE_EMPLOYEE_ADMIN', 'Employees', en, { active: patch.Active });
  return empView_(Object.assign({}, e, patch, { EN: en }));
}

// ---- API endpoints ----
function apiListEmployees(token, filter) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN], () => listEmployeesAll_(filter));
}
function apiCreateEmployee(token, payload) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN], (s) => withLock_(() => createEmployeeAdmin_(payload, s)));
}
function apiUpdateEmployeeAdmin(token, payload) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN], (s) => withLock_(() => updateEmployeeAdmin_(payload, s)));
}


/* ##################################################################
   ### 08d_CoursesCrud (ADMIN จัดการคอร์ส — list/create/update/delete)
   ################################################################## */

function courseView_(c) {
  return {
    courseId: String(c.CourseID), courseName: c.CourseName,
    validityMonths: Number(c.ValidityMonths) || APP.DEFAULT_VALIDITY_MONTHS,
  };
}

/** สร้างคอร์สใหม่ (ADMIN) */
function createCourse_(payload, session) {
  const courseId = String(payload.courseId || '').trim().toUpperCase();
  const courseName = String(payload.courseName || '').trim();
  const rawValidity = payload.validityMonths !== undefined && payload.validityMonths !== ''
    ? Number(payload.validityMonths) : APP.DEFAULT_VALIDITY_MONTHS;
  const validity = rawValidity;
  if (!courseId) throw new Error('Please enter a Course ID');
  if (!courseName) throw new Error('Please enter a Course Name');
  if (!(validity > 0)) throw new Error('Validity (months) must be a positive number');
  if (findRow_('Courses', c => String(c.CourseID).toUpperCase() === courseId)) {
    throw new Error('Course ID ' + courseId + ' already exists');
  }
  appendRow_('Courses', { CourseID: courseId, CourseName: courseName, ValidityMonths: validity });
  audit_(session.en, 'CREATE_COURSE', 'Courses', courseId, {});
  return { courseId: courseId, courseName: courseName, validityMonths: validity };
}

/** แก้ไขคอร์ส (ADMIN) */
function updateCourse_(payload, session) {
  const courseId = String(payload.courseId || '').trim();
  const c = findRow_('Courses', x => String(x.CourseID) === courseId);
  if (!c) throw new Error('Course not found: ' + courseId);
  const patch = {
    CourseName: payload.courseName !== undefined ? String(payload.courseName).trim() : c.CourseName,
    ValidityMonths: payload.validityMonths !== undefined ? Number(payload.validityMonths) : c.ValidityMonths,
  };
  if (!patch.CourseName) throw new Error('Course Name cannot be empty');
  if (!(patch.ValidityMonths > 0)) throw new Error('Validity (months) must be a positive number');
  updateRow_('Courses', c._row, patch);
  audit_(session.en, 'UPDATE_COURSE', 'Courses', courseId, patch);
  return courseView_(Object.assign({}, c, patch));
}

/**
 * ลบคอร์ส (ADMIN) — ตรวจว่ามี training record ที่ใช้คอร์สนี้ก่อน
 * ถ้ามี record อยู่ -> ปฏิเสธ (เพื่อไม่ให้ข้อมูลใน SkillMatrix กำพร้า)
 */
function deleteCourse_(courseId, session) {
  courseId = String(courseId || '').trim();
  const c = findRow_('Courses', x => String(x.CourseID) === courseId);
  if (!c) throw new Error('Course not found: ' + courseId);
  const activeStatuses = [TICKET_STATUS.OPEN, TICKET_STATUS.SCHEDULED, TICKET_STATUS.IN_PROGRESS];
  const usedInTicket = findRow_('Tickets', t =>
    String(t.CourseID) === courseId && activeStatuses.indexOf(t.Status) !== -1);
  if (usedInTicket) {
    throw new Error('Cannot delete "' + courseId + '": it has active tickets (' +
      usedInTicket.TicketID + '). Close or cancel them first.');
  }
  const used = findRow_('TrainingRecords', r => String(r.CourseID) === courseId);
  if (used) {
    throw new Error('Cannot delete "' + courseId + '": it has training records. Delete the records first or rename the course instead.');
  }
  deleteSheetRow_('Courses', c._row);
  audit_(session.en, 'DELETE_COURSE', 'Courses', courseId, {});
  return { courseId: courseId };
}

// ---- API endpoints ----
function apiListCourses(token) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN], () =>
    readAll_('Courses').map(courseView_));
}
function apiCreateCourse(token, payload) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN], (s) => withLock_(() => createCourse_(payload, s)));
}
function apiUpdateCourse(token, payload) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN], (s) => withLock_(() => updateCourse_(payload, s)));
}
function apiDeleteCourse(token, courseId) {
  return withAuth_(token, [ROLES.TRAINER, ROLES.ADMIN], (s) => withLock_(() => deleteCourse_(courseId, s)));
}


/* ##################################################################
   ### 09_WebApp
   ################################################################## */

/**
 * 09_WebApp.gs : entry point ของ Web App (HtmlService)
 */

function doGet(e) {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle(APP.NAME)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/** ใช้ใน HTML: <?!= include('Styles') ?> เพื่อรวมไฟล์ย่อย */
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}


/* ##################################################################
   ### 10_Alerts
   ################################################################## */

/**
 * 10_Alerts.gs : แจ้งเตือนใบเซอร์ใกล้หมดอายุทาง Email (time-driven trigger)
 *
 * ตั้ง trigger: รัน installThursdayAlertTrigger() หนึ่งครั้ง
 *   -> ระบบจะรัน sendExpiryAlerts() ทุกวันพฤหัสบดี เวลา ~07:30
 *
 * หมายเหตุ: เอกสารแนะนำเลี่ยง LINE Notify (จะปิดบริการ) -> ใช้ Email ก่อน
 *           ภายหลังต่อยอด LINE Messaging API (Phase 3) ได้
 */

/** ติดตั้ง trigger รายสัปดาห์ทุกวันพฤหัส ~07:30 (idempotent) */
function installThursdayAlertTrigger() {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === 'sendExpiryAlerts') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('sendExpiryAlerts')
    .timeBased().onWeekDay(ScriptApp.WeekDay.THURSDAY).atHour(7).nearMinute(30).create();
  return 'Thursday expiry alert trigger installed (~07:30)';
}

/** ส่งอีเมลสรุปใบเซอร์ที่กำลังจะหมดอายุ / หมดแล้ว */
function sendExpiryAlerts() {
  const now = new Date();
  const empIndex = {};
  readAll_('Employees').forEach(e => { empIndex[String(e.EN)] = e; });
  const courseIndex = {};
  readAll_('Courses').forEach(c => { courseIndex[String(c.CourseID)] = c; });

  // จัดกลุ่มรายการแจ้งเตือนตาม supervisor (เพื่อส่งสรุปให้หัวหน้าแต่ละคน)
  const bySupervisor = {};   // email -> rows[]
  const adminRows = [];

  readAll_('TrainingRecords').forEach(r => {
    const color = statusColor_(r, now);
    if (color !== 'YELLOW' && color !== 'RED') return; // เฉพาะใกล้หมด/หมดแล้ว
    const st = effectiveStatus_(r, now);
    if (st === RECORD_STATUS.FAILED) return;            // FAILED ไม่ใช่เรื่องหมดอายุ

    const emp = empIndex[String(r.EN)] || {};
    const course = courseIndex[String(r.CourseID)] || {};
    const row = {
      en: r.EN, name: emp.NameEN || emp.NameTH || r.EN,
      course: course.CourseName || r.CourseID,
      expiry: fmtDate_(r.ExpiryDate),
      state: color === 'RED' ? 'Expired' : 'Near expiry',
    };
    adminRows.push(row);

    const supEmail = findSupervisorEmail_(emp.Supervisor);
    if (supEmail) {
      (bySupervisor[supEmail] = bySupervisor[supEmail] || []).push(row);
    }
  });

  let sent = 0;
  // ส่งให้หัวหน้าแต่ละคน
  Object.keys(bySupervisor).forEach(email => {
    sendAlertEmail_(email, bySupervisor[email], 'Your team');
    sent++;
  });
  // ส่งสรุปรวมให้ ADMIN
  const admins = readAll_('Users').filter(u => u.Role === ROLES.ADMIN && u.Email);
  admins.forEach(a => {
    if (adminRows.length) { sendAlertEmail_(a.Email, adminRows, 'System overview'); sent++; }
  });

  console.log('sendExpiryAlerts: sent ' + sent + ' emails, rows ' + adminRows.length);
  return sent;
}

/** หา email ของ supervisor จากชื่อ (match กับ Users.Name หรือ Employees.Nickname) */
function findSupervisorEmail_(supName) {
  if (!supName) return null;
  const u = findRow_('Users', x =>
    String(x.Name) === String(supName) && x.Email &&
    (x.Role === ROLES.SUPERVISOR || x.Role === ROLES.TRAINER || x.Role === ROLES.ADMIN));
  return u ? u.Email : null;
}

function sendAlertEmail_(to, rows, scopeLabel) {
  if (!rows.length) return;
  rows.sort((a, b) => (a.expiry || '').localeCompare(b.expiry || ''));
  let html = '<h3>Training Certificate Alert (' + scopeLabel + ')</h3>';
  html += '<p>As of ' + fmtDate_(new Date()) + ', ' + rows.length + ' item(s) require action:</p>';
  html += '<table border="1" cellpadding="6" cellspacing="0" style="border-collapse:collapse;font-family:sans-serif;font-size:13px">';
  html += '<tr style="background:#1f3864;color:#fff"><th>EN</th><th>Name</th><th>Course</th><th>Expiry Date</th><th>Status</th></tr>';
  rows.forEach(r => {
    const bg = r.state === 'Expired' ? '#ffd6d6' : '#fff3cd';
    html += '<tr style="background:' + bg + '"><td>' + esc_(r.en) + '</td><td>' + esc_(r.name) +
            '</td><td>' + esc_(r.course) + '</td><td>' + esc_(r.expiry) + '</td><td>' + esc_(r.state) + '</td></tr>';
  });
  html += '</table><p style="color:#888;font-size:12px">- Training Record System (Ciena Optical), automated email</p>';

  MailApp.sendEmail({
    to: to,
    subject: '[Training Record] Certificate expiry alert (' + rows.length + ' items)',
    htmlBody: html,
  });
}


/* ##################################################################
   ### 10b_Notifications (อีเมลแจ้งเตือนตามเหตุการณ์ + สรุปรายสัปดาห์)
   ################################################################## */

/** escape ค่าก่อนใส่ใน HTML อีเมล (กัน HTML แตก/ฉีดโค้ด) */
function esc_(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/** อีเมลของผู้ใช้ตาม role (เฉพาะ active + มีอีเมล) */
function emailsForRoles_(roles) {
  return readAll_('Users')
    .filter(u => roles.indexOf(u.Role) !== -1 && u.Active !== false && String(u.Email || '').trim())
    .map(u => String(u.Email).trim());
}

/** อีเมลพนักงานจาก EN (null ถ้าไม่มี) */
function employeeEmail_(en) {
  const e = findRow_('Employees', x => String(x.EN) === String(en));
  const v = e ? String(e.Email || '').trim() : '';
  return v || null;
}

/**
 * ส่งอีเมลแบบปลอดภัย: รวมผู้รับไม่ซ้ำ + ข้ามค่าว่าง + ไม่ทำให้ flow หลักพัง
 * opts.name    = ชื่อผู้ส่งที่แสดง (display name) เช่นชื่อคนที่ทำรายการ
 * opts.replyTo = อีเมลสำหรับ "ตอบกลับ" (เด้งไปหาคนทำรายการ)
 * หมายเหตุ: ที่อยู่ From เปลี่ยนไม่ได้ (Google บังคับเป็นบัญชีที่รันสคริปต์) ตั้งได้แค่ชื่อ+replyTo
 */
function sendMailSafe_(to, subject, htmlBody, opts) {
  try {
    opts = opts || {};
    const list = (Array.isArray(to) ? to : [to]).map(x => String(x || '').trim()).filter(Boolean);
    const uniq = list.filter((v, i) => list.indexOf(v) === i);
    if (!uniq.length) return 0;
    const params = { to: uniq.join(','), subject: subject, htmlBody: htmlBody };
    // name intentionally omitted — sender shows script owner's account name
    if (String(opts.replyTo || '').trim()) params.replyTo = String(opts.replyTo).trim();
    MailApp.sendEmail(params);
    return uniq.length;
  } catch (e) { console.warn('sendMailSafe_ failed: ' + e); return 0; }
}

function mailRow_(k, v) {
  return '<tr><td style="background:#f0f3fa;padding:6px 10px"><b>' + esc_(k) +
         '</b></td><td style="padding:6px 10px">' + esc_(v) + '</td></tr>';
}
function mailTable_(rowsHtml) {
  return '<table border="1" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-family:sans-serif;font-size:13px">' + rowsHtml + '</table>';
}
function mailFoot_() {
  return '<p style="color:#888;font-size:12px">— Training Record System (Ciena Optical), automated email</p>';
}

/** [เปิด Ticket] แจ้งเทรนเนอร์ + แอดมิน ว่ามีคำขอเทรนใหม่ */
function notifyTicketOpened_(v, session) {
  const to = emailsForRoles_([ROLES.TRAINER, ROLES.ADMIN]);
  if (!to.length) return;
  const html = '<h3>New Training Request</h3>'
    + '<p>Opened by <b>' + esc_(session.name || session.en) + '</b></p>'
    + mailTable_(mailRow_('Ticket', v.ticketId) + mailRow_('Employee', v.name + ' (' + v.en + ')')
        + mailRow_('Course', v.courseName) + mailRow_('Preferred date', v.preferredDate || '-')
        + mailRow_('Notes', v.notes || '-'))
    + mailFoot_();
  sendMailSafe_(to, '[Training Record] New request: ' + v.courseName + ' — ' + v.name, html,
    { name: session.name || session.en, replyTo: session.email });
}

/** [Bulk] แจ้งเทรนเนอร์ + แอดมิน เมื่อ import คำขอหลายรายการ (สรุป + ตารางรายการ) */
function notifyBulkTicketsOpened_(list, session) {
  const to = emailsForRoles_([ROLES.TRAINER, ROLES.ADMIN]);
  if (!to.length) return;
  const head = '<tr style="background:#1f3864;color:#fff">'
    + '<td style="padding:6px 10px">Ticket</td><td style="padding:6px 10px">Employee</td>'
    + '<td style="padding:6px 10px">Work Area</td><td style="padding:6px 10px">Course</td>'
    + '<td style="padding:6px 10px">Preferred date</td></tr>';
  const body = list.map(v =>
    '<tr><td style="padding:6px 10px">' + esc_(v.ticketId) + '</td>'
    + '<td style="padding:6px 10px">' + esc_(v.name + ' (' + v.en + ')') + '</td>'
    + '<td style="padding:6px 10px">' + esc_(v.workingArea || '-') + '</td>'
    + '<td style="padding:6px 10px">' + esc_(v.courseName) + '</td>'
    + '<td style="padding:6px 10px">' + esc_(v.preferredDate || '-') + '</td></tr>').join('');
  const html = '<h3>New Training Requests (bulk import)</h3>'
    + '<p><b>' + list.length + '</b> request(s) imported by <b>' + esc_(session.name || session.en) + '</b>.</p>'
    + mailTable_(head + body)
    + '<p style="margin-top:10px">Open the app to review and schedule.</p>' + mailFoot_();
  sendMailSafe_(to, '[Training Record] ' + list.length + ' new requests imported', html,
    { name: session.name || session.en, replyTo: session.email });
}

/** [นัดวัน] แจ้งพนักงาน + หัวหน้า เมื่อ ticket ถูกจัดเป็น SCHEDULED */
function notifyTicketScheduled_(v, session) {
  session = session || {};
  const to = [employeeEmail_(v.en), findSupervisorEmail_(v.supervisor)];
  const html = '<h3>Training Scheduled</h3>'
    + mailTable_(mailRow_('Employee', v.name + ' (' + v.en + ')') + mailRow_('Course', v.courseName)
        + mailRow_('Scheduled date', v.preferredDate || '-') + mailRow_('Trainer', v.assignedTrainer || '-'))
    + mailFoot_();
  sendMailSafe_(to, '[Training Record] Training scheduled: ' + v.courseName + ' — ' + v.name, html,
    { name: session.name || session.en, replyTo: session.email });
}

/** [เลื่อนนัด] แจ้งพนักงาน + หัวหน้า ว่าวันเทรนเปลี่ยนไป */
function notifyTicketRescheduled_(v, session, oldDate, reason) {
  session = session || {};
  const to = [employeeEmail_(v.en), findSupervisorEmail_(v.supervisor)];
  const html = '<h3>Training Rescheduled</h3>'
    + mailTable_(
        mailRow_('Employee', v.name + ' (' + v.en + ')')
        + mailRow_('Course', v.courseName)
        + mailRow_('Previous date', oldDate || '-')
        + mailRow_('New date', v.preferredDate || '-')
        + mailRow_('Trainer', v.assignedTrainer || '-')
        + (reason ? mailRow_('Reason', reason) : ''))
    + mailFoot_();
  sendMailSafe_(to,
    '[Training Record] Rescheduled: ' + v.courseName + ' — ' + v.name, html,
    { name: session.name || session.en, replyTo: session.email });
}

/** [ปิดงานมีผล] แจ้งพนักงาน + หัวหน้า ผลประเมิน (ผ่าน/ไม่ผ่าน) */
function notifyTicketResult_(v, rec, session) {
  session = session || {};
  const to = [employeeEmail_(v.en), findSupervisorEmail_(v.supervisor)];
  const passed = rec.status === RECORD_STATUS.QUALIFIED;
  const html = '<h3>Training Result: ' + (passed ? 'QUALIFIED' : 'NOT QUALIFIED') + '</h3>'
    + mailTable_(mailRow_('Employee', v.name + ' (' + v.en + ')') + mailRow_('Course', v.courseName)
        + mailRow_('Result', passed ? 'Qualified' : 'Failed')
        + mailRow_('Qualified date', rec.qualifiedDate || '-')
        + mailRow_('Expiry date', rec.expiryDate || '-')
        + mailRow_('Score', rec.score || '-'))
    + mailFoot_();
  sendMailSafe_(to, '[Training Record] Result ' + (passed ? 'QUALIFIED' : 'FAILED') + ': ' + v.courseName + ' — ' + v.name, html,
    { name: session.name || session.en, replyTo: session.email });
}

/** [ยกเลิก] แจ้งพนักงาน + หัวหน้า เมื่อ ticket ถูก CANCELLED */
function notifyTicketCancelled_(v, session) {
  session = session || {};
  const to = [employeeEmail_(v.en), findSupervisorEmail_(v.supervisor)];
  const html = '<h3>Training Request Cancelled</h3>'
    + mailTable_(mailRow_('Ticket', v.ticketId) + mailRow_('Employee', v.name + ' (' + v.en + ')')
        + mailRow_('Course', v.courseName) + mailRow_('Cancelled by', session.name || session.en)
        + (v.notes ? mailRow_('Notes', v.notes) : ''))
    + mailFoot_();
  sendMailSafe_(to, '[Training Record] Request cancelled: ' + v.courseName + ' — ' + v.name, html,
    { name: session.name || session.en, replyTo: session.email });
}

/** ติดตั้ง trigger สรุปรายสัปดาห์ (จันทร์ ~07:30) */
function installWeeklySummaryTrigger() {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === 'sendWeeklySummary') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('sendWeeklySummary')
    .timeBased().onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(7).nearMinute(30).create();
  return 'Weekly summary trigger installed (Monday ~07:30)';
}

/** สรุปรายสัปดาห์ -> ADMIN (ทั้งระบบ) + หัวหน้าแต่ละคน (เฉพาะทีมตัวเอง) */
function sendWeeklySummary() {
  const now = new Date();
  const tickets = readAll_('Tickets');
  const employees = readAll_('Employees');
  const empIndex = {}; employees.forEach(e => empIndex[String(e.EN)] = e);
  const courseIndex = {}; readAll_('Courses').forEach(c => courseIndex[String(c.CourseID)] = c);
  const activeStatuses = [TICKET_STATUS.OPEN, TICKET_STATUS.SCHEDULED, TICKET_STATUS.IN_PROGRESS];
  const openTk = tickets.filter(t => activeStatuses.indexOf(t.Status) !== -1);

  // certs ใกล้หมด/หมดอายุ (YELLOW/RED, ไม่นับ FAILED)
  const expRows = [];
  readAll_('TrainingRecords').forEach(r => {
    const color = statusColor_(r, now);
    if (color !== 'YELLOW' && color !== 'RED') return;
    if (effectiveStatus_(r, now) === RECORD_STATUS.FAILED) return;
    const emp = empIndex[String(r.EN)] || {};
    expRows.push({
      en: r.EN, name: emp.NameEN || emp.NameTH || r.EN, supervisor: emp.Supervisor || '',
      course: (courseIndex[String(r.CourseID)] || {}).CourseName || r.CourseID,
      expiry: fmtDate_(r.ExpiryDate), state: color === 'RED' ? 'Expired' : 'Near expiry',
    });
  });

  function ticketTable(list) {
    if (!list.length) return '<p>No active requests.</p>';
    return mailTable_('<tr style="background:#1f3864;color:#fff"><td style="padding:6px 10px">Ticket</td><td style="padding:6px 10px">Employee</td><td style="padding:6px 10px">Course</td><td style="padding:6px 10px">Status</td></tr>'
      + list.map(t => {
          const emp = empIndex[String(t.EN)] || {};
          const cn = (courseIndex[String(t.CourseID)] || {}).CourseName || t.CourseID;
          return '<tr><td style="padding:6px 10px">' + esc_(t.TicketID) + '</td><td style="padding:6px 10px">'
            + esc_(emp.NameEN || emp.NameTH || t.EN) + '</td><td style="padding:6px 10px">' + esc_(cn)
            + '</td><td style="padding:6px 10px">' + esc_(t.Status) + '</td></tr>';
        }).join(''));
  }
  function expTable(list) {
    if (!list.length) return '<p>No upcoming expiries.</p>';
    list.sort((a, b) => (a.expiry || '').localeCompare(b.expiry || ''));
    return mailTable_('<tr style="background:#1f3864;color:#fff"><td style="padding:6px 10px">EN</td><td style="padding:6px 10px">Name</td><td style="padding:6px 10px">Course</td><td style="padding:6px 10px">Expiry</td><td style="padding:6px 10px">Status</td></tr>'
      + list.map(r => '<tr style="background:' + (r.state === 'Expired' ? '#ffd6d6' : '#fff3cd') + '"><td style="padding:6px 10px">'
          + esc_(r.en) + '</td><td style="padding:6px 10px">' + esc_(r.name) + '</td><td style="padding:6px 10px">'
          + esc_(r.course) + '</td><td style="padding:6px 10px">' + esc_(r.expiry) + '</td><td style="padding:6px 10px">'
          + esc_(r.state) + '</td></tr>').join(''));
  }

  let sent = 0;

  // ADMIN: ภาพรวมทั้งระบบ
  const admins = emailsForRoles_([ROLES.ADMIN]);
  if (admins.length) {
    const html = '<h3>Weekly Summary (System overview)</h3>'
      + '<p>As of ' + fmtDate_(now) + '</p>'
      + '<p><b>Active requests:</b> ' + openTk.length + ' &nbsp;|&nbsp; <b>Near/expired certs:</b> ' + expRows.length + '</p>'
      + '<h4>Active training requests</h4>' + ticketTable(openTk)
      + '<h4>Certificates near expiry / expired</h4>' + expTable(expRows)
      + mailFoot_();
    admins.forEach(a => { if (sendMailSafe_(a, '[Training Record] Weekly summary', html)) sent++; });
  }

  // หัวหน้าแต่ละคน: เฉพาะทีมตัวเอง
  const sups = readAll_('Users').filter(u =>
    u.Role === ROLES.SUPERVISOR && u.Active !== false && String(u.Email || '').trim());
  sups.forEach(sup => {
    const teamEN = {};
    employees.forEach(e => { if (String(e.Supervisor) === String(sup.Name)) teamEN[String(e.EN)] = true; });
    const myTk = openTk.filter(t => teamEN[String(t.EN)]);
    const myExp = expRows.filter(r => teamEN[String(r.en)]);
    if (!myTk.length && !myExp.length) return; // ไม่มีอะไรต้องแจ้ง -> ข้าม
    const html = '<h3>Weekly Summary (Your team)</h3>'
      + '<p>As of ' + fmtDate_(now) + '</p>'
      + '<h4>Active training requests</h4>' + ticketTable(myTk)
      + '<h4>Certificates near expiry / expired</h4>' + expTable(myExp)
      + mailFoot_();
    if (sendMailSafe_(String(sup.Email).trim(), '[Training Record] Weekly summary — your team', html)) sent++;
  });

  console.log('sendWeeklySummary: sent ' + sent + ' emails');
  return sent;
}


/* ##################################################################
   ### 11_SeedData
   ################################################################## */

/**
 * 11_SeedData.gs : ข้อมูลจริงนำเข้าจากไฟล์ Excel (สร้างอัตโนมัติด้วย tools/generate_seed.py)
 *   - พนักงาน 90 คน, training records 195 รายการ (HFO 106 + BASIC 89)
 * วิธีใช้: รัน initWithData() ครั้งเดียว (setup + เขียนข้อมูลลง DB)
 *          หรือแยกเป็น setupDatabase() แล้ว importSeedData()
 */

// คอลัมน์ตรงกับ SCHEMA.Employees.header
var SEED_EMPLOYEES = [
  ["67002611","Rawiwan Chaladchaiw","น.ส. รวิวรรณ ฉลาดเชี่ยว","นาง","Ciena: RLS","ตุ๊ก","Complete HFO-144. Already record in ETQ (New)","",true],
  ["67007518","Thikhamphon Bunthiam","น.ส ทิฆัมพร บุญเทียม","เค","Ciena: RLS","ตุ๊ก","Complete HFO-144. Already record in ETQ (New)","",true],
  ["67010204","Pornphilai Khansuwanna","","เปรีี้ยว","Ciena: Hydra, Ai","ปู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67010219","Sasitorn Bamkhunthod","","มิ้น","Ciena: Hydra, Ai","ปู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67010221","Thida Saengta","","ดา","Ciena: Hydra, Ai","ปู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67010239","Jidapha Phormthao","","เนย","Ciena: Hydra, Ai","ปู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67009442","Phimpakan Meayikhunthod","","หวิว","Ciena: Hydra, Ai","ปู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67003424","Soraya Karaket","น.ส.โสรยา การเกษ","ตั๊ก","Ciena: RLS","ฟาง","Complete HFO-145. Already record in ETQ (คนเก่าโดนตัดสกิว)","",true],
  ["26013926","Walaiporn Liangphum","น.ส. วลัยภรณ์ เลี่ยงภูมิ","เจี๊ยบ","Ciena: RLS","ฟาง","Complete HFO-145. Already record in ETQ (คนเก่าโดนตัดสกิว)","",true],
  ["67003860","Yonlada Chanthai","น.ส. ยลดา จันทร์ไทย","แหวน","Ciena: RLS","ฟาง","Complete HFO-145. Already record in ETQ (คนเก่าโดนตัดสกิว)","",true],
  ["67009656","Supattra Puttachat","น.ส สุพัตรา พุทธชาติ","ตุ๊กตา","Ciena: RLS","ฟาง","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67004008","Suchitta Yothakong","นางสาว สุจิตรา พุ่มเที่ยง","เจ","Ciena: RLS","ฟาง","Complete HFO-144. Already record in ETQ (คนเก่าโดนตัดสกิว)","",true],
  ["67010286","Athicha Thuengda","น.ส อธิชา ทึงดา","แบม","Ciena: Assamby","ตุ๊ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67010287","Sukanya Kahwai","น.ส สุกันยา กาหวาย","จอย","Ciena: Assamby","ตุ๊ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67010214","Ratchanok Baitham","น.ส. รัตน์ชนก ใบธรรม","เนย","Ciena: Test","หมู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67008982","Naphaphon Phrakhunloed","","ต้นหลิว","Ciena: RLS","ตุ๊ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67009242","Kanyapak Chotikul","น.ส.กัญญาภัค โชติกุล","เจน","New assy top ai","เล็ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67010224","Thippawan Chitkoh","น.ส ทิพวรรณ จิตรเกาะ","แนน","test hydra 800","เล็ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67009647","Pirisa Taithip","น.ส พิริสา ไตรทิพย์","แพรว","test system","เล็ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67009484","Siravit Dajhak","","แบค์","Support splice all","พี่ตั๊ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67003246","Jintana Khangkhan","น.ส จินตนา แข็งขัน","ติ๋ว","splice all","เล็ก","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["26014607","Pennapa Saisaard","น.ส. เพ็ญนภา ใสสะอาด","เพ็ญ","Ciena: Assamby","ฟาง","Complete HFO-145. Already record in ETQ (คนเก่าโดนตัดสกิว)","",true],
  ["67010405","Patcharin Wongsa","","","","ฟาง","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67010215","Pawina Tapwong","น.ส.ปวีณา เทพวงค์","หมิว","Ciena: Assamby","ฟาง","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67010404","Tidarat Chooyad","","เบีียร์","Ciena: Assamby","ฟาง","Complete HFO-145. Already record in ETQ (New)","",true],
  ["26016899","Laddawan Phuangphet","นางสาว ลัดดาวัลย์ พวงเพ็ชร","โย","splice all","ฟาง","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["26013903","Kanjana Salachonsin","นางสาว กาญจนา ศาลาชลสินธ์","ปัด","Ciena: Assamby","ฟาง","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67000935","Janya Nokprom","นางสาว จรรยา นกพรหม","ยา","Ciena: Assamby","ฟาง","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67004227","Piyaporn Chatdamdee","ปิยาภรณ์ ชาติดำดี","กิ้ว","Ciena: Hydra, RLS","ฟาง","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67002561","Wassana Khamnoi","น.ส. วาสนา คำน้อย","เฟิร์น","Ciena: Hydra, RLS","ฟาง","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67007494","Nattamol Neangchaiyod","น.ส. ณัฐมล เนื่องไชยศ","เบียร์","Ciena: Hydra, RLS","ฟาง","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67000163","Juthamanee Nammontri","Juthamanee Nammontri","เรย์","Ciena: RLS","ฟาง","Complete HFO-144. Already record in ETQ (Refresher)","",true],
  ["26013757","Sawitree Wimolsuk","นางสาว สาวิตรี วิมลสุข","เอ็ม","Ciena: RLS","ฟาง","Complete HFO-144. Already record in ETQ (Refresher)","",true],
  ["67002017","Yuphawan Rueangsaen","ยุพาวรรณ เรืองแสน","อิ่ว","Ciena: Hydra, Ai","ฟาง","Complete HFO-144. Already record in ETQ (Refresher)","",true],
  ["95164","Unchalee Mantaphan","Auncharee Mantraphan","นก","","ฟาง","Complete HFO-144. Already record in ETQ (Refresher)","",true],
  ["26014484","Anusara Sukya","อนุสรา สุขยา","","","ปู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["26013612","Patchara Keawdungta","พัชรา แก้วดวงตา","","","ปู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67002514","Chonticha Decha","ชลธิชา เดชะ","","","ปู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67008152","Tiptida Maihom","ทิพย์ธิดา ไม้หอม","","","ปู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67000809","Chatsuda Promprasert","ฉัตรสุดา พรหมประเสริฐ","","","ปู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67000410","Paweena Suttiprapa","ปวีณา สุทธิประภา","","","ปู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67004226","Ketsarin Sritiang","เกศรินทร์ ศรีเที่ยง","","","ปู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67010228","Kannika Ma-Ngern","น.ส กรรณิการ์ มาเงิน","ปู","","เล็ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67008628","Waranya Santalunai","น.ส วรัญญา สันทาลุนัย","ยาหยี","","เล็ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67009094","Tanyaphorn Chinnarat","น.ส. ธัญญาภรณ์ ชินรัตน์","มายด์","","เล็ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67008973","Mina Maoka","น.ส. มีนา เมากา","เมย์","","ตุ๊ก","HFO-145. Already record in ETQ (New)","",true],
  ["67010229","Sutthida Rityabut","น.ส. สุทธิดา ริตยะบุตร","ปลา","","ตุ๊ก","Complete HFO-145. Already record in ETQ (New)","",true],
  ["26013402","Chalita Ngaused","น.ส. ชลิตา เงาะเศษ","แป้ง","Ciena: RLS","หมู","Complete HFO-144. Already record in ETQ (Refresher)","",true],
  ["67002714","Narisa Comgern","น.ส. นริสา คำเงิน","แอน\nนาเบล","Ciena: RLS","หมู","Complete HFO-144. Already record in ETQ (Refresher)","",true],
  ["67004788","Sirirat Yemsen","น.ส ศิริรัช แย้มเเสน","","Ciena: Hydra, RLS","เล็ก","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67006772","Supadcha Baopad","น.ส สุพัดชา บัวผัด","","Ciena: Hydra, RLS","เล็ก","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67003559","Supaporn Poolpherm","น.ส. สุภาพร พูลเพิ่ม","","Ciena: Assamby","เล็ก","HFO-145. Already record in ETQ (Refresher) (ยังไม่ผ่าน splic single)","",true],
  ["67003237","Bulan Konme","น.ส. บุหลัน คุณมี","","Ciena: Assamby","เล็ก","HFO-145. Already record in ETQ (Refresher) (ยังไม่ผ่าน spli scingle)","",true],
  ["67000861","Wilailak Namkhot","น.ส วิไลลักษณ์ นามโคตร","","Ciena: Hydra, RLS","เล็ก","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67007394","Kultida Karam","น.ส.กุลธิดา คะรัมย์","","Ciena: Hydra, RLS","เล็ก","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67001296","Kantima Onlao","น.ส.กาญติมา อ่อนเหลา","อุ๊","RLS (Splice+Ribbon )","ตุ๊ก","Complete HFO-144. Already record in ETQ (Refresher)","",true],
  ["26001348","Nutjariya Jansripeng","น.ส. นุชจริยา จารย์ศรีเพ็ง","บอย","Captain RLS (Splice+Ribbon )","ตุ๊ก","Complete HFO-144. Already record in ETQ (Refresher)","",true],
  ["67001382","Chomphunuch Nakkruea","น.ส ชมพูนุช นาคเครือ","ขนุน","RLS (Splice+Ribbon )","ตุ๊ก","Complete  HFO-145 and 144. Already record in ETQ (Refresher)","",true],
  ["67010283","Chonlakorn Yosda","ชลกร ยศดา","หวาน","","ปู","Complete HFO-145. Already record in ETQ (New) มาต่อวันจันทร์","",true],
  ["67010297","Sunaree Suramanee","สุนารี สุระมณี","วัน","","ปู","HFO-145. Already record in ETQ (New) (ยังไม่ผ่าน splic single)","",true],
  ["67010312","Phirunphon Testan","พิรุณภรณ์ เทศทัน","กิ๊ฟ","","ปู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67010311","Sunisa Yenchujit","สุนิษา เย็นชูจิตร","มด","","ปู","HFO-145. Already record in ETQ (New) (ยังไม่ผ่าน splic single)","",true],
  ["67003768","Thippawan Onkaew","ทิพวรรณ อ่อนแก้ว","กวาง","Ciena: Hydra, Ai","ปู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67002066","Wannisa Thupbucha","วรรณนิสา ธูปบูชา","สา","Ciena: Hydra, Ai","ปู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67004076","Arisa Takaeo","น.ส. อริสา ตาแก้ว","พลอย","Ciena: Hydra, Ai","ฟาง","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67004229","Papatsorn Sorndet","น.ส. ประภัสสร ศรเดช","เกด","Ciena: Hydra, Ai","ฟาง","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67003870","Yuwapha Matsaya","น.ส. ยุวภา มาศยะ","ทิฟฟี่","Ciena: Hydra, Ai","ฟาง","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67004066","Kanyamat Thongnarin","น.ส. กัญญามาส ทองนรินทร์","เปรี้ยว","","ฟาง","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67008627","Peeyawan Samoesuk","น.ส ปรียาวรรณ เสมอสุข","ฟิล์ม","","ฟาง","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67009237","Maneerat Deechai","","แพม","","ฟาง","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67008911","Achiraya Sriphirom","น.ส.อชิรญา ศรีภิรมย์","เก๋","","ฟาง","Complete HFO-145. Already record in ETQ (New)","",true],
  ["26013252","Sujita Daungnapa","น.ส. สุจิตตา ดวงนภา","ตา","Ciena: RLS","หมู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67010227","Chutima Kongphet","น.ส. ชุติมา กงเพชร","เฟรช","Ciena: RLS","หมู","Complete HFO-145. Already record in ETQ (New)","",true],
  ["67000750","Pennapa Kumpapunt","น.ส. เพ็ญนภา กุมภาพันธ์","เหมียว","Ciena: Hydra, Ai","อ้อย","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67003760","Phiyarat Suksung","น.ส. ปิยรัตน์ สุขสังข์","เนย","Ciena: Hydra, Ai","อ้้อย","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67002357","Pakpimol Deloom","ภักตร์พิมล เดหลุ่ม","พี่ฟ้า","Ciena: Hydra, Ai","อ้อย","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67011896","Chanaghan Maneejan","","","ชมภู่","นง","HFO-145. Already record in ETQ (New)","",true],
  ["67011906","Boonyaporn Samorkhum","","","รุ่ง","นง","HFO-145. Already record in ETQ (New)","",true],
  ["67004352","Sirilak Singha","น.ส ศิริลักษณ์ สิงหา","ดรีมดรีม","RLS (Single Splice )","หมู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67002465","Jarupon Chiachanarot","น.ส.จารุพร ชัยชนะโรจน์","จา","RLS (Single Splice )","หมู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67004281","Siriwimon Tabjeen","น.ส สิริวิมล ทับจีน","อ้อม","RLS (Single Splice )","หมู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67001385","Punyaporn Nakkhruea","น.ส.ปุญญาพร นาคเครือ","คะน้า","RLS (Single Splice+Ribbon )","หมู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67007277","Saranya Namuangrak","น.ส. ศรัญญา นาเมืองรักษ์","ดรีม","","หมู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67007278","Butsakorn Nanthasan","น.ส. บุษกร นันทะสาร","พลอย","","หมู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["62006095","Kittisak Singkeaw","","โน๊ต","","","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67003333","Yutthachaiyakan Momkhunthot","","อั้ม","","","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67002682","On-auma Joomla","น.ส. อรอุมา จูมลา","แป้ง2","splice all","หมู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67000776","Naowarat Pratumlee","น.ส. เนาวรัตน์ ประทุมลี","ตะหลิว","splice all","หมู","Complete HFO-145. Already record in ETQ (Refresher)","",true],
  ["67012863","Wasita Phumnack","น.ส.วสิตา พุ่มนาค","ฟิล์ม","RMA","นง","HFO-145. Already record in ETQ (New)","",true],
  ["67012873","Inthira Khonphian","น.ส.อินทิรา คนเพียร","ปาล์มมี่","RMA","นง","HFO-145. Already record in ETQ (New)","",true]
];

// คอลัมน์ตรงกับ SCHEMA.TrainingRecords.header
var SEED_RECORDS = [
  ["RC-000001","67002611","HFO144-NEW","2026-01-07","2026-01-09","2027-01-09","QUALIFIED","","","import",""],
  ["RC-000002","67002611","HFO145-REF","2026-05-27","2026-05-27","2027-05-27","QUALIFIED","","","import",""],
  ["RC-000003","67002611","BASIC","","2025-08-22","2026-08-22","QUALIFIED","","","import",""],
  ["RC-000004","67007518","HFO144-NEW","2026-01-15","2026-01-16","2027-01-16","QUALIFIED","","","import",""],
  ["RC-000005","67007518","HFO145-REF","2026-03-13","2026-03-13","2027-03-13","QUALIFIED","","","import",""],
  ["RC-000006","67007518","BASIC","","2026-02-13","2027-02-13","QUALIFIED","","","import",""],
  ["RC-000007","67010204","HFO145-NEW","2026-01-20","2026-01-23","2027-01-23","QUALIFIED","","","import",""],
  ["RC-000008","67010204","BASIC","","2026-01-08","2027-01-08","QUALIFIED","","","import",""],
  ["RC-000009","67010219","HFO145-NEW","2026-01-20","2026-01-23","2027-01-23","QUALIFIED","","","import",""],
  ["RC-000010","67010219","BASIC","","2026-01-08","2027-01-08","QUALIFIED","","","import",""],
  ["RC-000011","67010221","HFO145-NEW","2026-01-20","2026-01-23","2027-01-23","QUALIFIED","","","import",""],
  ["RC-000012","67010221","BASIC","","2026-01-08","2027-01-08","QUALIFIED","","","import",""],
  ["RC-000013","67010239","HFO145-NEW","2026-01-20","2026-01-23","2027-01-23","QUALIFIED","","","import",""],
  ["RC-000014","67010239","BASIC","","2026-01-08","2027-01-08","QUALIFIED","","","import",""],
  ["RC-000015","67009442","HFO145-NEW","2026-01-20","2026-01-23","2027-01-23","QUALIFIED","","","import",""],
  ["RC-000016","67009442","BASIC","","2025-11-06","2026-11-06","QUALIFIED","","","import",""],
  ["RC-000017","67003424","HFO145-NEW","2026-01-26","2026-01-28","2027-01-28","QUALIFIED","","","import",""],
  ["RC-000018","67003424","HFO144-REF","2026-02-20","2026-02-20","2027-02-20","QUALIFIED","","","import",""],
  ["RC-000019","67003424","BASIC","","2025-10-03","2026-10-03","QUALIFIED","","","import",""],
  ["RC-000020","26013926","HFO145-NEW","2026-01-26","2026-01-28","2027-01-28","QUALIFIED","","","import",""],
  ["RC-000021","26013926","BASIC","","2025-10-31","2026-10-31","QUALIFIED","","","import",""],
  ["RC-000022","67003860","HFO145-NEW","2026-01-26","2026-01-28","2027-01-28","QUALIFIED","","","import",""],
  ["RC-000023","67003860","HFO144-REF","2026-05-13","2026-05-13","2027-05-13","QUALIFIED","","","import",""],
  ["RC-000024","67003860","BASIC","","2025-10-03","2026-10-03","QUALIFIED","","","import",""],
  ["RC-000025","67009656","HFO145-NEW","2026-01-26","2026-01-29","2027-01-29","QUALIFIED","","","import",""],
  ["RC-000026","67009656","BASIC","","2025-11-24","2026-11-24","QUALIFIED","","","import",""],
  ["RC-000027","67004008","HFO144-NEW","2026-01-27","2026-01-28","2027-01-28","QUALIFIED","","","import",""],
  ["RC-000028","67004008","HFO145-REF","2026-02-17","2026-02-17","2027-02-17","QUALIFIED","","","import",""],
  ["RC-000029","67004008","BASIC","","2026-01-30","2027-01-30","QUALIFIED","","","import",""],
  ["RC-000030","67010286","HFO145-NEW","2026-02-02","2026-02-05","2027-02-05","QUALIFIED","","","import",""],
  ["RC-000031","67010286","BASIC","","2026-01-15","2027-01-15","QUALIFIED","","","import",""],
  ["RC-000032","67010287","HFO145-NEW","2026-02-02","","","IN_PROGRESS","","","import",""],
  ["RC-000033","67010287","BASIC","","2026-01-15","2027-01-15","QUALIFIED","","","import",""],
  ["RC-000034","67010214","HFO145-NEW","2026-02-02","2026-02-05","2027-02-05","QUALIFIED","","","import",""],
  ["RC-000035","67010214","BASIC","","2026-01-08","2027-01-08","QUALIFIED","","","import",""],
  ["RC-000036","67008982","HFO145-NEW","2026-02-02","2026-02-05","2027-02-05","QUALIFIED","","","import",""],
  ["RC-000037","67008982","BASIC","","2025-10-02","2026-10-02","QUALIFIED","","","import",""],
  ["RC-000038","67009242","HFO145-NEW","2026-02-09","2026-02-12","2027-02-12","QUALIFIED","","","import",""],
  ["RC-000039","67009242","BASIC","","2025-10-23","2026-10-23","QUALIFIED","","","import",""],
  ["RC-000040","67010224","HFO145-NEW","2026-02-09","2026-02-12","2027-02-12","QUALIFIED","","","import",""],
  ["RC-000041","67010224","BASIC","","2026-01-08","2027-01-08","QUALIFIED","","","import",""],
  ["RC-000042","67009647","HFO145-NEW","2026-02-09","2026-02-12","2027-02-12","QUALIFIED","","","import",""],
  ["RC-000043","67009647","BASIC","","2025-08-27","2026-08-27","QUALIFIED","","","import",""],
  ["RC-000044","67009484","HFO145-NEW","2026-02-09","2026-02-12","2027-02-12","QUALIFIED","","","import",""],
  ["RC-000045","67003246","HFO145-REF","2026-02-10","2026-02-10","2027-02-10","QUALIFIED","","","import",""],
  ["RC-000046","67003246","BASIC","","2025-12-12","2026-12-12","QUALIFIED","","","import",""],
  ["RC-000047","26014607","HFO145-NEW","2026-02-16","2026-02-19","2027-02-19","QUALIFIED","","","import",""],
  ["RC-000048","26014607","HFO144-REF","2026-02-20","2026-02-20","2027-02-20","QUALIFIED","","","import",""],
  ["RC-000049","26014607","BASIC","","2025-10-03","2026-10-03","QUALIFIED","","","import",""],
  ["RC-000050","67010405","HFO145-NEW","2026-02-16","","","IN_PROGRESS","","","import",""],
  ["RC-000051","67010405","BASIC","","2026-01-22","2027-01-22","QUALIFIED","","","import",""],
  ["RC-000052","67010215","HFO145-NEW","2026-02-16","2026-02-19","2027-02-19","QUALIFIED","","","import",""],
  ["RC-000053","67010215","BASIC","","2026-01-08","2027-01-08","QUALIFIED","","","import",""],
  ["RC-000054","67010404","HFO145-NEW","2026-02-16","2026-02-19","2027-02-19","QUALIFIED","","","import",""],
  ["RC-000055","67010404","BASIC","","2026-01-22","2027-01-22","QUALIFIED","","","import",""],
  ["RC-000056","26016899","HFO144-REF","2026-04-23","2026-04-23","2027-04-23","QUALIFIED","","","import",""],
  ["RC-000057","26016899","HFO145-REF","2026-02-17","2026-02-17","2027-02-17","QUALIFIED","","","import",""],
  ["RC-000058","26016899","BASIC","","2026-01-30","2027-01-30","QUALIFIED","","","import",""],
  ["RC-000059","26013903","HFO144-REF","2026-02-19","2026-02-19","2027-02-19","QUALIFIED","","","import",""],
  ["RC-000060","26013903","HFO145-REF","2026-02-17","2026-02-17","2027-02-17","QUALIFIED","","","import",""],
  ["RC-000061","26013903","BASIC","","2026-01-30","2027-01-30","QUALIFIED","","","import",""],
  ["RC-000062","67000935","HFO144-REF","2026-02-19","2026-02-19","2027-02-19","QUALIFIED","","","import",""],
  ["RC-000063","67000935","HFO145-REF","2026-02-17","2026-02-17","2027-02-17","QUALIFIED","","","import",""],
  ["RC-000064","67000935","BASIC","","2025-03-28","2026-03-28","QUALIFIED","","","import",""],
  ["RC-000065","67004227","HFO145-REF","2026-02-18","2026-02-18","2027-02-18","QUALIFIED","","","import",""],
  ["RC-000066","67004227","BASIC","","2025-05-16","2026-05-16","QUALIFIED","","","import",""],
  ["RC-000067","67002561","HFO145-REF","2026-02-18","2026-02-18","2027-02-18","QUALIFIED","","","import",""],
  ["RC-000068","67002561","BASIC","","2025-05-16","2026-05-16","QUALIFIED","","","import",""],
  ["RC-000069","67007494","HFO145-REF","2026-02-18","2026-02-18","2027-02-18","QUALIFIED","","","import",""],
  ["RC-000070","67007494","BASIC","","2026-01-30","2027-01-30","QUALIFIED","","","import",""],
  ["RC-000071","67000163","HFO144-REF","2026-02-19","2026-02-19","2027-02-19","QUALIFIED","","","import",""],
  ["RC-000072","67000163","BASIC","","2025-03-28","2026-03-28","QUALIFIED","","","import",""],
  ["RC-000073","26013757","HFO144-REF","2026-02-19","2026-02-19","2027-02-19","QUALIFIED","","","import",""],
  ["RC-000074","26013757","BASIC","","2025-03-28","2026-03-28","QUALIFIED","","","import",""],
  ["RC-000075","67002017","HFO144-REF","2026-02-20","2026-02-20","2027-02-20","QUALIFIED","","","import",""],
  ["RC-000076","67002017","BASIC","","2026-02-27","2027-02-27","QUALIFIED","","","import",""],
  ["RC-000077","95164","HFO144-REF","2026-02-20","2026-02-20","2027-02-20","QUALIFIED","","","import",""],
  ["RC-000078","95164","BASIC","","2025-03-28","2026-03-28","QUALIFIED","","","import",""],
  ["RC-000079","26014484","HFO145-NEW","2026-02-23","2026-02-27","2027-02-27","QUALIFIED","","","import",""],
  ["RC-000080","26014484","BASIC","","2025-03-28","2026-03-28","QUALIFIED","","","import",""],
  ["RC-000081","26013612","HFO145-NEW","2026-02-23","2026-02-27","2027-02-27","QUALIFIED","","","import",""],
  ["RC-000082","26013612","BASIC","","2025-10-06","2026-10-06","QUALIFIED","","","import",""],
  ["RC-000083","67002514","HFO145-NEW","2026-02-23","2026-02-27","2027-02-27","QUALIFIED","","","import",""],
  ["RC-000084","67002514","BASIC","","2025-10-03","2026-10-03","QUALIFIED","","","import",""],
  ["RC-000085","67008152","HFO145-NEW","2026-02-23","2026-02-27","2027-02-27","QUALIFIED","","","import",""],
  ["RC-000086","67008152","BASIC","","2025-07-14","2026-07-14","QUALIFIED","","","import",""],
  ["RC-000087","67000809","HFO145-REF","2026-02-27","2026-02-27","2027-02-27","QUALIFIED","","","import",""],
  ["RC-000088","67000809","BASIC","","2025-10-03","2026-10-03","QUALIFIED","","","import",""],
  ["RC-000089","67000410","HFO145-REF","2026-02-27","2026-02-27","2027-02-27","QUALIFIED","","","import",""],
  ["RC-000090","67000410","BASIC","","2025-03-28","2026-03-28","QUALIFIED","","","import",""],
  ["RC-000091","67004226","HFO145-REF","2026-02-27","2026-02-27","2027-02-27","QUALIFIED","","","import",""],
  ["RC-000092","67004226","BASIC","","2025-10-03","2026-10-03","QUALIFIED","","","import",""],
  ["RC-000093","67010228","HFO145-NEW","2026-03-03","2026-03-05","2027-03-05","QUALIFIED","","","import",""],
  ["RC-000094","67010228","BASIC","","2026-01-08","2027-01-08","QUALIFIED","","","import",""],
  ["RC-000095","67008628","HFO145-NEW","2026-03-03","2026-03-05","2027-03-05","QUALIFIED","","","import",""],
  ["RC-000096","67008628","BASIC","","2025-11-13","2026-11-13","QUALIFIED","","","import",""],
  ["RC-000097","67009094","HFO145-NEW","2026-03-03","2026-03-05","2027-03-05","QUALIFIED","","","import",""],
  ["RC-000098","67009094","BASIC","","2025-07-17","2026-07-17","QUALIFIED","","","import",""],
  ["RC-000099","67008973","HFO145-NEW","2026-03-03","","","IN_PROGRESS","","","import",""],
  ["RC-000100","67008973","BASIC","","2025-10-02","2026-10-02","QUALIFIED","","","import",""],
  ["RC-000101","67010229","HFO145-NEW","2026-03-03","2026-03-05","2027-03-05","QUALIFIED","","","import",""],
  ["RC-000102","67010229","BASIC","","2026-02-09","2027-02-09","QUALIFIED","","","import",""],
  ["RC-000103","26013402","HFO144-REF","2026-03-05","2026-03-05","2027-03-05","QUALIFIED","","","import",""],
  ["RC-000104","26013402","BASIC","","2026-02-13","2027-02-13","QUALIFIED","","","import",""],
  ["RC-000105","67002714","HFO144-REF","2026-03-05","2026-03-05","2027-03-05","QUALIFIED","","","import",""],
  ["RC-000106","67002714","HFO145-REF","2026-05-27","2026-05-27","2027-05-27","QUALIFIED","","","import",""],
  ["RC-000107","67002714","BASIC","","2025-08-22","2026-08-22","QUALIFIED","","","import",""],
  ["RC-000108","67004788","HFO145-REF","2026-03-06","2026-03-06","2027-03-06","QUALIFIED","","","import",""],
  ["RC-000109","67004788","BASIC","","2025-09-19","2026-09-19","QUALIFIED","","","import",""],
  ["RC-000110","67006772","HFO145-REF","2026-03-06","2026-03-06","2027-03-06","QUALIFIED","","","import",""],
  ["RC-000111","67006772","BASIC","","2025-12-12","2026-12-12","QUALIFIED","","","import",""],
  ["RC-000112","67003559","HFO145-REF","2026-03-06","2026-03-06","2027-03-06","QUALIFIED","","","import",""],
  ["RC-000113","67003559","BASIC","","2025-11-14","2026-11-14","QUALIFIED","","","import",""],
  ["RC-000114","67003237","HFO145-REF","2026-03-06","2026-03-06","2027-03-06","QUALIFIED","","","import",""],
  ["RC-000115","67003237","BASIC","","2025-08-22","2026-08-22","QUALIFIED","","","import",""],
  ["RC-000116","67000861","HFO145-REF","2026-03-06","2026-03-06","2027-03-06","QUALIFIED","","","import",""],
  ["RC-000117","67000861","BASIC","","2026-01-16","2027-01-16","QUALIFIED","","","import",""],
  ["RC-000118","67007394","HFO145-REF","2026-03-06","2026-03-06","2027-03-06","QUALIFIED","","","import",""],
  ["RC-000119","67007394","BASIC","","2025-04-28","2026-04-28","QUALIFIED","","","import",""],
  ["RC-000120","67001296","HFO144-REF","2026-03-13","2026-03-13","2027-03-13","QUALIFIED","","","import",""],
  ["RC-000121","67001296","HFO145-REF","2026-04-29","2026-04-29","2027-04-29","QUALIFIED","","","import",""],
  ["RC-000122","67001296","BASIC","","2025-08-22","2026-08-22","QUALIFIED","","","import",""],
  ["RC-000123","26001348","HFO144-REF","2026-03-13","2026-03-13","2027-03-13","QUALIFIED","","","import",""],
  ["RC-000124","26001348","BASIC","","2026-02-13","2027-02-13","QUALIFIED","","","import",""],
  ["RC-000125","67001382","HFO144-REF","2026-03-13","2026-03-13","2027-03-13","QUALIFIED","","","import",""],
  ["RC-000126","67001382","HFO145-REF","2026-03-13","2026-03-13","2027-03-13","QUALIFIED","","","import",""],
  ["RC-000127","67001382","BASIC","","2025-04-03","2026-04-03","QUALIFIED","","","import",""],
  ["RC-000128","67010283","HFO145-NEW","2026-03-17","2026-03-23","2027-03-23","QUALIFIED","","","import",""],
  ["RC-000129","67010283","BASIC","","2026-01-15","2027-01-15","QUALIFIED","","","import",""],
  ["RC-000130","67010297","HFO145-NEW","2026-03-17","2026-03-20","2027-03-20","QUALIFIED","","","import",""],
  ["RC-000131","67010297","BASIC","","2026-01-15","2027-01-15","QUALIFIED","","","import",""],
  ["RC-000132","67010312","HFO145-NEW","2026-03-17","2026-03-20","2027-03-20","QUALIFIED","","","import",""],
  ["RC-000133","67010312","BASIC","","2026-01-15","2027-01-15","QUALIFIED","","","import",""],
  ["RC-000134","67010311","HFO145-NEW","2026-03-17","2026-03-20","2027-03-20","QUALIFIED","","","import",""],
  ["RC-000135","67010311","BASIC","","2026-02-16","2027-02-16","QUALIFIED","","","import",""],
  ["RC-000136","67003768","HFO145-REF","2026-03-20","2026-03-20","2027-03-20","QUALIFIED","","","import",""],
  ["RC-000137","67003768","BASIC","","2026-02-27","2027-02-27","QUALIFIED","","","import",""],
  ["RC-000138","67002066","HFO145-REF","2026-03-20","2026-03-20","2027-03-20","QUALIFIED","","","import",""],
  ["RC-000139","67002066","BASIC","","2025-04-21","2026-04-21","QUALIFIED","","","import",""],
  ["RC-000140","67004076","HFO144-REF","2026-04-23","2026-04-23","2027-04-23","QUALIFIED","","","import",""],
  ["RC-000141","67004076","HFO145-REF","2026-03-27","2026-03-27","2027-03-27","QUALIFIED","","","import",""],
  ["RC-000142","67004076","BASIC","","2025-05-16","2026-05-16","QUALIFIED","","","import",""],
  ["RC-000143","67004229","HFO145-REF","2026-03-27","2026-03-27","2027-03-27","QUALIFIED","","","import",""],
  ["RC-000144","67004229","BASIC","","2025-05-16","2026-05-16","QUALIFIED","","","import",""],
  ["RC-000145","67003870","HFO144-REF","2026-05-13","2026-05-13","2027-05-13","QUALIFIED","","","import",""],
  ["RC-000146","67003870","HFO145-REF","2026-03-27","2026-03-27","2027-03-27","QUALIFIED","","","import",""],
  ["RC-000147","67003870","BASIC","","2026-02-27","2027-02-27","QUALIFIED","","","import",""],
  ["RC-000148","67004066","HFO145-NEW","2026-03-23","2026-03-26","2027-03-26","QUALIFIED","","","import",""],
  ["RC-000149","67004066","BASIC","","2025-05-16","2026-05-16","QUALIFIED","","","import",""],
  ["RC-000150","67008627","HFO145-NEW","2026-03-23","2026-03-26","2027-03-26","QUALIFIED","","","import",""],
  ["RC-000151","67008627","BASIC","","2025-09-04","2026-09-04","QUALIFIED","","","import",""],
  ["RC-000152","67009237","HFO145-NEW","2026-03-23","2026-03-26","2027-03-26","QUALIFIED","","","import",""],
  ["RC-000153","67009237","BASIC","","2025-10-23","2026-10-23","QUALIFIED","","","import",""],
  ["RC-000154","67008911","HFO145-NEW","2026-03-23","2026-03-26","2027-03-26","QUALIFIED","","","import",""],
  ["RC-000155","67008911","BASIC","","2025-11-24","2026-11-24","QUALIFIED","","","import",""],
  ["RC-000156","26013252","HFO145-NEW","2026-04-07","2026-04-10","2027-04-10","QUALIFIED","","","import",""],
  ["RC-000157","26013252","BASIC","","2026-04-02","2027-04-02","QUALIFIED","","","import",""],
  ["RC-000158","67010227","HFO145-NEW","2026-04-07","2026-04-10","2027-04-10","QUALIFIED","","","import",""],
  ["RC-000159","67010227","BASIC","","2026-02-09","2027-02-09","QUALIFIED","","","import",""],
  ["RC-000160","67000750","HFO145-REF","2026-04-22","2026-04-22","2027-04-22","QUALIFIED","","","import",""],
  ["RC-000161","67000750","BASIC","","2026-01-30","2027-01-30","QUALIFIED","","","import",""],
  ["RC-000162","67003760","HFO145-REF","2026-04-22","2026-04-22","2027-04-22","QUALIFIED","","","import",""],
  ["RC-000163","67003760","BASIC","","2026-01-30","2027-01-30","QUALIFIED","","","import",""],
  ["RC-000164","67002357","HFO145-REF","2026-04-21","2026-04-21","2027-04-21","QUALIFIED","","","import",""],
  ["RC-000165","67002357","BASIC","","2025-04-21","2026-04-21","QUALIFIED","","","import",""],
  ["RC-000166","67011896","HFO145-NEW","2026-04-27","2026-04-30","2027-04-30","QUALIFIED","","","import",""],
  ["RC-000167","67011896","BASIC","","2026-04-23","2027-04-23","QUALIFIED","","","import",""],
  ["RC-000168","67011906","HFO145-NEW","2026-04-27","2026-04-30","2027-04-30","QUALIFIED","","","import",""],
  ["RC-000169","67011906","BASIC","","2026-04-23","2027-04-23","QUALIFIED","","","import",""],
  ["RC-000170","67004352","HFO145-REF","2026-04-29","2026-04-29","2027-04-29","QUALIFIED","","","import",""],
  ["RC-000171","67004352","BASIC","","2025-08-22","2026-08-22","QUALIFIED","","","import",""],
  ["RC-000172","67002465","HFO145-REF","2026-04-29","2026-04-29","2027-04-29","QUALIFIED","","","import",""],
  ["RC-000173","67002465","BASIC","","2025-08-22","2026-08-22","QUALIFIED","","","import",""],
  ["RC-000174","67004281","HFO145-REF","2026-04-29","2026-04-29","2027-04-29","QUALIFIED","","","import",""],
  ["RC-000175","67004281","BASIC","","2025-08-22","2026-08-22","QUALIFIED","","","import",""],
  ["RC-000176","67001385","HFO144-REF","2026-04-30","2026-04-30","2027-04-30","QUALIFIED","","","import",""],
  ["RC-000177","67001385","HFO145-REF","2026-04-29","2026-04-29","2027-04-29","QUALIFIED","","","import",""],
  ["RC-000178","67001385","BASIC","","2025-10-17","2026-10-17","QUALIFIED","","","import",""],
  ["RC-000179","67007277","HFO145-REF","2026-05-12","2026-05-12","2027-05-12","QUALIFIED","","","import",""],
  ["RC-000180","67007277","BASIC","","2026-04-24","2027-04-24","QUALIFIED","","","import",""],
  ["RC-000181","67007278","HFO145-REF","2026-05-12","2026-05-12","2027-05-12","QUALIFIED","","","import",""],
  ["RC-000182","67007278","BASIC","","2026-03-27","2027-03-27","QUALIFIED","","","import",""],
  ["RC-000183","62006095","HFO144-REF","2026-05-26","2026-05-26","2027-05-26","QUALIFIED","","","import",""],
  ["RC-000184","62006095","HFO145-REF","2026-05-27","2026-05-27","2027-05-27","QUALIFIED","","","import",""],
  ["RC-000185","62006095","BASIC","","2026-05-08","2027-05-08","QUALIFIED","","","import",""],
  ["RC-000186","67003333","HFO144-REF","2026-05-26","2026-05-26","2027-05-26","QUALIFIED","","","import",""],
  ["RC-000187","67003333","BASIC","","2025-11-14","2026-11-14","QUALIFIED","","","import",""],
  ["RC-000188","67002682","HFO145-REF","2026-05-27","2026-05-27","2027-05-27","QUALIFIED","","","import",""],
  ["RC-000189","67002682","BASIC","","2025-08-22","2026-08-22","QUALIFIED","","","import",""],
  ["RC-000190","67000776","HFO145-REF","2026-05-27","2026-05-27","2027-05-27","QUALIFIED","","","import",""],
  ["RC-000191","67000776","BASIC","","2025-10-17","2026-10-17","QUALIFIED","","","import",""],
  ["RC-000192","67012863","HFO145-NEW","2026-06-01","","","IN_PROGRESS","","","import",""],
  ["RC-000193","67012863","BASIC","","2026-05-29","2027-05-29","QUALIFIED","","","import",""],
  ["RC-000194","67012873","HFO145-NEW","2026-06-01","","","IN_PROGRESS","","","import",""],
  ["RC-000195","67012873","BASIC","","2026-05-29","2027-05-29","QUALIFIED","","","import",""]
];

/** แปลง 'yyyy-MM-dd' -> Date ; ค่าว่างคงเดิม */
function seedParseDate_(v) {
  if (!v || typeof v !== 'string') return v;
  var m = v.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return v;
  return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
}

/** นำเข้าข้อมูล seed (bulk setValues — เร็ว ไม่ชน execution limit) */
function importSeedData(force) {
  // 🛡️ กันลบข้อมูลจริง: ถ้ามี Ticket อยู่แล้ว = ระบบใช้งานจริง -> import จะลบ Employees/records ทิ้ง!
  //    ต้องยืนยันด้วย importSeedData(true) (setup ครั้งแรกผ่านได้เพราะยังไม่มี Ticket)
  if (force !== true) {
    var existingTk = readAll_('Tickets');
    if (existingTk.length > 0) {
      return skippedSeedImport_(existingTk.length, 'Import');
    }
  }
  var dateColsEmp = [];                 // Employees ไม่มีคอลัมน์วันที่
  var dateColsRec = [3, 4, 5];          // OverviewDate, QualifiedDate, ExpiryDate
  var now = new Date();

  // อัปเดตคอร์สให้ตรงกับ records ที่กำลังจะนำเข้า (กัน CourseID เก่าค้าง)
  resyncCourses_();

  // Employees
  var emp = SEED_EMPLOYEES.map(function (r) { return r.slice(); });
  _bulkWrite_('Employees', emp, dateColsEmp, -1);

  // TrainingRecords (เติม UpdatedAt = now ที่คอลัมน์สุดท้าย)
  var rec = SEED_RECORDS.map(function (r) {
    var c = r.slice(); c[c.length - 1] = now; return c;
  });
  _bulkWrite_('TrainingRecords', rec, dateColsRec, -1);

  getSpreadsheet_().toast(
    'Imported ' + emp.length + ' employees and ' + rec.length + ' records', 'Import', 6);
  return { employees: emp.length, records: rec.length, skippedImport: false };
}

function skippedSeedImport_(ticketCount, toastTitle) {
  var currentEmployees = readAll_('Employees').length;
  var currentRecords = readAll_('TrainingRecords').length;
  var msg = 'Seed import skipped because ' + ticketCount +
    ' ticket(s) already exist. Use initWithData(true) or importSeedData(true) only if you want to overwrite employee and training record data.';
  getSpreadsheet_().toast(msg, toastTitle || 'Import', 8);
  return {
    employees: currentEmployees,
    records: currentRecords,
    tickets: ticketCount,
    skippedImport: true,
    message: msg,
  };
}

/**
 * ติดตั้งระบบ + เขียนข้อมูลจริงลง DB ในขั้นตอนเดียว (รันครั้งเดียวจากเมนู Run)
 *   1) สร้างชีตทั้งหมด + คอร์ส + admin + หัวหน้างาน
 *   2) เขียนพนักงาน 90 คน + training records ลงตาราง
 */
function initWithData(force) {
  setupDatabase();

  if (force !== true) {
    var existingTk = readAll_('Tickets');
    if (existingTk.length > 0) {
      return skippedSeedImport_(existingTk.length, 'Done');
    }
  }

  var res = importSeedData(force);
  getSpreadsheet_().toast(
    'Ready: ' + res.employees + ' employees, ' + res.records + ' records', 'Done', 6);
  return res;
}

/**
 * เติมเฉพาะ "BASIC records" เข้าตาราง TrainingRecords แบบปลอดภัย (additive)
 *  - ไม่ลบ HFO records / Tickets ทิ้ง (ต่างจาก importSeedData ที่เขียนทับ)
 *  - ข้ามคนที่มี BASIC record อยู่แล้ว (idempotent — รันซ้ำได้)
 *  - sync คอร์สให้มี BASIC ก่อน
 * ใช้กรณีระบบมีข้อมูลใช้งานจริงแล้ว แต่ต้องการเพิ่มคอลัมน์ Basic เข้าไป
 */
function importBasicRecords() {
  resyncCourses_(); // ให้ชีต Courses มี BASIC เป็นคอร์สแรก

  const existing = readAll_('TrainingRecords');
  const seen = {};
  let maxNum = 0;
  existing.forEach(r => {
    seen[String(r.EN) + '|' + String(r.CourseID)] = true;
    const m = String(r.RecordID || '').match(/(\d+)$/);
    if (m) maxNum = Math.max(maxNum, parseInt(m[1], 10));
  });

  const now = new Date();
  const header = SCHEMA.TrainingRecords.header;
  const toAdd = [];
  SEED_RECORDS.filter(r => r[2] === 'BASIC').forEach(r => {
    const key = String(r[1]) + '|BASIC';
    if (seen[key]) return;               // มี Basic ของคนนี้แล้ว -> ข้าม
    seen[key] = true;
    maxNum++;
    toAdd.push([
      'RC-' + String(maxNum).padStart(6, '0'), r[1], 'BASIC',
      seedParseDate_(r[3]), seedParseDate_(r[4]), seedParseDate_(r[5]),
      r[6], r[7], r[8], 'import-basic', now,
    ]);
  });

  if (toAdd.length) {
    const sh = getSheet_('TrainingRecords');
    sh.getRange(sh.getLastRow() + 1, 1, toAdd.length, header.length).setValues(toAdd);
  }
  getSpreadsheet_().toast(
    'Added ' + toAdd.length + ' BASIC records (skipped existing)', 'Basic', 6);
  return { added: toAdd.length, alreadyHad: 89 - toAdd.length };
}

function _bulkWrite_(tableKey, rows, dateCols, _unused) {
  var sh = getSheet_(tableKey);
  var header = SCHEMA[tableKey].header;
  clearDataRows_(sh); // ล้างข้อมูลเดิม (เก็บ header) — ไม่ลบแถว เลี่ยง error 'delete all non-frozen rows'
  if (!rows.length) return;
  // แปลงคอลัมน์วันที่
  rows.forEach(function (r) {
    dateCols.forEach(function (ci) { r[ci] = seedParseDate_(r[ci]); });
  });
  sh.getRange(2, 1, rows.length, header.length).setValues(rows);
}
