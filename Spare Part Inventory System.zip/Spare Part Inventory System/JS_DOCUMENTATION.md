# Spare Part Inventory System — Project Documentation

> **Last updated:** 2026-06-15

---

## Changelog

### 2026-06-15 (security) — Login Rate-limiting / Brute-force Protection

> เป้าหมาย: กันการเดารหัสผ่านแบบยิงรัว (brute-force / password-spray) ที่ฝั่ง server

**สรุป:** เพิ่มการนับครั้ง login ผิด **ต่อ username** ใน `CacheService` แล้วล็อกชั่วคราวเมื่อผิดบ่อยเกินไป
(ของเดิมกันแค่ฝั่ง client `loginAttempts >= 3` ซึ่ง bypass ได้ง่าย)

**กลไก (`login()` ใน Code.gs):**

1. ตรวจก่อนเลยว่า username นี้ถูกล็อกอยู่ไหม — ถ้าล็อก คืน `{status:'locked', retryAfter}` **ทันที (ไม่แตะชีต)**
2. ถ้ารหัสผิด → `registerLoginFailure_()` เพิ่มตัวนับ; ครบเพดานก็ตั้ง lock
3. ถ้ารหัสถูก → `clearLoginFailures_()` ล้างตัวนับ
4. นับครั้งผิด**รวมกรณี username ไม่มีจริง** เพื่อกัน enumeration / password-spray
5. read-modify-write ตัวนับอยู่ใต้ `LockService` (login ถือ lock อยู่แล้ว) จึงไม่ race

**ค่าคงที่ (ปรับได้):**

```js
var LOGIN_MAX_ATTEMPTS   = 5;    // ผิดกี่ครั้งก่อนล็อก
var LOGIN_WINDOW_SECONDS = 900;  // หน้าต่างนับครั้งผิด (15 นาที)
var LOGIN_LOCKOUT_SECONDS = 900; // ระยะเวลาล็อก (15 นาที)
```

**Cache keys:** `lf_<username>` = ตัวนับครั้งผิด, `ll_<username>` = เวลาปลดล็อก (epoch ms)

**Helpers ใหม่ (Code.gs):** `loginLockRemaining_`, `registerLoginFailure_`, `clearLoginFailures_`, `loginFailKey_`, `loginLockKey_`

**Client (JS.html) — `performLogin` รองรับสถานะใหม่:**

- `status:'locked'` → แสดง lock-msg + ปุ่มขอรีเซ็ตรหัส + alert "ลองใหม่ใน X นาที"
- `status:'invalid'` (มี `remaining`) → แสดง "เหลืออีก N ครั้งก่อนถูกล็อก"

**Deploy:** push `Code.gs` + `JS.html` แล้ว Deploy ใหม่ — **ไม่มีคอลัมน์ชีตเพิ่ม** (ใช้ CacheService ล้วน)

**ข้อจำกัด:** GAS เข้าถึง client IP ไม่ได้ จึงล็อกแบบ per-username → อาจถูกใช้กลั่นแกล้งล็อกบัญชีคนอื่นชั่วคราว (15 นาที) เป็น trade-off มาตรฐาน

---

### 2026-06-15 (security) — Server-side Auth, Hashed Passwords & Write Authorization

> เป้าหมาย: ปิดช่องโหว่ "รหัสผ่าน plaintext + ตรวจ login ฝั่ง client" และ "ไม่มี authorization ฝั่ง server"

**สรุป:** ย้ายการยืนยันตัวตนและการตรวจสิทธิ์ทั้งหมดไปฝั่ง server ใช้ระบบ **token (session)** + **password hashing (SHA-256 + salt)**

| ด้าน | เดิม | ใหม่ |
| --- | --- | --- |
| เก็บรหัสผ่าน | plaintext ใน sheet | `passwordHash` (SHA-256) + `salt` ต่อ user, ลบ plaintext |
| ส่งให้ client | ส่ง users ทั้งก้อน **รวม password** | ส่ง users ที่ **strip password/hash/salt** ออกแล้ว |
| ตรวจ login | ฝั่ง client (`state.users.find`) | ฝั่ง server `login()` → คืน **token** |
| โหลดข้อมูล | `getInitialData()` เปิดให้ทุกคน | `getInitialData(token)` ต้อง login ก่อน |
| เขียนข้อมูล | `applyDelta` ใครก็เขียนได้ | `applyDelta(token, ...)` ต้องมี session ที่ valid |
| แก้ user | ผ่าน delta (ใครก็ส่งได้) | endpoint เฉพาะ + ตรวจสิทธิ์ Admin (`adminSaveUser`/`adminDeleteUser`) |
| เปลี่ยนรหัสตัวเอง | client เซ็ต `password` ตรงๆ | `changeOwnPassword(token, ...)` (hash ฝั่ง server) |
| ส่งอีเมล/Reset | `saveDataToServer` ทั้งก้อน | `saveDataToServer(token, ...)` (Admin only), email ต้องมี token |

**กลไกหลัก:**

- **Token store:** `CacheService` (ScriptCache) เก็บ `sess_<token>` → `{en, role, accessCategory, ...}` อายุ 6 ชม. (sliding TTL)
- **Brute-force protection (server-side):** นับครั้ง login ผิดต่อ username ใน `CacheService` — ผิดครบ **5 ครั้งใน 15 นาที → ล็อก 15 นาที** (`login()` คืน `status:'locked'` + `retryAfter`); login สำเร็จล้างตัวนับ; นับรวมกรณี username ไม่มีจริงเพื่อกัน spray/enumeration
- **`'users'` ออกจาก delta sync แล้ว** — การแก้ user ทุกอย่างผ่าน endpoint เฉพาะที่ตรวจสิทธิ์; `applyDelta` จะ **บล็อก** key `users`
- **Migration อัตโนมัติ:** user เก่าที่เป็น plaintext จะถูก hash ครั้งแรกที่ login สำเร็จ และตอน `getInitialData` (ยัง login ด้วยรหัสเดิมได้ตามปกติ)
- **Default admin:** ถ้า Users sheet ว่าง ระบบ seed `admin / admin01` (เก็บเป็น hash) ให้อัตโนมัติ

**Server endpoints ใหม่ (Code.gs):** `login`, `validateSession`, `logout`, `submitPasswordResetRequest`, `changeOwnPassword`, `adminSaveUser`, `adminDeleteUser` + helpers `hashPassword_`/`requireAuth_`/`requireAdmin_`/`sanitizeUser_`/`createSession_`

**Client (JS.html):** `authToken` (เก็บใน `sessionStorage`), `performLogin`/`logout`/`checkAuth`/`loadInitialData` ใช้ token, `saveUserForm`/`delUser`/`submitChangePassword`/`requestPasswordReset` เรียก endpoint ใหม่, `handleAuthExpired()` บังคับ login ใหม่เมื่อ session หมดอายุ

**⚠️ ตอน deploy:**

1. Push ทั้ง `Code.gs` + `JS.html` แล้ว Deploy เวอร์ชันใหม่
2. ครั้งแรกที่ login ระบบจะเพิ่มคอลัมน์ `salt`, `passwordHash` และเคลียร์คอลัมน์ `password` ในชีต Users (อัตโนมัติ) — **อย่าลบคอลัมน์เหล่านี้**
3. ผู้ใช้เดิม login ด้วย username/รหัสผ่านเดิมได้ทันที (ระบบ hash ให้เอง)

---

### 2026-06-15 — Concurrency-safe saving (Delta Sync) + UI credit

> เป้าหมาย: ทำให้ใช้งานพร้อมกันหลายคนได้โดยข้อมูลไม่หาย (แก้ปัญหา "เซฟทับทั้งตาราง")

**สรุปการเปลี่ยนแปลงเชิงสถาปัตยกรรม:** จากเดิม client ส่ง state ทั้งก้อนไปเขียนทับทุก sheet
→ เปลี่ยนเป็น **ส่งเฉพาะแถวที่เปลี่ยน (delta) แล้ว server merge ราย-แถวภายใต้ `LockService`**

| ด้าน | เดิม | ใหม่ |
| --- | --- | --- |
| รูปแบบการเซฟ | `saveDataToServer(state ทั้งก้อน)` → เขียนทับทุก sheet | `applyDelta(เฉพาะแถวที่เปลี่ยน)` → merge ราย-แถว |
| Concurrency | Last-writer-wins ทั้ง sheet → **ข้อมูลคนอื่นหาย** | แก้คนละแถว = เก็บครบ, แก้แถวเดียวกัน = last-writer-wins (เฉพาะแถวนั้น) |
| Lock | ไม่มี | `LockService.getScriptLock()` กันเขียนชนกัน |
| Primary Key | ไม่มี | ทุกแถวมี **`_id`** (UUID) ใช้อ้างอิงตอน merge |
| ปริมาณการเขียน | เขียนทุก sheet ทุกครั้ง | เขียนเฉพาะ sheet/แถวที่เปลี่ยน (ไม่เปลี่ยน = ไม่ยิง server) |

**ไฟล์ที่แก้:**

- **`Code.gs`**: เพิ่ม `applyDelta()`, `getDb_()`, `ensureIds_()`, ค่าคงที่ `DB_SPREADSHEET_ID` + `SHEET_MAP`; ครอบ `LockService` ทั้ง `applyDelta` และ `saveDataToServer`; `getInitialData()` backfill `_id` ให้ทุก sheet
- **`JS.html`**: เพิ่มชุด delta (`genId`, `ensureRowIds`, `ensureAllIds`, `captureBaseline`, `computeDelta`); เขียน `saveData()` ใหม่ให้ส่ง delta; เพิ่ม `captureBaseline()` ที่ทุกจุดโหลดข้อมูล; เพิ่ม **sort ตามเวลา** ใน 5 ตาราง (requests / PO / support / withdrawal history / edit history) เพื่อคง "ใหม่สุดอยู่บน"
- **`Index.html`**: เพิ่ม floating watermark มุมขวาล่าง (`#app-watermark`) — "Developed by Pantawat Tantem · pantawatt@celestica.com"

**⚠️ ต้องทำตอน deploy:**

1. Push โค้ดขึ้น Apps Script แล้ว **Deploy เวอร์ชันใหม่**
2. ครั้งแรกที่เปิดเว็บ ระบบจะเติมคอลัมน์ **`_id`** ให้ทุกแถวในทุก sheet อัตโนมัติ (one-time migration) — **ห้ามลบคอลัมน์ `_id`**
3. แนะนำเปิดทดสอบ 1 ครั้งให้ migration ทำงานก่อนเปิดใช้งานจริงหลายคน

---

## Project Overview

ระบบจัดการสต็อกอะไหล่ทำงานบน **Google Apps Script Web App** ประกอบด้วย 4 ไฟล์หลัก:

| ไฟล์ | หน้าที่ |
| --- | --- |
| Code.gs | Backend: Google Apps Script — อ่าน/เขียน Google Sheets + Email |
| Index.html | HTML Structure: Layout, Sidebar, Sections, Modals ทั้งหมด |
| CSS.html | Styles: Design tokens, Components, Animations |
| JS.html | Frontend Logic: State, Events, API calls, Rendering |

**Google Sheets ID:** `1TrtU1iQgSeQckKWfhX137IMZLE2C95N12WgcBVtxZT8`

**External Libraries:**

- Google Charts — Column Chart, Donut Chart ใน Reports
- SheetJS 0.18.5 (CDN) — Export `.xlsx`

---

## Architecture

```text
[User Browser]
      |
      | google.script.run (Client-Server Bridge)
      ↓
[Google Apps Script (Code.gs)]
      |
      ├── SpreadsheetApp → Google Sheets (Database)  [getDb_() = openById]
      │     ├── Sheet: Users           (+ _id column)
      │     ├── Sheet: Parts           (+ _id column)
      │     ├── Sheet: Requests        (+ _id column)
      │     ├── Sheet: PO              (+ _id column)
      │     ├── Sheet: HistoryWD        (+ _id column)
      │     ├── Sheet: HistoryED        (+ _id column)
      │     └── Sheet: SupportTickets   (+ _id column)
      │
      ├── LockService → กันการเขียนชนกันระหว่างผู้ใช้หลายคน
      └── MailApp → Email Notifications (Real-time)

[HTML Build Pipeline]
  Index.html
    ├── <?!= include('CSS') ?>  ← CSS.html inject ตอน serve
    ├── <?!= include('JS') ?>   ← JS.html inject ตอน serve
    └── #app-watermark          ← เครดิตผู้พัฒนา (floating, มุมขวาล่าง)
```

**Data Flow:**

```text
Login (ฝั่ง server)
  └─ login(username, password)    ← ตรวจ hash + rate-limit → คืน { token, user(sanitized) }
        └─ เก็บ authToken ใน sessionStorage → loadInitialData()

loadInitialData()  /  checkAuth() (เมื่อ session ยัง valid)
  └─ google.script.run.getInitialData(authToken)   ← 🔒 ต้อง login ก่อน
        └─ (one-time) backfill _id + hash passwords ทุก sheet
        └─ state ← Google Sheets data (users ถูก strip password/hash/salt)
        └─ captureBaseline()   ← snapshot ไว้เทียบหา delta
        └─ initSystem() → render UI

User Action (Save/Edit/Delete)
  └─ update state (RAM)            ← เช่น state.parts.push / splice / แก้ field
  └─ saveData()
        ├─ localStorage.setItem(...)        ← local cache
        ├─ ensureAllIds()                   ← ทุกแถวต้องมี _id
        ├─ computeDelta()                   ← เทียบกับ baseline → {upserts, deletes} (ไม่รวม users)
        │     └─ ถ้าไม่มีอะไรเปลี่ยน → setSyncState('synced') แล้ว return (ไม่ยิง server)
        └─ google.script.run.applyDelta(authToken, delta)   ← 🔒
              └─ requireAuth_(token) + LockService.waitLock()
              └─ อ่านข้อมูลล่าสุด → merge เฉพาะแถวใน delta → เขียนกลับ (บล็อก key users)
              └─ success → captureBaseline()  ← เลื่อน baseline

User / Password management (ไม่ผ่าน delta)
  └─ adminSaveUser(token,...) / adminDeleteUser(token,...) / changeOwnPassword(token,...)
        └─ ตรวจสิทธิ์ (Admin/เจ้าของ) + hash → เขียน Users → คืน users(sanitized)

Email Notification (fire-and-forget)
  └─ sendNotification(type, payload)
        └─ google.script.run.sendEmailNotification(authToken, type, payload)   ← 🔒
              └─ MailApp.sendEmail(...)

Auto-refresh every 30s
  └─ doRefresh() → getInitialData(authToken) → update state → captureBaseline() → re-render

Reset ทั้งระบบ (Admin)
  └─ resetUserData() → saveDataToServer(authToken, state ทั้งก้อน)  ← full-overwrite, Admin only
```

> **Concurrency model:** การเซฟปกติใช้ **delta merge ราย-แถว** จึงไม่ทับงานของคนอื่นที่แก้คนละแถว
> ส่วน `saveDataToServer` (เขียนทับทั้งฐานข้อมูล) ถูกสงวนไว้ใช้เฉพาะ **Reset** เท่านั้น ดูรายละเอียดหัวข้อ [Delta Sync](#delta-sync-row-level-merge)

---

## State Object (Global Application State)

```js
let state = {
    users: [],          // User objects
    parts: [],          // Part objects
    requests: [],       // Pending withdrawal requests
    po: [],             // Purchase Orders
    historyWD: [],      // Withdrawal history (approved/rejected)
    historyED: [],      // Stock edit history (audit trail)
    supportTickets: [], // Support/issue tickets
    currentUser: null   // Logged-in user object
}
```

### Data Schemas

> **หมายเหตุ:** ทุก schema มี field **`_id`** (UUID string) เพิ่มเข้ามาตั้งแต่ 2026-06-15
> ใช้เป็น primary key สำหรับ delta merge ฝั่ง server — ระบบจัดการให้อัตโนมัติ ไม่ต้องตั้งเอง และไม่แสดงใน UI/CSV

**User:**

```js
{ _id,                  // UUID — primary key (อัตโนมัติ)
  en, name, email,      // email ใช้สำหรับ Email Notifications ด้วย
  position,
  role: 'Admin'|'Manager'|'Technician'|'Operator',
  username,
  // 🔒 server เท่านั้น (ไม่เคยส่งให้ client):
  passwordHash,         // SHA-256(salt + '::' + password)
  salt,                 // per-user salt
  password,             // legacy plaintext — ว่าง/ถูกลบหลัง migrate เป็น hash
  status: 'Active'|'Inactive',
  accessCategory: 'All'|'Splicing'|'Optical Support' }
```

> ⚠️ `getInitialData` / `login` / `validateSession` คืน user ที่ **strip `password`/`passwordHash`/`salt` ออกแล้ว** เสมอ
> และ `users` **ไม่อยู่ในชุด delta sync** — แก้ผ่าน `adminSaveUser` / `adminDeleteUser` / `changeOwnPassword` เท่านั้น

**Part:**

```js
{ _id,             // UUID — primary key (อัตโนมัติ)
  part_no, name,
  category: 'Splicing'|'Optical Support',
  group,           // default: 'General'
  qty, min,
  location,        // default: 'Central Store'
  supplier,
  status: 'In Stock'|'Low Stock'|'Out of Stock',
  image            // base64 JPEG or null }
```

**Request:**

```js
{ _id,                  // UUID — primary key สำหรับ merge (คนละตัวกับ id ด้านล่าง)
  id: 'REQ-timestamp',  // business id ใช้ใน UI (approveReq/rejectReq อ้างตัวนี้)
  part_no, part_name, qty,
  requester, en, station,
  status: 'Pending'|'Approved'|'Approved (Tech Self-Confirmed)'|'Rejected',
  timestamp,
  details: { machine_sn, reason, remark },
  actionTime, actionBy, note }
```

**PO:**

```js
{ _id,                  // UUID — primary key สำหรับ merge
  id: 'PO-timestamp', date,
  part_no, part_name, qty,
  received_qty,
  status: 'Pending Approval'|'Ordered'|'In Transit'|'Delayed'|'Received'|'Cancelled',
  requester, en, reason }   // en: เพิ่มแล้ว (fix)
```

---

## Code.gs — Backend

### ฟังก์ชัน

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `doGet(e)` | Entry point: serve `index.html` เป็น Web App, set viewport meta |
| `include(filename)` | Helper สำหรับ `<?!= include('CSS') ?>` / `<?!= include('JS') ?>` |
| `getDb_()` | คืน Spreadsheet ตัวฐานข้อมูล (`openById(DB_SPREADSHEET_ID)`) — รวมที่เดียว ไม่ hardcode ซ้ำ |
| `ensureIds_(rows)` | เติม `_id` (UUID) ให้แถวที่ยังไม่มี — คืน `true` ถ้ามีการเปลี่ยนแปลง |
| `getInitialData(token)` | 🔒 (ต้อง login) โหลดข้อมูลทุก sheet + migration + backfill `_id` + **hash passwords** → คืน users ที่ sanitize แล้ว |
| `applyDelta(token, deltaString)` | 🔒 **(หลัก)** รับเฉพาะแถวที่เปลี่ยน → merge ราย-แถว ภายใต้ `LockService` (บล็อก key `users`) |
| `saveDataToServer(token, stateString)` | 🔒 **(Admin only, เฉพาะ Reset)** เขียนทับทุก sheet ภายใต้ `LockService` |
| `login(username, password)` | ตรวจรหัสผ่าน (hash) → คืน `{token, user}` ; upgrade plaintext→hash อัตโนมัติ |
| `validateSession(token)` | ตรวจ session ตอนรีโหลดหน้า → คืน user ล่าสุด (sanitized) |
| `logout(token)` | ทำลาย session |
| `submitPasswordResetRequest(username)` | (ไม่ต้องใช้ token) สร้าง support ticket + แจ้ง Admin |
| `changeOwnPassword(token, payload)` | 🔒 เปลี่ยนรหัสตัวเอง (ยืนยัน en/name/email) → hash |
| `adminSaveUser(token, userJson)` | 🔒 (Admin) สร้าง/แก้ user (hash password, เว้นว่าง=คงเดิม) |
| `adminDeleteUser(token, en)` | 🔒 (Admin) ลบ user (กันลบตัวเอง/Admin คนสุดท้าย) |
| `sendEmailNotification(token, type, payload)` | 🔒 wrapper ที่ต้อง login → เรียก `sendEmailNotificationInternal_` |
| `getSheetData(ss, sheetName)` | อ่าน sheet → แปลง row เป็น array of objects, Date → ISO string |
| `writeSheetData(ss, sheetName, dataArray)` | เขียน array of objects ลง sheet (auto-add missing columns) |
| `uploadImageToDrive(base64, fileName)` | อัปโหลดรูปไปยัง Google Drive folder `Inventory_Images` (ยังไม่ได้เรียกจาก frontend) |
| `forceAuthorize()` | สร้างไฟล์ทดสอบเพื่อ authorize Drive + MailApp permission (run ครั้งเดียว) |
| `sendEmailNotification(type, payload)` | ส่ง email ตาม event type, หา recipient จาก Users sheet |
| `emailWrap(...)` | HTML email layout template |
| `emailRows(rows)` | สร้าง info table ใน email |
| `emailAlert(color, text)` | Alert box ใน email |
| `nowTH()` | timestamp format `dd/MM/yyyy HH:mm:ss` |
| `emailNewRequest(p)` | HTML email: คำขอเบิกใหม่ |
| `emailRequestApproved(p)` | HTML email: อนุมัติแล้ว |
| `emailRequestRejected(p)` | HTML email: ปฏิเสธ + เหตุผล |
| `emailTechConfirmed(p)` | HTML email: Tech ยืนยันรับ |
| `emailLowStock(p)` | HTML email: สต็อกใกล้หมด |
| `emailOutOfStock(p)` | HTML email: สต็อกหมด |
| `emailSupportTicket(p)` | HTML email: Support ticket ใหม่ |
| `emailPasswordReset(p)` | HTML email: คำขอ reset password |

### Data Migration (ใน getInitialData)

เมื่อโหลดข้อมูล จะ auto-fix ค่าที่ขาดหาย:

**Users migration:**

- `accessCategory` ว่าง → set เป็น `'All'`

**Parts migration:**

- `category` ว่าง → `'Splicing'`
- `group` ว่าง → `'General'`
- `location` ว่าง → `'Central Store'`
- `supplier` undefined → `''`
- `min`/`qty` undefined → `0`
- คำนวณ `status` ใหม่ทุกครั้ง

**`_id` backfill (ทุก sheet):**

- แถวใดไม่มี `_id` → เติม `Utilities.getUuid()` แล้วเขียนกลับ (เกิดครั้งเดียวตอนข้อมูลเก่ายังไม่มี `_id`)
- หลัง backfill ครบแล้ว การโหลดครั้งถัดไปจะไม่เขียนซ้ำ

### writeSheetData — การเขียนลง Sheet

1. ถ้า sheet ว่าง → สร้าง header row จาก `Object.keys(dataArray[0])`
2. ถ้ามี key ใหม่ใน data ที่ยังไม่มี header → append column ใหม่ต่อท้าย
3. ล้าง data rows เดิมออก แล้วเขียนแถวใหม่ทั้งหมด
4. String ที่เป็นตัวเลขหรือ ISO date จะถูก prefix `'` เพื่อป้องกัน Sheets auto-convert

### Email Notification System

**Recipient Logic:**

| Event Type | ส่งให้ |
| --- | --- |
| `NEW_REQUEST` | Admin + Manager (Active, มี email) |
| `REQUEST_APPROVED` | ผู้เบิก (ค้นจาก EN) — fallback Admin+Manager |
| `REQUEST_REJECTED` | ผู้เบิก (ค้นจาก EN) — fallback Admin+Manager |
| `TECH_CONFIRMED` | Admin + Manager |
| `LOW_STOCK` | Admin + Manager |
| `OUT_OF_STOCK` | Admin + Manager |
| `SUPPORT_TICKET` | Admin เท่านั้น — fallback Admin+Manager |
| `PASSWORD_RESET` | Admin เท่านั้น — fallback Admin+Manager |

**หมายเหตุ:** ถ้าไม่มี recipient → log แล้ว skip (ไม่ throw error)

---

## Delta Sync (Row-Level Merge)

> ระบบบันทึกข้อมูลแบบกัน data loss ตอนใช้งานหลายคนพร้อมกัน — เพิ่ม 2026-06-15

### ปัญหาเดิม

`saveData()` เดิมส่ง `state` **ทั้งก้อน** ไปเขียนทับทุก sheet ดังนั้นถ้า 2 คนเปิดพร้อมกัน
คนที่กดเซฟทีหลังจะเขียนทับงานของคนแรกทั้งหมด (lost update) — ยิ่งมี auto-refresh 30s ยิ่งเสี่ยง

### วิธีแก้

แยกเป็น 3 ส่วน: **`_id` (primary key)** + **delta (เฉพาะส่วนต่าง)** + **merge ฝั่ง server ใต้ lock**

```text
Client                                    Server (applyDelta)
──────                                    ───────────────────
captureBaseline()  ← snapshot ตอนโหลด
   │
   │ ผู้ใช้แก้ state (push/splice/แก้ field)
   ↓
saveData()
   ├─ ensureAllIds()       ทุกแถวมี _id
   ├─ computeDelta()        เทียบ state vs baseline
   │     → { parts: { upserts:[...], deletes:[...] }, ... }
   └─ applyDelta(token, delta) ────────→  requireAuth_(token) + LockService.waitLock(30s)
                                          for แต่ละ sheet ใน delta (ข้าม key users):
                                            1. อ่านข้อมูลล่าสุด (source of truth)
                                            2. index ด้วย _id
                                            3. ลบ id ใน deletes
                                            4. upsert แถวใน upserts (ทับ/เพิ่ม)
                                            5. เขียนกลับทั้ง sheet (merged)
                                          releaseLock()
   captureBaseline() ←── success ─────────  { status:'success', applied:[...] }
```

### คุณสมบัติ

| สถานการณ์ | ผลลัพธ์ |
| --- | --- |
| A แก้แถว X, B แก้แถว Y (คนละแถว) | **เก็บทั้งคู่** (merge เข้าข้อมูลล่าสุด ไม่แตะแถวที่ไม่ได้ส่งมา) |
| A และ B แก้แถว X เดียวกัน | last-writer-wins เฉพาะแถว X (พฤติกรรม DB ปกติ) |
| ไม่มีอะไรเปลี่ยน | `computeDelta()` ว่าง → ไม่ยิง server เลย |
| เขียนชนกันเป๊ะ | `LockService` บังคับให้ทำทีละคน (รอสูงสุด 30s) |

### จุดสำคัญในการออกแบบ

- **ไม่ต้องแก้จุดเรียก `saveData()` ~20 จุด** — เพราะ `computeDelta()` หา diff อัตโนมัติจาก baseline
  (ตรวจ "แถวที่เพิ่ม/แก้" จากความต่างของ JSON และ "แถวที่ลบ" จาก id ที่หายไป)
- **`baseline` ถูกเลื่อน** ทุกครั้งที่: โหลด (`loadInitialData`), refresh (`doRefresh`), เซฟสำเร็จ (`saveData`), reset
- **ลำดับการแสดงผล**: แถวใหม่ถูก merge ต่อท้ายใน sheet → ตารางจึง **sort ตามเวลาฝั่ง client**
  (requests=`timestamp`, PO=`date`, support=`time`, historyWD=`actionTime`, historyED=`time`) เพื่อคง "ใหม่สุดอยู่บน"
- **request lifecycle**: เมื่อ approve/reject/tech-confirm จะย้าย object เดียวกัน (มี `_id` เดิม)
  จาก `requests` → `historyWD` → delta จึงเป็น *delete จาก Requests* + *upsert เข้า HistoryWD* (คนละ sheet ไม่ชนกัน)

### ข้อจำกัด / สิ่งที่ยังไม่ครอบคลุม

- ถ้าคนละคนแก้ "แถวเดียวกัน" พร้อมกัน → ยังเป็น last-writer-wins (ยังไม่มี field-level merge / conflict UI)
- delta คำนวณจาก baseline ในหน่วยความจำ ถ้าผู้ใช้แก้ค้างไว้แล้ว auto-refresh เด้ง → ของที่ยังไม่เซฟจะถูกทับ
  (เหมือนพฤติกรรมเดิม แต่ช่วงเสี่ยงสั้นมากเพราะเซฟทันทีหลังทุก action)

---

## Index.html — HTML Structure & Modals

### โครงสร้างหลัก

```text
<body>
  ├── #loading-screen          — Loading overlay
  ├── #login-screen            — หน้า login
  ├── #custom-alert-modal      — Custom alert popup
  ├── #custom-confirm-modal    — Custom confirm popup
  ├── #custom-prompt-modal     — Custom input prompt
  ├── #modal-image-viewer      — ดูรูปขนาดใหญ่ + ปุ่ม Withdraw
  │
  ├── .app-container
  │     ├── <aside>.sidebar    — Navigation sidebar
  │     └── <main>.main-content
  │           ├── #sparepart   (.section.active)  — หน้าหลักตารางอะไหล่
  │           ├── #receive-section (.section)      — เลือกประเภทรับของ
  │           └── #reports-section (.section)      — Reports & Analytics
  │
  └── #app-watermark           — เครดิตผู้พัฒนา (floating, pointer-events:none, มุมขวาล่าง)

  Modals (z-index layering):
  ├── #modal-change-password    (z:100000)
  ├── #modal-report-issue
  ├── #modal-support-tickets
  ├── #modal-receive-existing
  ├── #modal-receive-new
  ├── #modal-part-form          (z:1060)
  ├── #modal-withdraw           (z:1060)
  ├── #modal-part-requests
  ├── #modal-purchase-request   (z:1060)
  ├── #modal-purchase-tracking
  ├── #modal-user
  ├── #modal-user-form          (z:1050)
  ├── #modal-tech-confirm       (z:100000)
  └── #modal-import-csv         (z:1050)
```

### Sidebar Navigation

| Nav Item | CSS Class | เห็นได้โดย |
| --- | --- | --- |
| Spare Part | (ทุกคน) | ทุก role |
| Receive Stock | `.perm-manager` | Manager, Admin |
| Reports & Analytics | `.perm-manager .perm-tech .perm-operator` | Manager, Tech, Operator, Admin |
| User Mgmt | `.perm-admin` | Admin เท่านั้น |
| Support Req. | `.perm-admin` | Admin เท่านั้น |
| Google Sheets DB | `.perm-admin` | Admin เท่านั้น (link ไปเปิด Sheets) |

### Sections

**#sparepart** — หน้าหลัก

- Dashboard cards: Total Items, Low Stock, Out of Stock, Requests (คลิกได้ → filter)
- Toolbar: Category filter (Splicing / Optical Support) + **Export Excel** + Import CSV
- Search input + Group dropdown
- ตาราง: Image, Name, Part No., Category, Group, Qty, Location, Status, Action

**#receive-section** — 3 ตัวเลือก

- รับของที่มีในระบบ (Existing)
- เพิ่มสินค้าใหม่ (New)
- Import CSV (Manager/Admin)

**#reports-section** — Analytics

- KPI: Total Withdrawals, Most Popular Part, Pending Requests
- Google Charts: Column chart (Top 5) + Donut chart (Status)
- ตาราง Withdrawal History + Export CSV
- ตาราง Stock Edit History + Export CSV

### Modal Forms

**Withdraw Form** (`modal-withdraw`) fields:

- Part Name (readonly), Current Qty (readonly)
- Withdraw Qty, Employee ID (EN), Requester Name
- Station No., Machine SN
- Reason (dropdown: Consumed/Cycle/Broken/Lost/New/Other)
- Remark

**Purchase Order Form** (`modal-purchase-request`) fields:

- Part Select, Employee ID, Requester Name
- Order Qty, Urgency (Normal/Urgent/Critical)
- Purchase Reason, Supplier (optional), Remark

**Tech Confirm Form** (`modal-tech-confirm`) fields:

- รหัสพนักงาน (EN), ชื่อผู้รับ
- จำนวนรับจริง, หน่วย (อัน/ชิ้น/กล่อง/ชุด/เส้น/เมตร/ม้วน)

---

## CSS.html — Design System

### CSS Variables (Design Tokens)

```css
--bg-body: #f8fafc       /* พื้นหลัง */
--bg-sidebar: #0f172a    /* sidebar dark */
--bg-card: #ffffff       /* card background */
--primary: #6366f1       /* Indigo */
--primary-light: #818cf8
--primary-dark: #4f46e5
--success: #10b981       /* Green */
--warning: #f59e0b       /* Amber */
--danger: #ef4444        /* Red */
--info: #0ea5e9          /* Sky */
--text-main: #0f172a
--text-muted: #64748b
--border: #e2e8f0
--radius: 1rem
--radius-sm: 0.5rem
--radius-lg: 1.5rem
```

### Components

| Component | Class | คำอธิบาย |
| --- | --- | --- |
| Card | `.card` | White card, shadow-md, rounded-lg, hover elevate |
| Stat Card | `.stat-card.{blue\|yellow\|red\|gray}` | Dashboard metric card, left-border accent |
| Button Primary | `.btn.btn-primary` | Indigo gradient, glow on hover |
| Button Action | `.btn.btn-action` | White border button |
| Button Success | `.btn.btn-success` | Green gradient |
| Button Danger | `.btn.btn-danger` | Red gradient |
| Button SM | `.btn-sm` | Smaller padding/font |
| Badge | `.badge.{bg-green\|bg-yellow\|bg-red\|bg-blue\|bg-purple\|bg-gray\|bg-orange\|bg-blue-subtle}` | Status pill labels |
| Form Control | `.form-control` | Input/select/textarea |
| Form Label | `.form-label` | Input label |
| Grid | `.grid-2` `.grid-3` `.grid-4` | CSS Grid layouts |
| Modal | `.modal-overlay` `.modal-window` `.modal-header` `.modal-body` | Modal system |
| Popup | `.custom-popup-box` `.popup-icon-circle` | Alert/Confirm/Prompt popups |
| Upload Area | `.upload-area` `.upload-preview` | Drag-style file upload |
| Avatar | `.avatar` | Circular initials avatar |
| Nav Item | `.nav-item` `.nav-badge` | Sidebar nav item + badge |
| Part Image | `.part-img-thumb` | 44×44px thumbnail |

### Animations

| Animation | ใช้กับ |
| --- | --- |
| `spin` | Loading spinner, Sync icon |
| `pulseNumber` | (defined, ใช้ใน JS via `pulseElement()`) |
| `fadeIn` | Section switch animation |
| `cubic-bezier(0.34, 1.56, 0.64, 1)` | Modal open spring effect |

### Permission CSS

```css
/* ซ่อนไว้ก่อน — JS เปิดตาม role */
.perm-admin, .perm-manager, .perm-tech, .perm-operator, .manager-only {
    display: none;
}
```

---

## JS.html — Frontend JavaScript

### Global Variables

```js
let isGoogleChartsLoaded = false;  // flag รอ Google Charts โหลด
let targetPartNo = null;           // part ที่กำลัง withdraw
let receiveNewImageBase64 = null;  // รูปสำหรับ receive-new form
let currentImageBase64 = null;     // รูปสำหรับ part-form
let chartTopPartsInstance = null;  // (ประกาศไว้แต่ไม่ assign — charts recreate ทุกครั้ง)
let chartStatusInstance = null;    // (ประกาศไว้แต่ไม่ assign — charts recreate ทุกครั้ง)
let loginAttempts = 0;             // นับครั้งผิด (max 3)
let currentCategoryFilter = '';    // '' = All, หรือ 'Splicing'/'Optical Support'
let autoRefreshInterval = null;    // setInterval handle
let csvParsedRows = [];            // ผลลัพธ์ parse CSV ก่อน import
let lastSynced = {};               // baseline สำหรับ delta sync: { sheetKey: { _id: rowJSON } }

const REFRESH_INTERVAL_MS = 30000; // auto-refresh ทุก 30 วินาที
const SHEET_KEYS = [...];          // 7 sheet keys ที่ sync (users/parts/requests/po/historyWD/historyED/supportTickets)
const DEFAULT_IMG = "data:image/svg+xml;..."; // placeholder SVG
const DEFAULT_USERS = [{ /* admin user */ }];
```

---

### ฟังก์ชันแบ่งตามหมวด

#### Authentication

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `checkAuth()` | ตรวจ `authToken` ใน `sessionStorage` → `validateSession()` → ถ้า valid เรียก `loadInitialData()` ไม่งั้นโชว์ login |
| `loadInitialData(loadScreen)` | 🔒 `getInitialData(authToken)` → เซ็ต state → `captureBaseline()` → `initSystem()` |
| `showLoginScreen(loadScreen)` | ซ่อน loading, แสดงหน้า login |
| `performLogin()` | เรียก `login(u,p)` ฝั่ง server → เก็บ `authToken` → `loadInitialData()`; จัดการ `invalid`/`locked` |
| `logout()` | เรียก `logout(token)` ฝั่ง server → ล้าง token/session, หยุด auto-refresh, reset UI |
| `handleAuthExpired()` | session หมด/ไม่มีสิทธิ์ → alert + บังคับ login ใหม่ |
| `requestPasswordReset()` | เรียก `submitPasswordResetRequest(u)` (ไม่ใช้ token) → server สร้าง ticket + ส่ง email |
| `submitChangePassword()` | เรียก `changeOwnPassword(token, ...)` ยืนยัน EN+Name+Email แล้ว server hash รหัสใหม่ |
| `resetUserData()` | `saveDataToServer(token, ...)` Reset ข้อมูลทั้งหมดกลับ default (Admin only) |

**Login lock:**

- **ฝั่ง client (UX):** ผิด 3 ครั้ง → แสดง lock msg + ปุ่ม "ขอเปลี่ยนรหัสผ่าน" และโชว์จำนวนครั้งที่เหลือ
- **ฝั่ง server (บังคับจริง):** ผิด 5 ครั้ง/15 นาที → ล็อก username 15 นาที (`login()` คืน `status:'locked'`) — ดู Changelog "Login Rate-limiting"

#### Sync & Auto-Refresh

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `saveData()` | localStorage cache + คำนวณ delta + `google.script.run.applyDelta` (ดูหัวข้อ Delta Sync) |
| `doRefresh(isManual)` | ดึงข้อมูลใหม่, อัปเดต state, `captureBaseline()`, re-render UI |
| `manualRefresh()` | `doRefresh(true)` + แสดง toast ผล |
| `startAutoRefresh()` | ตั้ง setInterval 30s |
| `setSyncState(state)` | update sync indicator dot + label: `syncing`/`synced`/`error`/`idle` |
| `showToast(msg, type)` | toast notification ที่มุมขวาล่าง (success/error/info/warning) |
| `pulseElement(id)` | flash สี primary บน element 500ms |

#### Delta Sync Helpers

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `genId()` | สร้าง id ไม่ซ้ำฝั่ง client (`id_<base36 time>_<random>`) สำหรับแถวใหม่ |
| `ensureRowIds(arr)` | เติม `_id` ให้แถวใน array ที่ยังไม่มี |
| `ensureAllIds()` | เรียก `ensureRowIds` กับทุก sheet ใน `SHEET_KEYS` |
| `captureBaseline()` | snapshot state ปัจจุบันเป็น `{ sheetKey: { _id: rowJSON } }` ไว้เทียบ delta |
| `computeDelta()` | เทียบ state vs baseline → คืน `{ sheetKey: { upserts, deletes } }` เฉพาะที่เปลี่ยน |

**ค่าคงที่:** `SHEET_KEYS` = `['users','parts','requests','po','historyWD','historyED','supportTickets']`,
`lastSynced` = baseline object

#### Role-Based Permissions

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `updatePermissions()` | show/hide elements ตาม role + ตั้ง category filter |
| `updateProfileUI()` | แสดงชื่อ, position, role, avatar initial ใน sidebar |

**Role Hierarchy:**

```text
Admin      → .perm-admin + .perm-manager + .perm-tech + .perm-operator + .manager-only
Manager    → .perm-manager + .perm-tech + .perm-operator + .manager-only
Technician → .perm-tech
Operator   → .perm-operator (read-only Reports)
```

**Category Access:**

- `All` → เห็น category filter, เห็นข้อมูลทุก category
- `Splicing` / `Optical Support` → ซ่อน filter, กรองข้อมูลเฉพาะ category นั้น

#### Spare Part Table

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `renderSparePartTable(searchVal)` | Render ตารางหลัก + อัปเดต dashboard metrics |
| `smartUpdateSparePartTable()` | อัปเดต metrics quietly, re-render ถ้า user ไม่ได้กำลัง type |
| `filterParts(filterVal)` | `show_all_items` / `low_stock_filter` / `out_of_stock_filter` หรือ search |
| `setCategoryFilter(cat)` | เปลี่ยน category filter + re-render |
| `updateCategoryFilterUI()` | อัปเดต active state บนปุ่ม category |
| `populateGroupFilter()` | build group dropdown จาก parts ที่มีอยู่ |
| `viewImage(partNo)` | เปิด image viewer modal พร้อมข้อมูล part + stock status |

**Stock Status:**

```text
qty === 0             → Out of Stock (bg-red)
qty > 0 && qty ≤ min  → Low Stock   (bg-yellow)
qty > min             → In Stock    (bg-green)
```

#### Part CRUD

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `openPartForm(mode, id)` | เปิด modal: `'create'` / `'edit'` |
| `savePartForm()` | validate → create หรือ update part → log historyED |
| `deletePart(partNo)` | confirm → ลบ part → log historyED |

#### Receive (รับอะไหล่)

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `populateReceiveSearch()` | build datalist สำหรับ autocomplete |
| `onSelectReceivePart(val)` | แสดงข้อมูล part ที่เลือกใน card |
| `confirmReceiveExisting()` | เพิ่ม qty ให้ part เดิม + log historyED |
| `confirmReceiveNew()` | เพิ่ม part ใหม่เข้า state + log historyED |

#### Withdraw (เบิกอะไหล่)

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `openWithdrawModal(partNo)` | เปิด modal พร้อม pre-fill ข้อมูล |
| `saveWithdraw()` | สร้าง Request, **ตัด qty ทันที**, log historyED + **ส่ง email** (NEW_REQUEST / LOW_STOCK / OUT_OF_STOCK) |

**สำคัญ:** qty ถูกตัดตอนสร้าง Request ไม่ใช่ตอน Approve — ถ้า Reject จะคืน qty กลับ

#### Request Approval

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `renderRequests()` | แสดง Pending requests (**sort `timestamp` ใหม่→เก่า**) |
| `smartUpdateRequestsTable()` | อัปเดต count + re-render |
| `approveReq(id)` | Approve → historyWD + **ส่ง email REQUEST_APPROVED** |
| `rejectReq(id)` | Reject + prompt เหตุผล → **คืน qty** → historyWD + **ส่ง email REQUEST_REJECTED** |
| `techApproveReq(id)` | เปิด Tech Confirm modal |
| `submitTechConfirm()` | Self-confirm พร้อมระบุ qty/unit จริง → historyWD + **ส่ง email TECH_CONFIRMED** |
| `filterRequests(val)` | filter rows ในตาราง |

**Approve Flow:**

```text
saveWithdraw() → Request(Pending) + qty ลด + email(NEW_REQUEST)
                      ↓
    ┌─────────────────┼─────────────────┐
    ↓                 ↓                 ↓
approveReq()    rejectReq()     techApproveReq()
→ historyWD     → คืน qty      → historyWD
→ email         → historyWD    → email(TECH_CONFIRMED)
  (APPROVED)    → email
                  (REJECTED)
```

#### Purchase Orders

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `populatePartSelect()` | build dropdown ใน PO form |
| `savePurchaseOrder()` | สร้าง PO ใหม่ (บันทึก `en` ด้วย) |
| `renderPurchaseTable()` | แสดงตาราง PO (**sort `date` ใหม่→เก่า**), Manager/Admin เห็น status dropdown |
| `updatePOStatus(id, newStatus)` | เปลี่ยน status (ไม่อัปเดต stock ถ้าตั้งเป็น Received ผ่าน dropdown) |
| `receivePO(id)` | prompt qty → ยืนยัน → **เพิ่ม stock** → อัปเดต PO status |

**PO Status Flow:** `Pending Approval` → `Ordered` → `In Transit` → `Received (x/y)` → `Received`

#### Reports & Analytics

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `renderReportsDashboard()` | reset search, คำนวณ KPI, render charts + tables |
| `renderCharts(partCounts, wdData, reqData)` | วาด Google Charts (retry ถ้า charts ยังโหลดไม่เสร็จ) |
| `renderRequestHistoryTable()` | ตาราง historyWD (null-safe, **sort `actionTime` ใหม่→เก่า**) |
| `renderEditHistoryTable()` | ตาราง historyED พร้อม type badge (null-safe, XSS-safe, **sort `time` ใหม่→เก่า**) |
| `renderReports()` | เรียก 2 ฟังก์ชันข้างบน |
| `exportToCSV(tableId, filename)` | export ตารางเป็น CSV (UTF-8 BOM) |
| `exportSparePartsXLSX()` | export อะไหล่เป็น `.xlsx` 2 sheets: Spare Parts + Summary |
| `isQtyIncrease(changeStr)` | ตรวจสอบ `Qty: X -> Y` ว่าเพิ่มหรือลด |
| `formatChanges(str)` | แปลง change string เป็น HTML สวยงาม |
| `filterHistoryTable(tbodyId, val)` | filter rows ใน history table |

**Edit History Type Detection:**

```text
'created'/'new item'    → New Item  (bg-blue)
'received' + qty up     → Stock In  (bg-green)
'withdrawal' + qty down → Stock Out (bg-red)
'image'                 → Image     (bg-purple)
else                    → Edit Info (bg-orange)
```

**Export Excel (exportSparePartsXLSX):**

- Sheet 1 **Spare Parts**: Part No., Name, Category, Group, Qty, Min Level, Status, Location, Supplier (column width auto-set, freeze header)
- Sheet 2 **Summary**: Generated time, Category filter, Total parts, Total qty, In/Low/Out of Stock count + %
- ชื่อไฟล์: `SpareParts_<category>_<YYYY-MM-DD>.xlsx`

#### User Management

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `renderUserTable()` | แสดงตาราง users พร้อม category badge (null-safe avatar) |
| `openUserForm(mode, en)` | เปิด modal: `'create'` / `'edit'` |
| `saveUserForm()` | บันทึก user + อัปเดต session ถ้าแก้ตัวเอง |
| `delUser(en)` | ลบ user (ป้องกัน en=001 หรือลบตัวเอง) |
| `togglePasswordVisibility(inputId, iconEl)` | toggle password show/hide |

#### Support Tickets

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `submitSupportTicket()` | สร้าง ticket + **ส่ง email SUPPORT_TICKET** |
| `renderSupportTickets()` | แสดงตาราง tickets (**sort `time` ใหม่→เก่า**) |
| `resolveTicket(id)` | Mark → Resolved |
| `updateSupportBadge()` | อัปเดต badge count (Pending tickets) |

#### CSV Import

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `downloadPartTemplate()` | สร้างและดาวน์โหลด template CSV |
| `handlePartCSVUpload(input)` | รับไฟล์, ตรวจ .csv, เรียก parse |
| `parseCSV(text)` | Parse CSV: auto-detect delimiter (`,` `;` `\t`), handle quoted fields |
| `validateAndPreviewCSV(rows)` | Validate ทุกแถว, แสดง preview, นับ valid/error |
| `importPartCSVConfirmed()` | Import เฉพาะ valid rows → สร้าง parts + historyED |

**Required CSV columns:** `part_no`, `name`, `category`, `qty`, `min`

**Optional columns:** `group`, `location`, `supplier`

**Valid categories:** `Splicing`, `Optical Support`

#### Image Management

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `processImageUpload(file, ...)` | read → resize max 300×300 → compress JPEG 50% → base64 |
| `handleImageUpload(input)` | สำหรับ part form |
| `handleReceiveNewImage(input)` | สำหรับ receive-new form |
| `removeImage(type)` | ล้างรูปออกจาก form (`'part'` หรือ `'receive'`) |

**Image limit:** 10MB ก่อน compress, ผลลัพธ์เป็น base64 JPEG quality 0.5 เก็บใน `part.image`

#### Email Notification (JS.html)

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `sendNotification(type, payload)` | fire-and-forget wrapper สำหรับ `google.script.run.sendEmailNotification` — ไม่บล็อก UI, log error ใน console เท่านั้น |

**ทุก Event ที่ trigger notification:**

| ฟังก์ชัน | Event ที่ส่ง |
| --- | --- |
| `saveWithdraw()` | `NEW_REQUEST` + `OUT_OF_STOCK` หรือ `LOW_STOCK` (ถ้าถึง threshold) |
| `approveReq()` | `REQUEST_APPROVED` |
| `rejectReq()` | `REQUEST_REJECTED` |
| `submitTechConfirm()` | `TECH_CONFIRMED` |
| `submitSupportTicket()` | `SUPPORT_TICKET` |
| `requestPasswordReset()` | `PASSWORD_RESET` |

#### UI Helpers

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `showAlert(title, msg, type)` | custom alert: `success`/`error`/`info` |
| `closeAlert()` | ปิด alert modal |
| `showConfirm(title, msg, callback)` | custom confirm, เรียก callback ถ้า OK |
| `closeConfirm(result)` | ปิด confirm |
| `showPrompt(title, msg, default, cb)` | custom input prompt |
| `closePrompt(result)` | ปิด prompt พร้อมค่า |
| `openModal(id)` | เปิด modal overlay (trigger render ของ modal นั้นด้วย) |
| `closeModal(id)` | ปิด modal + cleanup state บางอย่าง |
| `switchTab(id, el)` | สลับ section + active state บน nav |
| `handleRefresh()` | `checkAuth()` + showAlert |
| `escapeHtml(unsafe)` | Sanitize HTML entities ป้องกัน XSS |

#### Access Control Helpers

| ฟังก์ชัน | คำอธิบาย |
| --- | --- |
| `getCategoryAccessFilter()` | คืน `{ category, allowedNos }` ตาม currentUser |
| `filterByAccessCategory(arr, field)` | กรอง array ตาม accessCategory |

---

## Known Issues / Notes

1. **qty ถูกตัดทันทีตอน `saveWithdraw()`** — ไม่ใช่ตอน approve การ reject จะต้อง `part.qty += req.qty` คืนกลับ ถ้าระบบล่มระหว่าง pending อาจทำให้ qty ต่ำกว่าจริง

2. **`uploadImageToDrive()` ใน Code.gs** — implement ไว้แล้วแต่ยังไม่ได้ถูกเรียกจาก JS frontend รูปยังถูกเก็บเป็น base64 ใน Google Sheets ตรงๆ

3. **`po-urgency`, `po-supplier`, `po-remark`** — field เหล่านี้มีใน modal-purchase-request form แต่ `savePurchaseOrder()` ยังไม่ได้อ่านค่าเหล่านั้นไปเก็บใน PO object (เก็บเฉพาะ `reason`)

4. **Image viewer Withdraw button** — ปิด modal แล้วเปิด `openWithdrawModal()` โดยอ่าน `#viewer-part-no-hidden` hidden element

5. **`chartTopPartsInstance` / `chartStatusInstance`** — ประกาศไว้แต่ไม่ได้ assign จริง (charts ถูก recreate ทุกครั้งที่ render)

6. **Email ต้อง authorize ก่อนใช้งานครั้งแรก** — run `forceAuthorize()` ใน Apps Script Editor เพื่อ grant `MailApp` scope

7. **`_id` เป็น primary key ที่ระบบใช้ภายใน** — ห้ามลบ/แก้คอลัมน์ `_id` ใน Google Sheets ด้วยมือ มิฉะนั้น delta merge อาจสร้างแถวซ้ำ

8. **Conflict แถวเดียวกัน** — ยังเป็น last-writer-wins (ยังไม่มี field-level merge) ดูหัวข้อ Delta Sync → ข้อจำกัด

### ✅ Resolved (2026-06-15)

- ~~การเซฟทับทั้งตารางทำให้ข้อมูลหายตอนใช้งานหลายคน~~ → แก้ด้วย **Delta Sync + LockService** (ดู Changelog)
- ~~ไม่มี lock ตอนเขียน Sheet~~ → เพิ่ม `LockService` แล้วทั้ง `applyDelta` และ `saveDataToServer`

### ✅ Resolved (2026-06-15 security)

- ~~รหัสผ่าน plaintext + ตรวจ login ฝั่ง client~~ → hash (SHA-256+salt) + `login()` ฝั่ง server + ไม่ส่ง password ให้ client
- ~~ไม่มี authorization ฝั่ง server~~ → ทุก write/read endpoint ต้องมี token; user management ต้องเป็น Admin
- ~~Brute-force กันแค่ฝั่ง client~~ → server throttle/lockout per-username (5 ครั้ง/15 นาที → ล็อก 15 นาที)

### ยังคงเป็นข้อควรปรับ

- **`writeSheetData` prefix `'` หน้าตัวเลข/วันที่** ทำให้ค่าใน Sheet เป็น text — ยังไม่แก้
- **Token เก็บใน `CacheService`** (อาจถูก evict ก่อนหมดอายุ) → ถ้าหลุดจะถูกบังคับ login ใหม่ (UX acceptable)
- **Conflict แถวเดียวกันพร้อมกัน** ยังเป็น last-writer-wins (ดู Delta Sync)
- **Account lockout = DoS เล็กน้อย**: ผู้ไม่หวังดีจงใจ login ผิดเพื่อล็อกบัญชีคนอื่นได้ (ล็อกชั่วคราว 15 นาที) — เป็น trade-off มาตรฐานของ per-username lockout

---

## Bug Fixes Log

| # | ฟังก์ชัน | Bug | Fix |
| --- | --- | --- | --- |
| 1 | `renderRequestHistoryTable` | Declared 2 ครั้ง — 2nd (active) ขาด null check → `Invalid Date` + `TypeError` ถ้า `status` เป็น null | ลบ 2nd definition ออก |
| 2 | `renderEditHistoryTable` | Declared 2 ครั้ง — 2nd (active) ขาด null check, ไม่ escape `log.part_no`/`log.part_name` (XSS), ใช้ `innerHTML +=` ใน loop | ลบ 2nd definition ออก |
| 3 | `escapeHtml` | Declared 2 ครั้ง (identical) | ลบ 2nd definition ออก |
| 4 | `savePurchaseOrder` | `en` field ถูก validate แต่ไม่ save ลง PO object | เพิ่ม `en: en` ใน object |
| 5 | `renderSparePartTable` | `part.name.toLowerCase()` crash ถ้า name เป็น null | เปลี่ยนเป็น `(part.name \|\| '').toLowerCase()` |
| 6 | `onSelectReceivePart` | `p.name.toLowerCase()` ใน `.find()` callback crash ถ้ามี part ใดที่ name เป็น null | เปลี่ยนเป็น `(p.name \|\| '').toLowerCase()` |
| 7 | `renderUserTable` | `u.name[0]` แสดง `undefined` หรือตัวพิมพ์เล็กถ้า name ว่าง | เปลี่ยนเป็น `(u.name \|\| '?').charAt(0).toUpperCase()` |
| 8 | `getSheetData` (Code.gs) | field ที่เป็น object (เช่น `details`) ถูก `JSON.stringify` ตอนเขียน แต่ไม่ parse กลับตอนอ่าน → หลัง refresh `r.details.reason`/`machine_sn` หาย | parse string ที่ขึ้นต้นด้วย `{`/`[` กลับเป็น object (try/catch) |
| 9 | `delUser` | เช็ค `en === '001'` ซึ่งไม่ตรงกับ Admin จริง (en=67007842) → กัน System Admin ไม่ได้ | เปลี่ยนเป็นกัน "ลบตัวเอง" + กัน "ลบ Admin คนสุดท้าย" |
| 10 | `saveUserForm` | โหมด edit ไม่เช็ค username ซ้ำ → ตั้ง username ชนคนอื่นได้ → login ผิดคน | เพิ่มเช็ค username ซ้ำ (ยกเว้นตัวเอง) ในโหมด edit |
| 11 | `confirmReceiveExisting` | `p.name.toLowerCase()` ตกหล่นจาก null-guard fix → crash ถ้ามี part ที่ name ว่าง | เปลี่ยนเป็น `(p.name \|\| '')` |
| 12 | `renderSparePartTable` / `renderRequests` / `renderPurchaseTable` | ใส่ค่าจากผู้ใช้ (name, reason ฯลฯ) ลง `innerHTML` ดิบ → ช่อง XSS | ครอบด้วย `escapeHtml()` ทุก field ที่แสดงผล |

> **#8–#12 แก้เมื่อ 2026-06-15** (รอบเดียวกับ Delta Sync) — #8 ทำให้ subtext "เหตุผล / SN" ในตารางคำขอกลับมาแสดงหลัง refresh

---

## Initialization Flow

```text
DOMContentLoaded
  └─ checkAuth()
  └─ startAutoRefresh()          ← [30s] doRefresh() (no-op จนกว่าจะ login)

checkAuth()                       ← 🔒 token-based
  └─ show loading-screen
  └─ authToken ใน sessionStorage?
        ├─ NO  → showLoginScreen()
        └─ YES → validateSession(token)
                    ├─ valid   → set authToken + currentUser → loadInitialData()
                    └─ invalid → ล้าง token → showLoginScreen()

performLogin()                    ← ผู้ใช้กด Login
  └─ login(username, password)    ← ตรวจ hash + rate-limit ฝั่ง server
        ├─ success → เก็บ authToken/currentUser → loadInitialData()
        ├─ invalid → แสดง error (+ ครั้งที่เหลือ)
        └─ locked  → แสดงข้อความล็อก + retryAfter

loadInitialData(loadScreen)       ← 🔒 ต้องมี authToken แล้ว
  └─ getInitialData(authToken)
        ↓ success
        └─ state ← dbData (sanitized users + migrations + _id backfill)
        └─ captureBaseline()      ← ตั้ง baseline ก่อนเริ่มแก้ไข
        └─ hide login-screen → initSystem()

initSystem()
  └─ updateProfileUI()
  └─ updatePermissions()
  └─ populateGroupFilter()
  └─ renderSparePartTable()
  └─ populateReceiveSearch()
  └─ updateSupportBadge()
  └─ setSyncState('idle')
  └─ bind modal-overlay click-outside handlers
  └─ startAutoRefresh()
  └─ setTimeout(doRefresh, 1500)   ← immediate first sync
```
