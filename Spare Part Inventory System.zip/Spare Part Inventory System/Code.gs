// ==========================================
// 1. ฟังก์ชันเรียกหน้าเว็บและดึงไฟล์ย่อยมาประกอบกัน
// ==========================================
function doGet(e) {
  return HtmlService.createTemplateFromFile('index')
      .evaluate()
      .setTitle('Spare Part Inventory System')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL) 
      .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// ==========================================
// 2. ฟังก์ชันสำหรับดึงไฟล์ css และ js เข้ามาในหน้า index
// ==========================================
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// ==========================================
// 2.1 ค่าคงที่ฐานข้อมูล + ตัวช่วยกลาง
// ==========================================
var DB_SPREADSHEET_ID = '1TrtU1iQgSeQckKWfhX137IMZLE2C95N12WgcBVtxZT8';

// map ชื่อ key ฝั่ง client -> ชื่อ Sheet จริง
var SHEET_MAP = {
  users: 'Users',
  parts: 'Parts',
  requests: 'Requests',
  po: 'PO',
  historyWD: 'HistoryWD',
  historyED: 'HistoryED',
  supportTickets: 'SupportTickets'
};

function getDb_() {
  return SpreadsheetApp.openById(DB_SPREADSHEET_ID);
}

// ใส่ _id ให้ทุกแถวที่ยังไม่มี (ใช้เป็น primary key ตอน merge) — คืน true ถ้ามีการเปลี่ยนแปลง
function ensureIds_(rows) {
  var changed = false;
  for (var i = 0; i < rows.length; i++) {
    if (rows[i]._id === undefined || rows[i]._id === null || rows[i]._id === '') {
      rows[i]._id = Utilities.getUuid();
      changed = true;
    }
  }
  return changed;
}

// ==========================================
// 2.2 ระบบ Authentication & Authorization (Security)
// ==========================================
var SESSION_TTL_SECONDS = 21600; // 6 ชั่วโมง (เพดานของ CacheService)

// ---- Password hashing (SHA-256 + per-user salt) ----
function bytesToHex_(bytes) {
  var hex = '';
  for (var i = 0; i < bytes.length; i++) {
    var v = (bytes[i] & 0xFF).toString(16);
    if (v.length === 1) v = '0' + v;
    hex += v;
  }
  return hex;
}
function newSalt_() {
  return Utilities.getUuid().replace(/-/g, '');
}
function hashPassword_(password, salt) {
  var raw = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    String(salt) + '::' + String(password),
    Utilities.Charset.UTF_8
  );
  return bytesToHex_(raw);
}
// แปลง user เก่าที่เก็บรหัสผ่าน plaintext -> hash (เรียกครั้งเดียวต่อ user) คืน true ถ้าเปลี่ยน
function upgradeUserSecret_(user) {
  if ((user.passwordHash === undefined || user.passwordHash === '') &&
      user.password !== undefined && user.password !== '') {
    user.salt = newSalt_();
    user.passwordHash = hashPassword_(user.password, user.salt);
    user.password = ''; // ลบ plaintext ออกจากฐานข้อมูล
    return true;
  }
  return false;
}
function verifyUserPassword_(user, password) {
  if (user.passwordHash) {
    return hashPassword_(password, user.salt) === user.passwordHash;
  }
  // legacy plaintext (กรณียังไม่ได้ migrate)
  if (user.password !== undefined && user.password !== '') {
    return String(user.password) === String(password);
  }
  return false;
}

// ---- ลบ field ลับก่อนส่งให้ client (ห้ามส่ง password/hash/salt ออกไปเด็ดขาด) ----
function sanitizeUser_(u) {
  var c = {};
  for (var k in u) {
    if (k === 'password' || k === 'passwordHash' || k === 'salt') continue;
    c[k] = u[k];
  }
  return c;
}
function sanitizeUsers_(users) {
  return users.map(sanitizeUser_);
}
// hash รหัสผ่าน plaintext ที่หลุดมากับ array users ก่อนเขียนลง sheet (ใช้ตอน reset)
function hashUsersInPlace_(users) {
  for (var i = 0; i < users.length; i++) {
    upgradeUserSecret_(users[i]);
  }
}

// ---- เพิ่ม admin เริ่มต้นถ้า sheet ว่าง ----
function ensureDefaultAdmin_(users) {
  if (users.length > 0) return false;
  var salt = newSalt_();
  users.push({
    _id: Utilities.getUuid(),
    en: '67007842', name: 'Panthawat', email: 'pantawatt@celestica.com',
    position: '', role: 'Admin', username: 'admin',
    password: '', salt: salt, passwordHash: hashPassword_('admin01', salt),
    status: 'Active', accessCategory: 'All'
  });
  return true;
}

// ---- Session token store (CacheService) ----
function createSession_(user) {
  var token = Utilities.getUuid();
  var payload = JSON.stringify({
    en: user.en, username: user.username, name: user.name,
    role: user.role, accessCategory: user.accessCategory || 'All', ts: Date.now()
  });
  CacheService.getScriptCache().put('sess_' + token, payload, SESSION_TTL_SECONDS);
  return token;
}
function getSession_(token) {
  if (!token) return null;
  var raw = CacheService.getScriptCache().get('sess_' + token);
  if (!raw) return null;
  try {
    var s = JSON.parse(raw);
    CacheService.getScriptCache().put('sess_' + token, raw, SESSION_TTL_SECONDS); // sliding TTL
    return s;
  } catch (e) { return null; }
}
function destroySession_(token) {
  if (token) CacheService.getScriptCache().remove('sess_' + token);
}
function requireAuth_(token) {
  var s = getSession_(token);
  if (!s) throw new Error('AUTH_REQUIRED');
  return s;
}
function requireAdmin_(token) {
  var s = requireAuth_(token);
  if ((s.role || '') !== 'Admin') throw new Error('FORBIDDEN');
  return s;
}

// ---- Brute-force / rate-limit สำหรับ login (per-username ผ่าน CacheService) ----
var LOGIN_MAX_ATTEMPTS = 5;       // ผิดได้กี่ครั้งก่อนโดนล็อก
var LOGIN_WINDOW_SECONDS = 900;   // หน้าต่างนับครั้งผิด (15 นาที)
var LOGIN_LOCKOUT_SECONDS = 900;  // ระยะเวลาที่ถูกล็อก (15 นาที)

function loginFailKey_(username) { return 'lf_' + String(username).toLowerCase(); }
function loginLockKey_(username) { return 'll_' + String(username).toLowerCase(); }

// คืนจำนวนวินาทีที่ยังถูกล็อกอยู่ (0 = ไม่ถูกล็อก)
function loginLockRemaining_(username) {
  var cache = CacheService.getScriptCache();
  var until = cache.get(loginLockKey_(username));
  if (!until) return 0;
  var ms = parseInt(until, 10) - Date.now();
  if (ms <= 0) { cache.remove(loginLockKey_(username)); return 0; }
  return Math.ceil(ms / 1000);
}

// บันทึกครั้งที่ login ผิด -> ถ้าถึงเพดานจะตั้ง lock
function registerLoginFailure_(username) {
  var cache = CacheService.getScriptCache();
  var key = loginFailKey_(username);
  var n = parseInt(cache.get(key) || '0', 10) + 1;
  if (n >= LOGIN_MAX_ATTEMPTS) {
    var until = Date.now() + LOGIN_LOCKOUT_SECONDS * 1000;
    cache.put(loginLockKey_(username), String(until), LOGIN_LOCKOUT_SECONDS);
    cache.remove(key); // รีเซ็ตตัวนับหลังล็อก
    return { locked: true, retryAfter: LOGIN_LOCKOUT_SECONDS };
  }
  cache.put(key, String(n), LOGIN_WINDOW_SECONDS);
  return { locked: false, remaining: LOGIN_MAX_ATTEMPTS - n };
}

function clearLoginFailures_(username) {
  var cache = CacheService.getScriptCache();
  cache.remove(loginFailKey_(username));
  cache.remove(loginLockKey_(username));
}

// ==========================================
// 2.3 Public Auth Endpoints (เรียกจาก client ได้)
// ==========================================
function login(username, password) {
  var lock = LockService.getScriptLock();
  try { lock.waitLock(20000); } catch (e) { return { status: 'error', message: 'Server busy, please retry' }; }
  try {
    if (!username) return { status: 'invalid' };

    // 🔒 ถูกล็อกจากการพยายามผิดบ่อยเกินไปหรือยัง
    var locked = loginLockRemaining_(username);
    if (locked > 0) return { status: 'locked', retryAfter: locked };

    var ss = getDb_();
    var users = getSheetData(ss, 'Users');
    var changed = false;
    if (ensureIds_(users)) changed = true;
    if (ensureDefaultAdmin_(users)) changed = true;

    var u = null;
    for (var i = 0; i < users.length; i++) {
      if (String(users[i].username) === String(username) && users[i].status === 'Active') { u = users[i]; break; }
    }

    var ok = !!u && verifyUserPassword_(u, password);
    if (ok && !u.passwordHash) { upgradeUserSecret_(u); changed = true; } // upgrade legacy on success
    if (changed) writeSheetData(ss, 'Users', users);

    if (!ok) {
      // นับครั้งผิด (รวมกรณี username ไม่มีจริง เพื่อกัน enumeration/spray)
      var fail = registerLoginFailure_(username);
      if (fail.locked) return { status: 'locked', retryAfter: fail.retryAfter };
      return { status: 'invalid', remaining: fail.remaining };
    }

    clearLoginFailures_(username); // login สำเร็จ -> ล้างตัวนับ
    return { status: 'success', token: createSession_(u), user: sanitizeUser_(u) };
  } catch (err) {
    Logger.log('login error: ' + err.message);
    return { status: 'error', message: err.message };
  } finally {
    lock.releaseLock();
  }
}

// ตรวจ session ตอนรีโหลดหน้า -> คืน user ล่าสุด (sanitized)
function validateSession(token) {
  var s = getSession_(token);
  if (!s) return { status: 'invalid' };
  try {
    var users = getSheetData(getDb_(), 'Users');
    for (var i = 0; i < users.length; i++) {
      if (String(users[i].en) === String(s.en) && users[i].status === 'Active') {
        return { status: 'success', user: sanitizeUser_(users[i]) };
      }
    }
  } catch (e) {}
  destroySession_(token);
  return { status: 'invalid' };
}

function logout(token) {
  destroySession_(token);
  return { status: 'success' };
}

// คำขอรีเซ็ตรหัสผ่าน (เรียกก่อน login ได้ ไม่ต้องใช้ token)
function submitPasswordResetRequest(username) {
  var lock = LockService.getScriptLock();
  try { lock.waitLock(20000); } catch (e) { return { status: 'error', message: 'Server busy' }; }
  try {
    if (!username) return { status: 'error', message: 'Username required' };
    var ss = getDb_();
    var tickets = getSheetData(ss, 'SupportTickets');
    tickets.unshift({
      _id: Utilities.getUuid(),
      id: Date.now(),
      user: username,
      topic: 'Password Reset Request',
      desc: 'User requested password reset due to locked account (too many failed attempts).',
      status: 'Pending',
      time: new Date().toISOString()
    });
    writeSheetData(ss, 'SupportTickets', tickets);
    try { sendEmailNotificationInternal_('PASSWORD_RESET', { username: username }); } catch (e2) {}
    return { status: 'success' };
  } catch (err) {
    return { status: 'error', message: err.message };
  } finally {
    lock.releaseLock();
  }
}

// เปลี่ยนรหัสผ่านตัวเอง (ยืนยันตัวตนด้วย username/en/name/email ที่ตรงกับบัญชีของ token)
function changeOwnPassword(token, payloadJson) {
  var auth;
  try { auth = requireAuth_(token); } catch (e) { return { status: 'error', message: e.message }; }
  var lock = LockService.getScriptLock();
  try { lock.waitLock(20000); } catch (e) { return { status: 'error', message: 'Server busy' }; }
  try {
    var p = JSON.parse(payloadJson);
    var ss = getDb_();
    var users = getSheetData(ss, 'Users');
    var u = null;
    for (var i = 0; i < users.length; i++) {
      if (String(users[i].en) === String(auth.en)) { u = users[i]; break; }
    }
    if (!u) return { status: 'error', message: 'User not found' };
    if (String(u.username) !== String(p.username) || String(u.en) !== String(p.en) ||
        String(u.name) !== String(p.name) || String(u.email || '') !== String(p.email || '')) {
      return { status: 'invalid' };
    }
    if (!p.newPassword) return { status: 'error', message: 'Password required' };
    u.salt = newSalt_();
    u.passwordHash = hashPassword_(p.newPassword, u.salt);
    u.password = '';
    writeSheetData(ss, 'Users', users);
    return { status: 'success' };
  } catch (err) {
    return { status: 'error', message: err.message };
  } finally {
    lock.releaseLock();
  }
}

// ==========================================
// 2.4 Admin-only User Management Endpoints
// ==========================================
function adminSaveUser(token, userJson) {
  try { requireAdmin_(token); } catch (e) { return { status: 'error', message: e.message }; }
  var lock = LockService.getScriptLock();
  try { lock.waitLock(20000); } catch (e) { return { status: 'error', message: 'Server busy' }; }
  try {
    var input = JSON.parse(userJson);
    if (!input.en || !input.name || !input.username) return { status: 'error', message: 'Missing required fields' };
    var ss = getDb_();
    var users = getSheetData(ss, 'Users');
    ensureIds_(users);

    var idx = -1;
    for (var i = 0; i < users.length; i++) {
      if (String(users[i].en) === String(input.en)) { idx = i; break; }
    }
    for (var j = 0; j < users.length; j++) {
      if (String(users[j].username) === String(input.username) && String(users[j].en) !== String(input.en)) {
        return { status: 'error', message: 'Username already exists' };
      }
    }

    if (idx === -1) {
      if (!input.password) return { status: 'error', message: 'Password required for new user' };
      var salt = newSalt_();
      users.push({
        _id: Utilities.getUuid(),
        en: input.en, name: input.name, position: input.position || '',
        role: input.role, status: input.status, username: input.username,
        email: input.email || '', accessCategory: input.accessCategory || 'All',
        password: '', salt: salt, passwordHash: hashPassword_(input.password, salt)
      });
    } else {
      var ex = users[idx];
      ex.name = input.name; ex.position = input.position || ''; ex.role = input.role;
      ex.status = input.status; ex.username = input.username; ex.email = input.email || '';
      ex.accessCategory = input.accessCategory || 'All';
      if (input.password) { // เปลี่ยนรหัสเฉพาะเมื่อกรอกค่าใหม่
        ex.salt = newSalt_();
        ex.passwordHash = hashPassword_(input.password, ex.salt);
        ex.password = '';
      }
    }
    writeSheetData(ss, 'Users', users);
    return { status: 'success', users: sanitizeUsers_(users) };
  } catch (err) {
    return { status: 'error', message: err.message };
  } finally {
    lock.releaseLock();
  }
}

function adminDeleteUser(token, en) {
  var auth;
  try { auth = requireAdmin_(token); } catch (e) { return { status: 'error', message: e.message }; }
  if (String(auth.en) === String(en)) return { status: 'error', message: 'Cannot delete yourself' };
  var lock = LockService.getScriptLock();
  try { lock.waitLock(20000); } catch (e) { return { status: 'error', message: 'Server busy' }; }
  try {
    var ss = getDb_();
    var users = getSheetData(ss, 'Users');
    var target = null;
    for (var i = 0; i < users.length; i++) {
      if (String(users[i].en) === String(en)) { target = users[i]; break; }
    }
    if (!target) return { status: 'error', message: 'User not found' };
    if ((target.role || '') === 'Admin') {
      var admins = users.filter(function (x) { return (x.role || '') === 'Admin'; }).length;
      if (admins <= 1) return { status: 'error', message: 'Cannot delete the last Admin' };
    }
    users = users.filter(function (x) { return String(x.en) !== String(en); });
    writeSheetData(ss, 'Users', users);
    return { status: 'success', users: sanitizeUsers_(users) };
  } catch (err) {
    return { status: 'error', message: err.message };
  } finally {
    lock.releaseLock();
  }
}

// ==========================================
// 3. ฟังก์ชันดึงข้อมูลตอนโหลดหน้าเว็บ
// ==========================================
function getInitialData(token) {
  // 🔒 ต้อง login ก่อนถึงจะดึงข้อมูลได้
  try { requireAuth_(token); } catch (authErr) { throw new Error('AUTH_REQUIRED'); }
  try {
    // 🟢 แก้ไข: ใช้ openById ล็อคไฟล์ฐานข้อมูลโดยตรง ป้องกันปัญหาหาไฟล์ไม่เจอ
    var ss = getDb_();

    var users = getSheetData(ss, 'Users');

    // Migration: ensure all users have accessCategory field
    var usersMigrated = false;
    for (var i = 0; i < users.length; i++) {
      if (users[i].accessCategory === undefined || users[i].accessCategory === null || users[i].accessCategory === '') {
        users[i].accessCategory = 'All';
        usersMigrated = true;
      }
      if (upgradeUserSecret_(users[i])) usersMigrated = true; // plaintext -> hash (ครั้งเดียว)
    }
    if (ensureIds_(users)) usersMigrated = true; // backfill _id ครั้งเดียว
    if (ensureDefaultAdmin_(users)) usersMigrated = true;
    if (usersMigrated) {
      writeSheetData(ss, 'Users', users);
    }

    var parts = getSheetData(ss, 'Parts');

    // Migration: ensure all parts have required fields
    var partsMigrated = false;
    for (var j = 0; j < parts.length; j++) {
      var p = parts[j];
      var changed = false;

      if (!p.category || p.category === '') { p.category = 'Splicing'; changed = true; }
      if (!p.group || p.group === '') { p.group = 'General'; changed = true; }
      if (!p.location || p.location === '') { p.location = 'Central Store'; changed = true; }
      if (p.supplier === undefined || p.supplier === null) { p.supplier = ''; changed = true; }
      if (p.min === undefined || p.min === null || p.min === '') { p.min = 0; changed = true; }
      if (p.qty === undefined || p.qty === null || p.qty === '') { p.qty = 0; changed = true; }

      // Recalculate status
      var qty = Number(p.qty) || 0;
      var min = Number(p.min) || 0;
      var expectedStatus = qty === 0 ? 'Out of Stock' : (qty <= min ? 'Low Stock' : 'In Stock');
      if (!p.status || p.status !== expectedStatus) { p.status = expectedStatus; changed = true; }

      if (changed) { partsMigrated = true; }
    }
    if (ensureIds_(parts)) partsMigrated = true;
    if (partsMigrated) {
      writeSheetData(ss, 'Parts', parts);
    }

    var requests = getSheetData(ss, 'Requests');
    if (ensureIds_(requests)) writeSheetData(ss, 'Requests', requests);

    var po = getSheetData(ss, 'PO');
    if (ensureIds_(po)) writeSheetData(ss, 'PO', po);

    // 🟢 แก้ไข: แปลงประวัติการเบิกให้เป็นตัวเลขเสมอ ป้องกันการบวกเลขในกราฟผิดพลาด
    var historyWD = getSheetData(ss, 'HistoryWD');
    for (var k = 0; k < historyWD.length; k++) {
      if (historyWD[k].qty !== undefined) {
        historyWD[k].qty = Number(historyWD[k].qty);
      }
    }
    if (ensureIds_(historyWD)) writeSheetData(ss, 'HistoryWD', historyWD);

    var historyED = getSheetData(ss, 'HistoryED');
    if (ensureIds_(historyED)) writeSheetData(ss, 'HistoryED', historyED);

    var supportTickets = getSheetData(ss, 'SupportTickets');
    if (ensureIds_(supportTickets)) writeSheetData(ss, 'SupportTickets', supportTickets);

    return {
      users: sanitizeUsers_(users), // 🔒 ไม่ส่ง password/hash/salt ออกไป
      parts: parts,
      requests: requests,
      po: po,
      historyWD: historyWD,
      historyED: historyED,
      supportTickets: supportTickets
    };
  } catch (e) {
    // 🟢 ถ้าพัง จะส่ง Error กลับไปบอกหน้าเว็บตรงๆ
    throw new Error("Server Error (getInitialData): " + e.message);
  }
}


// ==========================================
// 4. ฟังก์ชันบันทึกข้อมูลกลับลง Google Sheets
// ==========================================
// ⚠️ เขียนทับทั้งฐานข้อมูล — ใช้เฉพาะตอน Reset เท่านั้น (ไม่ใช้ในการบันทึกปกติแล้ว)
//     การบันทึกปกติย้ายไปใช้ applyDelta() ซึ่งบันทึกเฉพาะแถวที่เปลี่ยน + กันชนด้วย LockService
function saveDataToServer(token, stateString) {
  try { requireAdmin_(token); } catch (authErr) { return { status: "error", message: authErr.message }; }
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000); // กันการเขียนชนกันระหว่างผู้ใช้หลายคน
  } catch (e) {
    return { status: "error", message: "Server busy, please retry" };
  }
  try {
    if (!stateString) {
      throw new Error('Empty state received');
    }

    var state;
    try {
      state = JSON.parse(stateString);
    } catch (e) {
      throw new Error('Invalid JSON format: ' + e.message);
    }

    var ss = getDb_();

    // บันทึกข้อมูลแต่ละ sheet
    var sheetsSaved = [];
    if (state.users !== undefined) { hashUsersInPlace_(state.users); writeSheetData(ss, 'Users', state.users); sheetsSaved.push('Users'); }
    if (state.parts !== undefined) { writeSheetData(ss, 'Parts', state.parts); sheetsSaved.push('Parts'); }
    if (state.requests !== undefined) { writeSheetData(ss, 'Requests', state.requests); sheetsSaved.push('Requests'); }
    if (state.po !== undefined) { writeSheetData(ss, 'PO', state.po); sheetsSaved.push('PO'); }
    if (state.historyWD !== undefined) { writeSheetData(ss, 'HistoryWD', state.historyWD); sheetsSaved.push('HistoryWD'); }
    if (state.historyED !== undefined) { writeSheetData(ss, 'HistoryED', state.historyED); sheetsSaved.push('HistoryED'); }
    if (state.supportTickets !== undefined) { writeSheetData(ss, 'SupportTickets', state.supportTickets); sheetsSaved.push('SupportTickets'); }

    Logger.log('Data saved successfully: ' + sheetsSaved.join(', '));
    return { status: "success", savedSheets: sheetsSaved };

  } catch (error) {
    Logger.log('Error saving data: ' + error.message);
    return { status: "error", message: error.message };
  } finally {
    lock.releaseLock();
  }
}

// ==========================================
// 4.1 บันทึกแบบ Delta (merge ราย-แถว) — หัวใจของการกัน data loss ตอนใช้งานหลายคน
//     client ส่งมาเฉพาะแถวที่ "เพิ่ม/แก้" (upserts) และ id ที่ "ลบ" (deletes)
//     server จะอ่านข้อมูลล่าสุดมา merge ทับเฉพาะแถวนั้น ไม่แตะแถวของคนอื่น
// ==========================================
function applyDelta(token, deltaString) {
  // 🔒 ต้องมี session ที่ถูกต้องเท่านั้นถึงจะเขียนได้
  try { requireAuth_(token); } catch (authErr) { return { status: "error", message: authErr.message }; }
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
  } catch (e) {
    return { status: "error", message: "Server busy, please retry" };
  }
  try {
    if (!deltaString) {
      throw new Error('Empty delta received');
    }

    var delta;
    try {
      delta = JSON.parse(deltaString);
    } catch (e) {
      throw new Error('Invalid JSON format: ' + e.message);
    }

    var ss = getDb_();
    var applied = [];

    for (var key in delta) {
      // 🔒 ห้ามแก้ตาราง Users ผ่าน applyDelta (ต้องใช้ adminSaveUser/changeOwnPassword)
      if (key === 'users') { Logger.log('applyDelta: blocked users delta'); continue; }
      var sheetName = SHEET_MAP[key];
      if (!sheetName) continue;

      var change = delta[key];

      // 1) อ่านข้อมูลล่าสุดจาก Sheet (source of truth) แล้ว index ด้วย _id
      var fresh = getSheetData(ss, sheetName);
      var byId = {};
      var order = [];
      for (var i = 0; i < fresh.length; i++) {
        var fid = fresh[i]._id;
        if (fid === undefined || fid === null || fid === '') {
          fid = 'legacy_' + i;
          fresh[i]._id = fid;
        }
        byId[fid] = fresh[i];
        order.push(fid);
      }

      // 2) ลบแถวตาม id ที่ client แจ้ง
      if (change.deletes && change.deletes.length) {
        for (var d = 0; d < change.deletes.length; d++) {
          delete byId[change.deletes[d]];
        }
      }

      // 3) เพิ่ม/แก้ (upsert) เฉพาะแถวที่ client ส่งมา
      if (change.upserts && change.upserts.length) {
        for (var u = 0; u < change.upserts.length; u++) {
          var row = change.upserts[u];
          if (row._id === undefined || row._id === null || row._id === '') {
            row._id = Utilities.getUuid();
          }
          if (byId[row._id] === undefined) {
            order.push(row._id); // แถวใหม่ — ต่อท้าย
          }
          byId[row._id] = row; // ทับของเดิม หรือเพิ่มใหม่
        }
      }

      // 4) ประกอบกลับตามลำดับเดิม แล้วเขียนทับทั้ง Sheet (ภายใต้ lock)
      var result = [];
      for (var o = 0; o < order.length; o++) {
        if (byId[order[o]] !== undefined) result.push(byId[order[o]]);
      }
      writeSheetData(ss, sheetName, result);
      applied.push(sheetName);
    }

    Logger.log('Delta applied: ' + applied.join(', '));
    return { status: "success", applied: applied };

  } catch (error) {
    Logger.log('applyDelta error: ' + error.message);
    return { status: "error", message: error.message };
  } finally {
    lock.releaseLock();
  }
}

// ==========================================
// 5. ฟังก์ชันช่วยอ่านข้อมูลจาก Sheet
// ==========================================
function getSheetData(ss, sheetName) {
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    Logger.log('Warning: Sheet "' + sheetName + '" not found');
    return [];
  }

  var dataRef = sheet.getDataRange();
  if(!dataRef) return [];
  var data = dataRef.getValues();
  if (!data || data.length <= 1) return [];

  var headers = data[0];
  var result = [];
  var scriptTimeZone = Session.getScriptTimeZone();

  for (var i = 1; i < data.length; i++) {
    var row = data[i];
    var obj = {};
    for (var j = 0; j < headers.length; j++) {
      var cellVal = row[j];
      if (cellVal instanceof Date) {
        var isoDate = Utilities.formatDate(cellVal, scriptTimeZone, "yyyy-MM-dd'T'HH:mm:ss");
        obj[headers[j]] = isoDate + 'Z';
      } else if (cellVal === '' || cellVal === null || cellVal === undefined) {
        obj[headers[j]] = '';
      } else if (typeof cellVal === 'string' && (cellVal.charAt(0) === '{' || cellVal.charAt(0) === '[')) {
        // 🟢 แก้ไข: field ที่เก็บเป็น JSON (เช่น details ของ Request) ต้อง parse กลับเป็น object
        try {
          obj[headers[j]] = JSON.parse(cellVal);
        } catch (parseErr) {
          obj[headers[j]] = cellVal; // ถ้าไม่ใช่ JSON จริง เก็บเป็น string ตามเดิม
        }
      } else {
        obj[headers[j]] = cellVal;
      }
    }
    result.push(obj);
  }
  return result;
}

// ==========================================
// 6. ฟังก์ชันช่วยเขียนข้อมูลลง Sheet
// ==========================================
function writeSheetData(ss, sheetName, dataArray) {
  try {
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      Logger.log('Error: Sheet "' + sheetName + '" not found');
      throw new Error('Sheet "' + sheetName + '" not found');
    }

    if (!dataArray) {
      Logger.log('Warning: dataArray is null for sheet ' + sheetName);
      return;
    }

    if (dataArray.length === 0) {
      if (sheet.getLastRow() > 1) {
        sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).clearContent();
      }
      Logger.log('Sheet "' + sheetName + '" cleared (empty data)');
      return;
    }
  
  var headers = [];
  if (sheet.getLastRow() === 0) {
    headers = Object.keys(dataArray[0]);
    sheet.appendRow(headers);
  } else {
    headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    
    var newKeys = [];
    var sampleObj = dataArray[0] || {};
    for (var k in sampleObj) {
      if (headers.indexOf(k) === -1) {
        newKeys.push(k);
      }
    }
    if (newKeys.length > 0) {
      headers = headers.concat(newKeys);
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    }
  }
  
  if (sheet.getLastRow() > 1) {
    var numColsToClear = Math.max(sheet.getLastColumn(), headers.length);
    sheet.getRange(2, 1, sheet.getLastRow() - 1, numColsToClear).clearContent();
  }
  
  var outputData = [];
  for (var i = 0; i < dataArray.length; i++) {
    var row = [];
    var obj = dataArray[i];
    for (var j = 0; j < headers.length; j++) {
      var val = obj[headers[j]];
      if (typeof val === 'object' && val !== null) {
        val = JSON.stringify(val);
      } else if (typeof val === 'string' && val.trim() !== "") {
        if (!isNaN(Number(val)) || val.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/)) {
          val = "'" + val;
        }
      }
      row.push(val !== undefined ? val : "");
    }
    outputData.push(row);
  }
  if (outputData.length > 0) {
    sheet.getRange(2, 1, outputData.length, headers.length).setValues(outputData);
  }
  Logger.log('Sheet "' + sheetName + '" updated with ' + outputData.length + ' rows');
  } catch (error) {
    Logger.log('Error in writeSheetData (' + sheetName + '): ' + error.message);
    throw error;
  }
}

// ==========================================
// 7. ฟังก์ชันอัปโหลดรูปภาพไปเก็บที่ Google Drive
// ==========================================
function uploadImageToDrive(base64Data, fileName) {
  try {
    var folderName = "Inventory_Images";
    var folders = DriveApp.getFoldersByName(folderName);
    var folder;
    
    if (folders.hasNext()) {
      folder = folders.next();
    } else {
      folder = DriveApp.createFolder(folderName);
      folder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    }
    
    var splitBase = base64Data.split(',');
    var type = splitBase[0].split(';')[0].replace('data:', '');
    var byteCharacters = Utilities.base64Decode(splitBase[1]);
    var blob = Utilities.newBlob(byteCharacters, type, fileName);
    
    var file = folder.createFile(blob);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    
    var fileId = file.getId();
    return "https://drive.google.com/thumbnail?id=" + fileId + "&sz=w800";
    
  } catch (e) {
    return "ERROR: " + e.message;
  }
}

// ==========================================
// 8. ฟังก์ชันสำหรับกด "เรียกใช้ (Run)" เพื่อขออนุญาตเข้าถึง Google Drive แบบเต็ม
// ==========================================
function forceAuthorize() {
  var folderName = "Inventory_Images";
  var folders = DriveApp.getFoldersByName(folderName);
  var folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(folderName);
  var file = folder.createFile("test.txt", "OK");
  file.setTrashed(true);
}

// ==========================================
// 9. ระบบแจ้งเตือนผ่าน Email (Real-time Notifications)
// ==========================================

// Public wrapper — ต้อง login ก่อน (กันคนนอกยิงสแปมอีเมล)
function sendEmailNotification(token, type, payload) {
  try { requireAuth_(token); } catch (e) { return { status: 'error', message: e.message }; }
  return sendEmailNotificationInternal_(type, payload);
}

function sendEmailNotificationInternal_(type, payload) {
  try {
    var ss = getDb_();
    var users = getSheetData(ss, 'Users');

    var adminManagerEmails = users.filter(function(u) {
      return (u.role === 'Admin' || u.role === 'Manager') &&
             u.status === 'Active' && u.email && u.email.trim() !== '';
    }).map(function(u) { return u.email.trim(); });

    var adminOnlyEmails = users.filter(function(u) {
      return u.role === 'Admin' && u.status === 'Active' &&
             u.email && u.email.trim() !== '';
    }).map(function(u) { return u.email.trim(); });

    var allActiveUsers = users.filter(function(u) {
      return u.status === 'Active' && u.email && u.email.trim() !== '';
    });

    function getEmailByEn(en) {
      for (var i = 0; i < allActiveUsers.length; i++) {
        if (String(allActiveUsers[i].en) === String(en)) {
          return allActiveUsers[i].email.trim();
        }
      }
      return null;
    }

    var subject, htmlBody, toEmails;

    switch (type) {
      case 'NEW_REQUEST':
        toEmails = adminManagerEmails;
        subject = '[Inventory] New Withdrawal Request: ' + payload.part_name;
        htmlBody = emailNewRequest(payload);
        break;
      case 'REQUEST_APPROVED':
        var e1 = getEmailByEn(payload.en);
        toEmails = e1 ? [e1] : adminManagerEmails;
        subject = '[Inventory] Withdrawal Request Approved: ' + payload.part_name;
        htmlBody = emailRequestApproved(payload);
        break;
      case 'REQUEST_REJECTED':
        var e2 = getEmailByEn(payload.en);
        toEmails = e2 ? [e2] : adminManagerEmails;
        subject = '[Inventory] Withdrawal Request Rejected: ' + payload.part_name;
        htmlBody = emailRequestRejected(payload);
        break;
      case 'TECH_CONFIRMED':
        toEmails = adminManagerEmails;
        subject = '[Inventory] Tech Confirmed Receipt: ' + payload.part_name;
        htmlBody = emailTechConfirmed(payload);
        break;
      case 'LOW_STOCK':
        toEmails = adminManagerEmails;
        subject = '[Inventory] ⚠️ Low Stock: ' + payload.part_name;
        htmlBody = emailLowStock(payload);
        break;
      case 'OUT_OF_STOCK':
        toEmails = adminManagerEmails;
        subject = '[Inventory] 🚨 Out of Stock: ' + payload.part_name;
        htmlBody = emailOutOfStock(payload);
        break;
      case 'SUPPORT_TICKET':
        toEmails = adminOnlyEmails.length > 0 ? adminOnlyEmails : adminManagerEmails;
        subject = '[Inventory] New Support Ticket: ' + payload.topic;
        htmlBody = emailSupportTicket(payload);
        break;
      case 'PASSWORD_RESET':
        toEmails = adminOnlyEmails.length > 0 ? adminOnlyEmails : adminManagerEmails;
        subject = '[Inventory] Password Reset Request: ' + payload.username;
        htmlBody = emailPasswordReset(payload);
        break;
      default:
        Logger.log('Unknown notification type: ' + type);
        return { status: 'error', message: 'Unknown type' };
    }

    if (!toEmails || toEmails.length === 0) {
      Logger.log('No recipients for [' + type + ']');
      return { status: 'skipped', message: 'No recipients' };
    }

    MailApp.sendEmail({ to: toEmails.join(','), subject: subject, htmlBody: htmlBody });
    Logger.log('Email sent [' + type + '] → ' + toEmails.join(', '));
    return { status: 'sent', count: toEmails.length };

  } catch (e) {
    Logger.log('Email error [' + type + ']: ' + e.message);
    return { status: 'error', message: e.message };
  }
}

// ─── Email Layout Helper ───────────────────────────────────────────────────

function emailWrap(accentColor, badgeText, icon, title, bodyHTML) {
  return '<!DOCTYPE html><html><body style="margin:0;padding:0;background:#f1f5f9;font-family:Arial,sans-serif;">' +
    '<table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:32px 16px;">' +
    '<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">' +

    // Header
    '<tr><td style="background:' + accentColor + ';padding:28px 32px;">' +
    '<div style="color:#fff;font-size:12px;font-weight:600;letter-spacing:1.2px;text-transform:uppercase;opacity:0.8;margin-bottom:6px;">Spare Part Inventory System</div>' +
    '<div style="color:#fff;font-size:22px;font-weight:700;">' + icon + '  ' + title + '</div>' +
    '</td></tr>' +

    // Badge
    '<tr><td style="padding:0 32px;"><span style="display:inline-block;background:' + accentColor + '22;color:' + accentColor + ';font-size:11px;font-weight:700;padding:5px 14px;border-radius:0 0 10px 10px;letter-spacing:0.5px;">' + badgeText + '</span></td></tr>' +

    // Body
    '<tr><td style="padding:24px 32px 32px;">' + bodyHTML + '</td></tr>' +

    // Footer
    '<tr><td style="background:#f8fafc;padding:18px 32px;border-top:1px solid #e2e8f0;">' +
    '<div style="color:#94a3b8;font-size:11px;text-align:center;">This email was sent automatically by the system &bull; Please do not reply</div>' +
    '</td></tr>' +

    '</table></td></tr></table></body></html>';
}

function emailRows(rows) {
  var cells = rows.map(function(r) {
    return '<tr>' +
      '<td style="padding:9px 16px;color:#64748b;font-size:13px;width:150px;white-space:nowrap;border-bottom:1px solid #f1f5f9;">' + r[0] + '</td>' +
      '<td style="padding:9px 16px;color:#0f172a;font-size:13px;font-weight:' + (r[2] ? '700' : '500') + ';border-bottom:1px solid #f1f5f9;">' + r[1] + '</td>' +
      '</tr>';
  }).join('');
  return '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:10px;overflow:hidden;margin:20px 0;">' + cells + '</table>';
}

function emailAlert(color, text) {
  return '<div style="background:' + color + '18;border-left:4px solid ' + color + ';border-radius:8px;padding:13px 18px;margin:20px 0;color:' + color + ';font-size:13px;font-weight:600;">' + text + '</div>';
}

function nowTH() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'dd/MM/yyyy HH:mm:ss');
}

// ─── Individual Email Builders ────────────────────────────────────────────

function emailNewRequest(p) {
  var body = '<p style="color:#334155;font-size:14px;margin:0 0 4px;">A new spare part withdrawal request is awaiting approval.</p>' +
    emailRows([
      ['Part', p.part_name, true],
      ['Part No.', p.part_no || '-', false],
      ['Quantity', p.qty + ' pcs', true],
      ['Requester', p.requester + '  (' + p.en + ')', false],
      ['Station', p.station || '-', false],
      ['Reason', p.reason || '-', false],
      ['Time', nowTH(), false]
    ]) +
    emailAlert('#6366f1', 'Please log in to Approve or Reject this request.');
  return emailWrap('#6366f1', 'WITHDRAWAL REQUEST', '📋', 'New Withdrawal Request', body);
}

function emailRequestApproved(p) {
  var body = '<p style="color:#334155;font-size:14px;margin:0 0 4px;">Your withdrawal request has been <strong>approved</strong>.</p>' +
    emailRows([
      ['Part', p.part_name, true],
      ['Quantity', p.qty + ' pcs', true],
      ['Requester', p.requester + '  (' + p.en + ')', false],
      ['Approved By', p.actionBy, false],
      ['Time', nowTH(), false]
    ]) +
    emailAlert('#10b981', 'You may collect the spare part at the stock room.');
  return emailWrap('#10b981', 'APPROVED', '✅', 'Withdrawal Request Approved', body);
}

function emailRequestRejected(p) {
  var body = '<p style="color:#334155;font-size:14px;margin:0 0 4px;">Your withdrawal request has been <strong>rejected</strong>.</p>' +
    emailRows([
      ['Part', p.part_name, true],
      ['Quantity', p.qty + ' pcs', false],
      ['Requester', p.requester + '  (' + p.en + ')', false],
      ['Rejected By', p.actionBy, false],
      ['Reason', p.reason || '-', true],
      ['Time', nowTH(), false]
    ]) +
    emailAlert('#ef4444', 'Please contact your Supervisor or Admin for more information.');
  return emailWrap('#ef4444', 'REJECTED', '❌', 'Withdrawal Request Rejected', body);
}

function emailTechConfirmed(p) {
  var body = '<p style="color:#334155;font-size:14px;margin:0 0 4px;">A technician has confirmed receipt of the spare part.</p>' +
    emailRows([
      ['Part', p.part_name, true],
      ['Part No.', p.part_no || '-', false],
      ['Actual Qty Received', p.qty + ' ' + p.unit, true],
      ['Received By', p.confirmedBy + '  (' + p.en + ')', false],
      ['Processed By', p.actionBy || '-', false],
      ['Time', nowTH(), false]
    ]);
  return emailWrap('#0ea5e9', 'TECH CONFIRMED', '🔧', 'Tech Confirmed Receipt', body);
}

function emailLowStock(p) {
  var body = '<p style="color:#334155;font-size:14px;margin:0 0 4px;">This spare part has dropped below its Minimum Level.</p>' +
    emailRows([
      ['Part', p.part_name, true],
      ['Part No.', p.part_no || '-', false],
      ['Remaining', p.qty + ' pcs', true],
      ['Minimum Level', p.min + ' pcs', false]
    ]) +
    emailAlert('#f59e0b', 'Please reorder soon to avoid an unexpected stockout.');
  return emailWrap('#f59e0b', 'LOW STOCK ALERT', '⚠️', 'Low Stock', body);
}

function emailOutOfStock(p) {
  var body = '<p style="color:#334155;font-size:14px;margin:0 0 4px;">This spare part is <strong>out of stock</strong> and requires urgent action!</p>' +
    emailRows([
      ['Part', p.part_name, true],
      ['Part No.', p.part_no || '-', false],
      ['Remaining', '0 pcs', true],
      ['Minimum Level', p.min + ' pcs', false]
    ]) +
    emailAlert('#ef4444', 'Please reorder urgently! This part cannot be withdrawn until stock is received.');
  return emailWrap('#ef4444', 'OUT OF STOCK', '🚨', 'Out of Stock — Reorder Urgently', body);
}

function emailSupportTicket(p) {
  var body = '<p style="color:#334155;font-size:14px;margin:0 0 4px;">A new support ticket is awaiting action.</p>' +
    emailRows([
      ['Reported By', p.user, true],
      ['Topic', p.topic, true],
      ['Details', p.desc, false],
      ['Time', nowTH(), false]
    ]) +
    emailAlert('#6366f1', 'Please log in → Support Req. to take action.');
  return emailWrap('#6366f1', 'SUPPORT TICKET', '🎫', 'New Support Ticket', body);
}

function emailPasswordReset(p) {
  var body = '<p style="color:#334155;font-size:14px;margin:0 0 4px;">A user has requested a password reset.</p>' +
    emailRows([
      ['Username', p.username, true],
      ['Reason', 'Entered wrong password more than 3 times', false],
      ['Time', nowTH(), false]
    ]) +
    emailAlert('#f59e0b', 'Please log in → User Management to reset the password for this user.');
  return emailWrap('#f59e0b', 'PASSWORD RESET', '🔑', 'Password Reset Request', body);
}