# OE Center — Loop Pivot Report

> **Automation Tool for Serial Number Loop Analysis**  
> Google Apps Script Web Application · Celestica CTH

---

## 📋 ภาพรวมโปรเจค

**OE Center - Loop Pivot Report** เป็นเว็บแอปพลิเคชันที่พัฒนาด้วย Google Apps Script (GAS)  
สำหรับ **นำข้อมูล Raw Data มา Pivot เป็นรายงานแนวนอนตาม Loop number** ของ Serial Number (S/N)  
ช่วยลดเวลาการวิเคราะห์ข้อมูล OE (Operations Engineering) และลด Human Error ในการจัดเรียงข้อมูลด้วยมือ

---

## 🗂️ โครงสร้างไฟล์

```
OE Center/
├── code.gs          — Backend: Google Apps Script (Logic หลัก + Export)
├── Index.html       — Frontend: HTML + JavaScript (UI + State Management)
├── Css.html         — Stylesheet: CSS ทั้งหมดของแอป
└── README.md        — เอกสารโปรเจคนี้
```

---

## ✨ Features

### Step 1 — Import Raw Data
| วิธีนำเข้าข้อมูล | รายละเอียด |
|---|---|
| **Upload CSV** | อ่านไฟล์ `.csv` (รองรับ UTF-8 BOM จาก Excel) |
| **Upload XLSX** | Parse ไฟล์ `.xlsx` / `.xls` บน Server-side ด้วย `Utilities.unzip()` + `XmlService` ไม่ต้องพึ่ง API ภายนอก |
| **Fetch from Sheet** | ดึงข้อมูลจาก Google Sheet ที่กำหนดใน `CONFIG.SPREADSHEET_ID` โดยตรง |

### Step 2 — Select Pivot Fields
- **Require Loop** *(Multi-select)* — S/N ต้องมี Loop ที่เลือกครบ (ถ้าไม่ครบจะถูก Drop ออกจากรายงาน)
  - `No Requirement` = ไม่บังคับ
  - `All Loops` = ต้องมีครบทุก Loop ที่ปรากฏในข้อมูล
  - เลือกเจาะจง = ต้องมี Loop ที่ติ๊กไว้ครบทุกตัว
- **Current Operation** *(Multi-select)* — กรองแถวตาม Operation ที่เลือก (default = `End`)
  - ไม่ติ๊กใดเลย / `All Operations` = เอาทุกแถว
- **Show Loop** *(Multi-select)* — เลือกว่าจะแสดงคอลัมน์ Loop ไหนบ้างในรายงาน
  - `All Loops` = แสดงทุก Loop
  - เลือกเจาะจง = แสดงเฉพาะ Loop ที่เลือก
- **Pivot Fields** — เลือก Field ที่ต้องการ Pivot (ค่า default = `DEFECT_DESC`, `RD`)

### Step 3 — Run Report
- คลิก **▶ Run Report** เพื่อประมวลผล
- คลิก **⬆ Export to Sheet** เพื่อส่งออกเป็น Google Sheet ใหม่ใน Drive
- คลิก **⬇ Download CSV** เพื่อดาวน์โหลดเป็นไฟล์ CSV (UTF-8 BOM, Excel-compatible)

### Step 4 — Result Table
- ตารางแบบ 2-row header (Loop N / Field Name)
- Search S/N แบบ Real-time
- Stats bar แสดงสถิติการกรองทุกขั้นตอน

---

## ⚙️ กฎการประมวลผล (5 Rules)

```
Rule 1 │ กรองแถวตาม Current Operation (exact match, case-insensitive)
Rule 2 │ จัดกลุ่มแถวตาม Serial Number (S/N)
Rule 3 │ คัด S/N ที่ไม่มี Loop ที่กำหนดออก (ถ้าเปิด Require Loop)
Rule 4 │ หา Max Loop เพื่อสร้าง Dynamic Header
Rule 5 │ Pivot ข้อมูลออกแนวนอนตาม Loop number
```

**หากมีหลาย record ใน Loop เดียวกันของ S/N เดียวกัน → เขียนทับด้วย record ล่าสุด**

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────┐
│              Browser (GAS HtmlService)       │
│                                              │
│  Index.html  ──── state{} ────  UI render    │
│      │                              │        │
│      └──── google.script.run ───────┘        │
└─────────────────┬───────────────────────────┘
                  │ RPC (JSON serialized)
┌─────────────────▼───────────────────────────┐
│              Google Apps Script              │
│                                              │
│  doGet()            → serve HTML             │
│  inspectCsvHeaders()  → parse headers only   │
│  inspectXlsxHeaders() → parse headers only   │
│  inspectSheetHeaders()→ read sheet headers   │
│  processUploadedCsv() → full pipeline        │
│  processUploadedXlsx()→ full pipeline        │
│  fetchFromSheet()     → full pipeline        │
│  exportToReportSheet()→ write to Drive       │
│                                              │
│  processRawData()   ← Core Engine (Rule 1-5) │
└──────────────────────────────────────────────┘
```

---

## 🔧 การตั้งค่า (CONFIG)

แก้ไขค่าใน `code.gs` บรรทัด 20–43:

```javascript
const CONFIG = {
  SPREADSHEET_ID:    '...',         // Google Sheet ต้นทาง
  RAW_SHEET_NAME:    'Raw Data',    // ชื่อ sheet ต้นทาง
  REPORT_SHEET_NAME: 'Report',      // ชื่อ sheet ปลายทาง
  REPORT_FOLDER_ID:  '...',         // Google Drive Folder ID สำหรับ Export
  REPORT_FILE_PREFIX:'OE_Loop_Report_',
  COL_SERIAL:   'Serial Number',    // ชื่อคอลัมน์ S/N
  COL_OPERATION:'Current Operation',// ชื่อคอลัมน์ Operation
  COL_LOOP:     'Loop',             // ชื่อคอลัมน์ Loop
  DEFAULT_PIVOT_FIELDS: ['DEFECT_DESC', 'RD'], // Fields ที่ default ถูกเลือก
  FILTER_KEYWORD: 'End'             // Operation default
};
```

---

## 📊 รูปแบบ Raw Data ที่รองรับ

| คอลัมน์ (ต้องมี) | ตัวอย่างค่า | หมายเหตุ |
|---|---|---|
| `Serial Number` | `SN-001` | Grouping key |
| `Current Operation` | `End`, `Start`, `Repair` | Filter key |
| `Loop` | `1`, `2`, `Loop 3` | ตัวเลขหรือ "Loop N" |
| `DEFECT_DESC` | `Scratch` | Pivot field (default) |
| `RD` | `RD-01` | Pivot field (default) |
| คอลัมน์อื่น ๆ | — | เลือก Pivot ได้ใน UI |

> คอลัมน์ `Loop` รองรับหลายรูปแบบ: `1`, `"1"`, `"Loop 1"`, `"loop1"`, `"Step 2 Loop 1"` → ระบบเอาตัวเลขสุดท้ายเสมอ

---

## 📤 รูปแบบผลลัพธ์ (Pivot Output)

```
S/N      │ Loop 1              │ Loop 2              │ Loop 3 ...
         │ DEFECT_DESC │ RD   │ DEFECT_DESC │ RD   │ ...
─────────┼─────────────┼──────┼─────────────┼──────┼────
SN-001   │ Scratch     │ RD01 │             │      │ ...
SN-002   │             │      │ Crack       │ RD02 │ ...
```

---

## 📈 Stats Bar

| ค่า | ความหมาย |
|---|---|
| **Raw Rows** | จำนวนแถวทั้งหมดใน Raw Data |
| **After Filter** | แถวที่เหลือหลังกรอง Operation |
| **Total S/N** | S/N ไม่ซ้ำทั้งหมดหลังจัดกลุ่ม |
| **Dropped** | S/N ที่ถูกตัดออกเพราะ Require Loop ไม่ครบ |
| **Valid S/N** | S/N ที่ผ่านทุกเงื่อนไข (ออกรายงาน) |
| **Max Loop** | หมายเลข Loop สูงสุดที่พบในข้อมูล |

---

## 🚀 การ Deploy

1. เปิด [Google Apps Script](https://script.google.com) → สร้าง Project ใหม่
2. Copy `code.gs`, `Index.html`, `Css.html` ใส่ใน Project
3. แก้ไข `CONFIG` ใน `code.gs` ให้ตรงกับ Spreadsheet และ Drive ของคุณ
4. **Deploy → New deployment → Web app**
   - Execute as: **Me**
   - Who has access: **Anyone within [Organization]** หรือ **Anyone**
5. Copy URL ไปใช้งาน

---

## 🔄 Changelog

### v1.1.2 (2026-05-26)
- 🐛 QA ตรวจสอบ Logic การกรองแบบ Multi-select ทุกส่วน
- ✅ ยืนยัน Array handling ใน `processRawData` ทำงานถูกต้อง

### v1.1.0 – v1.1.1
- ✨ เพิ่ม Multi-select Checkbox Dropdown สำหรับ 3 ส่วน:
  - **Require Loop** — เลือกได้หลาย Loop ที่ S/N ต้องมีครบ
  - **Current Operation** — เลือกได้หลาย Operation เพื่อกรอง
  - **Show Loop** — เลือกได้หลาย Loop ที่ต้องการแสดงผล
- ✨ Backend (`code.gs`) รองรับ Array parameter สำหรับ filter ทุกตัว
- 🎨 Custom dropdown UI พร้อม animation และ outside-click-to-close

### v1.0.0
- 🚀 Release แรก
- ✨ Import CSV / XLSX / Google Sheet
- ✨ Pivot ตาม Loop number แบบ Dynamic Header
- ✨ Export to Google Sheet + Download CSV
- ✨ Search S/N real-time
- ✨ Stats bar

---

## 👤 ผู้พัฒนา

**Pantawat Tantem**  
Celestica CTH · OE Center · 2026
