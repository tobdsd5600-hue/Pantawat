/**
 * ============================================================
 *  OE Center - Loop Pivot Report (Backend)
 *  Google Apps Script (code.gs)
 * ============================================================
 *  หน้าที่หลัก:
 *  1) เสิร์ฟหน้าเว็บ (doGet)
 *  2) รับข้อมูล Raw Data (CSV upload / Google Sheet)
 *  3) ประมวลผลตามกฎ 5 ข้อ:
 *     - กรอง Current Operation ตามค่าที่ผู้ใช้เลือก (exact match)
 *     - จัดกลุ่มตาม Serial Number (S/N)
 *     - คัด S/N ที่ไม่มี Loop ที่กำหนด (เฉพาะเมื่อผู้ใช้เลือก Require Loop)
 *     - Pivot fields ที่ผู้ใช้เลือกออกแนวนอนตามหมายเลข Loop (เจาะจง Loop หรือทุก Loop)
 *     - สร้าง Dynamic Header ตาม field และ Loop ที่แสดง
 *  4) Export ผลลัพธ์ลง Sheet "Report"
 * ============================================================
 */

// ===== CONFIG =====
const CONFIG = {
  // ใส่ Spreadsheet ID ของคุณที่นี่ (ใช้สำหรับ "ดึงข้อมูลจาก Sheet")
  SPREADSHEET_ID: '1n8MFB_Zo_BnM0HR7ycWHIAX3k-RuNfiwv-HGl4YP6_k',
  RAW_SHEET_NAME: 'Raw Data',
  REPORT_SHEET_NAME: 'Report',

  // โฟลเดอร์ปลายทางสำหรับ Export Report เป็นไฟล์ใหม่ (Option C)
  // ดึง ID จาก URL: drive.google.com/drive/folders/<FOLDER_ID>
  REPORT_FOLDER_ID: '1-uoxPBAoB1pdKQ6MQ5AOolTGy9Fzug8z',

  // prefix ของชื่อไฟล์ Report ที่สร้างใหม่ (จะตามด้วย timestamp)
  REPORT_FILE_PREFIX: 'OE_Loop_Report_',

  // คอลัมน์ "หลัก" ที่ระบบใช้ในการจัดกลุ่ม/กรอง (จำเป็นต้องมี)
  COL_SERIAL: 'Serial Number',
  COL_OPERATION: 'Current Operation',
  COL_LOOP: 'Loop',

  // Pivot fields ค่า default — ถ้าผู้ใช้ไม่เลือกอะไรจาก UI จะใช้รายการนี้
  DEFAULT_PIVOT_FIELDS: ['DEFECT_DESC', 'RD'],

  // คำที่ใช้กรอง Current Operation (exact match, case-insensitive)
  FILTER_KEYWORD: 'End'
};

// ============================================================
//  Web App Entry Point
// ============================================================
function doGet(e) {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('OE Center - Loop Pivot Report')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// ============================================================
//  Data Sources
// ============================================================

/**
 * อ่านข้อมูล Raw Data จาก Google Sheet ต้นทาง
 * @param {Array<string>} [pivotFields]
 * @param {string} [filterOp]    - ค่า Current Operation ที่จะกรอง (ถ้าไม่ส่ง = CONFIG.FILTER_KEYWORD)
 * @param {string} [loopFilter]  - Loop ที่จะแสดง (ถ้าไม่ส่ง/ว่าง = ทุก Loop)
 * @param {string} [requireLoop] - Loop ที่ S/N ต้องมี (ถ้าไม่ส่ง/ว่าง = ไม่บังคับ)
 */
function fetchFromSheet(pivotFields, filterOp, loopFilter, requireLoop) {
  try {
    const values = readSheetValues();
    return processRawData(values, pivotFields, filterOp, loopFilter, requireLoop);
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

/**
 * รับ CSV content (string) จากฝั่ง client แล้ว parse + ประมวลผล
 * @param {string} csvText
 * @param {Array<string>} [pivotFields]
 * @param {string} [filterOp]
 * @param {string} [loopFilter]
 * @param {string} [requireLoop]
 */
function processUploadedCsv(csvText, pivotFields, filterOp, loopFilter, requireLoop) {
  try {
    if (!csvText || !csvText.trim()) {
      throw new Error('File is empty or could not be read');
    }
    // ตัด UTF-8 BOM (﻿) ที่ Excel/Windows ใส่มาให้ — ถ้าไม่ตัด header ตัวแรกจะมี BOM นำหน้า ทำให้ findColumnIndex พัง
    const cleanCsv = csvText.replace(/^\uFEFF/, '');
    const parsed = Utilities.parseCsv(cleanCsv);
    if (parsed.length < 2) throw new Error('CSV file contains no data');

    return processRawData(parsed, pivotFields, filterOp, loopFilter, requireLoop);
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

// ===== Header Inspection (สำหรับให้ UI โชว์ checkbox เลือก field + dropdown filter) =====

/**
 * ดึงค่า Current Operation ที่ไม่ซ้ำกัน (สำหรับให้ UI ทำ dropdown filter)
 * @param {Array<Array<any>>} values - แถวแรกคือ header
 * @returns {Array<string>} รายการค่าที่ไม่ซ้ำ เรียงตามตัวอักษร
 */
function extractOperations(values) {
  if (!values || values.length < 2) return [];
  const header = values[0].map(h => String(h).trim());
  const idxOp = findColumnIndex(header, CONFIG.COL_OPERATION);
  if (idxOp < 0) return [];
  const seen = {};
  const ops = [];
  for (let i = 1; i < values.length; i++) {
    const v = cleanCell(values[i][idxOp]);
    if (!v) continue;
    const key = v.toLowerCase();
    if (!seen[key]) {
      seen[key] = true;
      ops.push(v);
    }
  }
  ops.sort();
  return ops;
}

/**
 * ดึงค่า Loop ที่ไม่ซ้ำกัน (สำหรับ dropdown filter Loop)
 * @param {Array<Array<any>>} values - แถวแรกคือ header
 * @returns {Array<number>} รายการ Loop เรียงจากน้อยไปมาก
 */
function extractLoops(values) {
  if (!values || values.length < 2) return [];
  const header = values[0].map(h => String(h).trim());
  const idxLoop = findColumnIndex(header, CONFIG.COL_LOOP);
  if (idxLoop < 0) return [];
  const seen = {};
  const loops = [];
  for (let i = 1; i < values.length; i++) {
    const n = parseLoopNumber(values[i][idxLoop]);
    if (n !== null && !seen[n]) {
      seen[n] = true;
      loops.push(n);
    }
  }
  loops.sort(function(a, b) { return a - b; });
  return loops;
}

/**
 * อ่าน header row + ค่า Current Operation + ค่า Loop จาก Google Sheet ต้นทาง
 */
function inspectSheetHeaders() {
  try {
    const values = readSheetValues();
    return {
      ok: true,
      headers: values[0].map(String),
      operations: extractOperations(values),
      loops: extractLoops(values)
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

/**
 * อ่าน header row + ค่า Current Operation + ค่า Loop จากไฟล์ xlsx (base64)
 */
function inspectXlsxHeaders(base64Data, filename) {
  try {
    if (!base64Data) throw new Error('No file data received');
    const rows = parseXlsxToRows(base64Data, filename);
    if (!rows || rows.length === 0) throw new Error('File contains no data');
    return {
      ok: true,
      headers: rows[0].map(String),
      operations: extractOperations(rows),
      loops: extractLoops(rows)
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

/**
 * อ่าน header row + ค่า Current Operation + ค่า Loop จาก CSV content
 */
function inspectCsvHeaders(csvText) {
  try {
    if (!csvText || !csvText.trim()) throw new Error('File is empty or could not be read');
    const cleanCsv = csvText.replace(/^\uFEFF/, '');
    const parsed = Utilities.parseCsv(cleanCsv);
    if (parsed.length < 1) throw new Error('CSV file contains no data');
    return {
      ok: true,
      headers: parsed[0].map(String),
      operations: extractOperations(parsed),
      loops: extractLoops(parsed)
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

// helper
function readSheetValues() {
  const ss = CONFIG.SPREADSHEET_ID
    ? SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID)
    : SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Spreadsheet not found — please set SPREADSHEET_ID in CONFIG');
  const sheet = ss.getSheetByName(CONFIG.RAW_SHEET_NAME);
  if (!sheet) throw new Error('Sheet named "' + CONFIG.RAW_SHEET_NAME + '" not found');
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) throw new Error('No data found in the Raw Data sheet');
  return values;
}

/**
 * รับไฟล์ XLSX (base64) แล้ว parse เอง ในตัว Apps Script
 *   - ใช้ Utilities.unzip() แตก zip (.xlsx เป็น zip ของ XML)
 *   - ใช้ XmlService parse XML
 *   - ไม่ต้องเรียก Google Drive API / GCP API ใดๆ
 *
 * @param {string} base64Data
 * @param {string} filename
 * @param {Array<string>} [pivotFields]
 * @param {string} [filterOp]
 * @param {string} [loopFilter]
 * @param {string} [requireLoop]
 */
function processUploadedXlsx(base64Data, filename, pivotFields, filterOp, loopFilter, requireLoop) {
  try {
    if (!base64Data) throw new Error('No file data received');
    const rows = parseXlsxToRows(base64Data, filename);
    if (!rows || rows.length < 2) throw new Error('File contains no data');
    return processRawData(rows, pivotFields, filterOp, loopFilter, requireLoop);
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

/**
 * Parse xlsx (base64) → 2D array
 * รองรับ: shared strings, inline strings, ตัวเลข, การ pad คอลัมน์ว่าง
 * @param {number} [maxRows] ถ้าระบุ จะหยุดหลังได้ครบ N แถว (ใช้ตอน inspect headers)
 */
function parseXlsxToRows(base64Data, filename, maxRows) {
  const bytes = Utilities.base64Decode(base64Data);
  const zipBlob = Utilities.newBlob(bytes, 'application/zip', filename || 'upload.xlsx');

  let parts;
  try {
    parts = Utilities.unzip(zipBlob);
  } catch (e) {
    throw new Error('Failed to unzip — this may not be a valid .xlsx file: ' + e.message);
  }

  // สร้าง map ของไฟล์ใน zip
  const fileMap = {};
  parts.forEach(function(p) { fileMap[p.getName()] = p; });

  // 1) อ่าน sharedStrings (ถ้ามี)
  const sharedStrings = [];
  if (fileMap['xl/sharedStrings.xml']) {
    const ssXml = XmlService.parse(fileMap['xl/sharedStrings.xml'].getDataAsString());
    const root = ssXml.getRootElement();
    const ns = root.getNamespace();
    const sis = root.getChildren('si', ns);
    sis.forEach(function(si) {
      // <si><t>text</t></si>  หรือ  <si><r><t>...</t></r><r><t>...</t></r></si> (rich text)
      const tDirect = si.getChild('t', ns);
      if (tDirect) {
        sharedStrings.push(tDirect.getText());
      } else {
        const rs = si.getChildren('r', ns);
        let text = '';
        rs.forEach(function(r) {
          const t = r.getChild('t', ns);
          if (t) text += t.getText();
        });
        sharedStrings.push(text);
      }
    });
  }

  // 2) หา worksheet แรก (สำหรับ xlsx ทั่วไป = xl/worksheets/sheet1.xml)
  let sheetPart = fileMap['xl/worksheets/sheet1.xml'];
  if (!sheetPart) {
    // หา sheet ตัวแรกแบบ generic — เผื่อโครงสร้างแปลก
    const sheetKey = Object.keys(fileMap).filter(function(k) {
      return /^xl\/worksheets\/sheet\d+\.xml$/i.test(k);
    }).sort()[0];
    if (sheetKey) sheetPart = fileMap[sheetKey];
  }
  if (!sheetPart) throw new Error('No worksheet found in the xlsx file');

  // 3) parse sheet XML
  const sDoc = XmlService.parse(sheetPart.getDataAsString());
  const sRoot = sDoc.getRootElement();
  const sNs = sRoot.getNamespace();
  const sheetData = sRoot.getChild('sheetData', sNs);
  if (!sheetData) throw new Error('sheetData element not found in the worksheet');

  const rowEls = sheetData.getChildren('row', sNs);
  const limitedRows = maxRows ? rowEls.slice(0, maxRows) : rowEls;

  const out = [];
  let maxCols = 0;
  let prevRowIdx = 0;

  limitedRows.forEach(function(rowEl) {
    // pad rows ที่หายไป (sparse rows)
    const rAttr = rowEl.getAttribute('r');
    const rowIdx = rAttr ? parseInt(rAttr.getValue(), 10) : (prevRowIdx + 1);
    while (out.length < rowIdx - 1) out.push([]);
    prevRowIdx = rowIdx;

    const cellEls = rowEl.getChildren('c', sNs);
    const rowData = [];

    cellEls.forEach(function(cellEl) {
      const refAttr = cellEl.getAttribute('r');
      const ref = refAttr ? refAttr.getValue() : '';
      const colLetters = ref.replace(/\d+/g, '');
      const colIdx = colLetters ? colLetterToIndex(colLetters) : rowData.length;

      const typeAttr = cellEl.getAttribute('t');
      const type = typeAttr ? typeAttr.getValue() : '';
      const vEl = cellEl.getChild('v', sNs);
      const isEl = cellEl.getChild('is', sNs);

      let value = '';
      if (type === 's' && vEl) {
        const idx = parseInt(vEl.getText(), 10);
        value = (idx >= 0 && idx < sharedStrings.length) ? sharedStrings[idx] : '';
      } else if (type === 'inlineStr' && isEl) {
        const t = isEl.getChild('t', sNs);
        if (t) value = t.getText();
      } else if (type === 'b' && vEl) {
        value = vEl.getText() === '1' ? 'TRUE' : 'FALSE';
      } else if (vEl) {
        // number, date (serial), หรือ string ที่เก็บตรงๆ
        value = vEl.getText();
      }

      // pad ช่องว่างก่อนถึง colIdx
      while (rowData.length < colIdx) rowData.push('');
      rowData.push(value);
    });

    if (rowData.length > maxCols) maxCols = rowData.length;
    out.push(rowData);
  });

  // normalize ความยาวทุกแถวให้เท่ากัน
  out.forEach(function(r) {
    while (r.length < maxCols) r.push('');
  });

  // ตัดแถวว่างท้ายไฟล์
  while (out.length && out[out.length - 1].every(function(c) { return c === ''; })) {
    out.pop();
  }

  return out;
}

/**
 * แปลง column letters → 0-indexed: "A"→0, "B"→1, "Z"→25, "AA"→26, ...
 */
function colLetterToIndex(letters) {
  let n = 0;
  const s = String(letters).toUpperCase();
  for (let i = 0; i < s.length; i++) {
    n = n * 26 + (s.charCodeAt(i) - 64);
  }
  return n - 1;
}

// ============================================================
//  Core Logic - Pivot Engine
// ============================================================

/**
 * ประมวลผล Raw Data (2D Array) ตามกฎ 5 ข้อ — รองรับ pivot fields แบบยืดหยุ่น
 * @param {Array<Array<any>>} values     - แถวแรกคือ header
 * @param {Array<string>} [pivotFields]  - field ที่ผู้ใช้เลือก (ถ้าไม่ส่ง = default)
 * @param {string} [filterOp]            - ค่า Current Operation ที่จะกรอง: '__ALL_OP__'=ไม่กรอง, ค่าอื่น=กรองตรงตัว (ว่าง=CONFIG.FILTER_KEYWORD)
 * @param {string} [loopFilter]          - Loop ที่จะแสดงในรายงาน (ถ้าไม่ส่ง/ว่าง = แสดงทุก Loop)
 * @param {string} [requireLoop]         - Loop ที่ S/N ต้องมี: ''=ไม่บังคับ, 'ALL'=ต้องมีครบทุก Loop, ตัวเลข=ต้องมี Loop นั้น
 */
function processRawData(values, pivotFields, filterOp, loopFilter, requireLoop) {
  const header = values[0].map(h => String(h).trim());
  const rows = values.slice(1);

  // resolve pivot fields
  const fields = (pivotFields && pivotFields.length)
    ? pivotFields.slice()
    : CONFIG.DEFAULT_PIVOT_FIELDS.slice();
  const numFields = fields.length;
  if (numFields === 0) throw new Error('Please select at least one pivot field');

  // หา index ของคอลัมน์หลัก
  const idxSN = findColumnIndex(header, CONFIG.COL_SERIAL);
  const idxOp = findColumnIndex(header, CONFIG.COL_OPERATION);
  const idxLoop = findColumnIndex(header, CONFIG.COL_LOOP);

  const missing = [];
  if (idxSN < 0) missing.push(CONFIG.COL_SERIAL);
  if (idxOp < 0) missing.push(CONFIG.COL_OPERATION);
  if (idxLoop < 0) missing.push(CONFIG.COL_LOOP);

  // หา index ของ pivot fields (แต่ละตัว)
  const fieldIndices = fields.map(f => findColumnIndex(header, f));
  fields.forEach((f, i) => {
    if (fieldIndices[i] < 0) missing.push(f);
  });

  if (missing.length) {
    throw new Error('Column(s) not found: ' + missing.join(', '));
  }

  // ค่า Current Operation ที่จะกรอง (รองรับ Array หลายค่า)
  //   '__ALL_OP__' หรือ [] → ไม่กรอง (เอาทุก Operation)
  //   ['End','Start']      → กรองเฉพาะที่ตรงกับค่าใดค่าหนึ่งใน Array
  const opRaw = (filterOp !== null && filterOp !== undefined) ? filterOp : '';
  let opAll, opFilters;
  if (opRaw === '__ALL_OP__' || opRaw === '' ||
      (Array.isArray(opRaw) && opRaw.length === 0)) {
    opAll = true; opFilters = [];
  } else if (Array.isArray(opRaw)) {
    opFilters = opRaw.map(o => String(o).trim().toLowerCase()).filter(o => o.length > 0);
    opAll = opFilters.length === 0;
  } else {
    const s = String(opRaw).trim();
    opAll = (s === '__ALL_OP__' || s === '');
    opFilters = opAll ? [] : [s.toLowerCase()];
  }
  const opFilter = opAll ? 'ALL' : (Array.isArray(filterOp) ? filterOp.join(', ') : String(filterOp));

  // Loop ที่จะแสดงในรายงาน — null = ทุก Loop, Array = เจาะจง Loops ที่เลือก
  let loopSel;
  if (!loopFilter || loopFilter === '' ||
      (Array.isArray(loopFilter) && loopFilter.length === 0)) {
    loopSel = null;
  } else if (Array.isArray(loopFilter)) {
    const parsed = loopFilter.map(l => parseLoopNumber(l)).filter(l => l !== null);
    loopSel = parsed.length > 0 ? parsed : null;
  } else {
    const n = parseLoopNumber(loopFilter);
    loopSel = n !== null ? [n] : null;
  }

  // Loop ที่ S/N ต้องมี (Rule 3) — รองรับ Array หลาย Loop
  //   []    → ไม่บังคับ (ไม่ตัด S/N)
  //   'ALL' → S/N ต้องมีครบทุก Loop ที่ปรากฏในข้อมูล
  //   [1,3] → S/N ต้องมี Loop 1 และ Loop 3 ครบ
  const reqRaw = (requireLoop !== null && requireLoop !== undefined) ? requireLoop : '';
  let reqAll, reqLoops;
  if (reqRaw === '' || (Array.isArray(reqRaw) && reqRaw.length === 0)) {
    reqAll = false; reqLoops = null;
  } else if (reqRaw === 'ALL' || (!Array.isArray(reqRaw) && String(reqRaw).trim().toUpperCase() === 'ALL')) {
    reqAll = true; reqLoops = null;
  } else if (Array.isArray(reqRaw)) {
    const parsed = reqRaw.map(l => parseLoopNumber(l)).filter(l => l !== null);
    reqAll = false; reqLoops = parsed.length > 0 ? parsed : null;
  } else {
    const n = parseLoopNumber(String(reqRaw).trim());
    reqAll = false; reqLoops = n !== null ? [n] : null;
  }

  const stats = {
    totalRows: rows.length,
    afterEndFilter: 0,
    totalSN: 0,
    droppedNoLoop1: 0,
    finalSN: 0,
    maxLoop: 0,
    fields: fields,
    filterOp: opFilter,
    opAll: opAll,
    loopFilter: loopSel,
    requireLoop: reqLoops,
    requireAll: reqAll
  };

  // ---- Rule 1: กรองแถวตาม Current Operation ----
  //   opAll → ไม่กรอง เอาทุกแถว
  //   อื่นๆ → เก็บเฉพาะแถวที่ตรงกับค่าที่เลือก (exact match, case-insensitive, trim)
  let filtered;
  if (opAll) {
    filtered = rows;
  } else {
    filtered = rows.filter(r => {
      const op = String(r[idxOp] || '').trim().toLowerCase();
      return opFilters.indexOf(op) !== -1;
    });
  }
  stats.afterEndFilter = filtered.length;

  // ---- Rule 2: จัดกลุ่มตาม S/N ----
  // groups[sn] = [ { loop, values: [v1, v2, ...] }, ... ]
  const groups = {};
  filtered.forEach(r => {
    const sn = String(r[idxSN] || '').trim();
    if (!sn) return;
    const loopVal = parseLoopNumber(r[idxLoop]);
    if (loopVal === null) return;

    const rec = { loop: loopVal, values: fieldIndices.map(idx => cleanCell(r[idx])) };
    if (!groups[sn]) groups[sn] = [];
    groups[sn].push(rec);
  });
  stats.totalSN = Object.keys(groups).length;

  // ---- Rule 3: คัด S/N ตามเงื่อนไข Require Loop ----
  //   reqAll        → S/N ต้องมีครบทุก Loop ที่ปรากฏในข้อมูล
  //   reqLoop ตัวเลข → S/N ต้องมี Loop นั้น
  //   ไม่บังคับ      → เก็บทุก S/N
  // distinct Loop ที่มีในข้อมูล (หลัง op filter) — ใช้ตอน reqAll
  const allLoopNums = [];
  if (reqAll) {
    const seenLoop = {};
    Object.keys(groups).forEach(sn => {
      groups[sn].forEach(rec => {
        if (!seenLoop[rec.loop]) { seenLoop[rec.loop] = true; allLoopNums.push(rec.loop); }
      });
    });
  }

  const validGroups = {};
  Object.keys(groups).forEach(sn => {
    const records = groups[sn];
    let keep;
    if (reqAll) {
      keep = allLoopNums.every(function(ln) {
        return records.some(function(rec) { return rec.loop === ln; });
      });
    } else if (reqLoops && reqLoops.length > 0) {
      // S/N ต้องมีครบทุก Loop ที่ระบุใน reqLoops
      keep = reqLoops.every(function(rl) {
        return records.some(function(rec) { return rec.loop === rl; });
      });
    } else {
      keep = true;
    }
    if (keep) {
      validGroups[sn] = records;
    } else {
      stats.droppedNoLoop1++;
    }
  });
  stats.finalSN = Object.keys(validGroups).length;

  // ---- Rule 4: หา Max Loop เพื่อสร้าง Dynamic Header ----
  let maxLoop = 0;
  Object.keys(validGroups).forEach(sn => {
    validGroups[sn].forEach(rec => {
      if (rec.loop > maxLoop) maxLoop = rec.loop;
    });
  });
  stats.maxLoop = maxLoop;

  // ---- Rule 5: Pivot ข้อมูลออกแนวนอน ----
  // loopsToShow = รายการ Loop ที่จะ pivot เป็นคอลัมน์
  //   - เลือก Loop เจาะจง → [loopSel] (คอลัมน์เดียว)
  //   - ทุก Loop → [1, 2, ..., maxLoop]
  // headerTop/headerSub ใช้สำหรับ render ตาราง HTML (2 แถว + colspan)
  let loopsToShow;
  if (loopSel !== null && loopSel.length > 0) {
    loopsToShow = loopSel.slice().sort(function(a, b) { return a - b; });
  } else {
    loopsToShow = [];
    for (let i = 1; i <= maxLoop; i++) loopsToShow.push(i);
  }

  const headerTop = ['S/N'];
  const headerSub = [''];
  loopsToShow.forEach(function(loopNum) {
    for (let j = 0; j < numFields; j++) {
      headerTop.push('Loop ' + loopNum);
      headerSub.push(fields[j]);
    }
  });

  // สร้าง body — ถ้ามีหลาย record ใน Loop เดียวกัน เขียนทับด้วยตัวล่าสุด
  const sortedSN = Object.keys(validGroups).sort();
  const body = sortedSN.map(sn => {
    const row = new Array(1 + loopsToShow.length * numFields).fill('');
    row[0] = sn;
    validGroups[sn].forEach(rec => {
      const loopPos = loopsToShow.indexOf(rec.loop);
      if (loopPos < 0) return;   // Loop นี้ไม่ได้อยู่ในรายการที่แสดง — ข้าม
      const baseCol = 1 + loopPos * numFields;
      for (let j = 0; j < numFields; j++) {
        row[baseCol + j] = rec.values[j];
      }
    });
    return row;
  });

  return {
    ok: true,
    headerTop: headerTop,
    headerSub: headerSub,
    body: body,
    stats: stats,
    fieldsPerLoop: numFields,   // ให้ frontend ใช้ render colSpan
    fields: fields,
    loops: loopsToShow          // รายการ Loop ที่ pivot ออกมา (ให้ frontend/export ใช้)
  };
}

// ============================================================
//  Export to Sheet
// ============================================================

/**
 * Export ผลลัพธ์เป็นไฟล์ Google Sheet ใหม่ในโฟลเดอร์ที่กำหนด (Option C)
 *   - สร้าง Spreadsheet ใหม่ ตั้งชื่อ "OE_Loop_Report_YYYY-MM-DD_HHmm"
 *   - ย้ายไฟล์เข้าโฟลเดอร์ REPORT_FOLDER_ID
 *   - เขียน Header 2 แถว (Row1: Loop N merged | Row2: FIELD-N) + Body + format
 *   - โครงสร้างสะท้อนตาม filter ที่เลือก (loops มาจาก loopFilter, fields มาจาก pivotFields)
 * @param {Object} report - { body, fields, fieldsPerLoop, stats, loops }
 */
function exportToReportSheet(report) {
  try {
    if (!report || !report.body || !report.fields || !report.stats || !report.loops) {
      throw new Error('No data to export, or the report object is incomplete');
    }
    if (!CONFIG.REPORT_FOLDER_ID) {
      throw new Error('REPORT_FOLDER_ID is not set in CONFIG');
    }

    // 1) ตรวจสอบโฟลเดอร์ปลายทาง
    let folder;
    try {
      folder = DriveApp.getFolderById(CONFIG.REPORT_FOLDER_ID);
    } catch (e) {
      throw new Error('Destination folder not found or no access permission (FOLDER_ID: ' + CONFIG.REPORT_FOLDER_ID + ')');
    }

    // 2) สร้าง Spreadsheet ใหม่ (จะอยู่ใน My Drive ก่อน แล้วค่อยย้าย)
    const tz = Session.getScriptTimeZone() || 'Asia/Bangkok';
    const stamp = Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd_HHmm');
    const fileName = CONFIG.REPORT_FILE_PREFIX + stamp;

    const ss = SpreadsheetApp.create(fileName);
    const fileId = ss.getId();

    // 3) ย้ายไฟล์เข้าโฟลเดอร์ (moveTo)
    const file = DriveApp.getFileById(fileId);
    file.moveTo(folder);

    // 4) เขียนข้อมูลและ format
    const sheet = ss.getSheets()[0];
    sheet.setName(CONFIG.REPORT_SHEET_NAME);

    const body = report.body;
    const fields = report.fields;
    const loops = report.loops;
    const nf = report.fieldsPerLoop || fields.length || 1;
    const numCols = 1 + loops.length * nf;

    // Row 1 (top): S/N | Loop N | Loop N | ... (ตามรายการ loops)
    const headerTop = ['S/N'];
    // Row 2 (sub): ''  | DEFECT_DESC-N | RD-N | ...
    const headerSub = [''];
    loops.forEach(function(loopNum) {
      for (let j = 0; j < nf; j++) {
        headerTop.push('Loop ' + loopNum);
        headerSub.push((fields[j] || ('Field' + (j + 1))) + '-' + loopNum);
      }
    });

    sheet.getRange(1, 1, 1, numCols).setValues([headerTop]);
    sheet.getRange(2, 1, 1, numCols).setValues([headerSub]);

    // merge S/N ข้ามสองแถว
    sheet.getRange(1, 1, 2, 1).merge()
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle');

    // merge หัว Loop แต่ละกลุ่ม (nf คอลัมน์) — ข้าม merge ถ้า nf=1 เพราะ Sheets ไม่อนุญาต merge 1 cell
    if (nf > 1) {
      for (let i = 0; i < loops.length; i++) {
        sheet.getRange(1, 2 + i * nf, 1, nf)
          .merge()
          .setHorizontalAlignment('center');
      }
    }

    // เขียน body เริ่มแถว 3
    // normalize ทุก row ให้มีความยาว = numCols เพื่อป้องกัน Google Sheets API throw
    if (body.length > 0) {
      const normalizedBody = body.map(function(r) {
        const row = r.slice(0, numCols);
        while (row.length < numCols) row.push('');
        return row;
      });
      sheet.getRange(3, 1, normalizedBody.length, numCols).setValues(normalizedBody);
    }

    // format header 2 แถว
    sheet.getRange(1, 1, 2, numCols)
      .setFontWeight('bold')
      .setBackground('#1f4e78')
      .setFontColor('#ffffff')
      .setHorizontalAlignment('center')
      .setVerticalAlignment('middle');

    sheet.setFrozenRows(2);
    sheet.setFrozenColumns(1);
    sheet.autoResizeColumns(1, numCols);

    return {
      ok: true,
      url: ss.getUrl(),
      fileName: fileName,
      folderUrl: folder.getUrl(),
      rowCount: body.length
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

// ============================================================
//  Helpers
// ============================================================

function findColumnIndex(header, name) {
  const target = String(name).toLowerCase().replace(/[\s_]+/g, '');
  // Pass 1: exact match (normalize whitespace + underscore)
  for (let i = 0; i < header.length; i++) {
    const h = String(header[i]).toLowerCase().replace(/[\s_]+/g, '');
    if (h === target) return i;
  }
  // Pass 2: contains match — เฉพาะ target ยาว >= 4 ตัวอักษร
  // กันกรณี 'rd' ไป match 'rd_type' หรือ 'standard' โดยไม่ตั้งใจ
  if (target.length >= 4) {
    for (let i = 0; i < header.length; i++) {
      const h = String(header[i]).toLowerCase().replace(/[\s_]+/g, '');
      if (h.includes(target)) return i;
    }
  }
  return -1;
}

/**
 * แปลงค่า Loop ให้เป็นจำนวนเต็มบวก
 * รองรับรูปแบบ: 1, "1", "Loop 1", "loop1"
 * - ใช้ตัวเลขสุดท้ายในสตริง เพื่อกัน "Step 2 Loop 1" → 1 (ไม่ใช่ 2)
 * - reject 0 และลบ เพราะจะทำให้ baseCol เป็นลบ ทับ array ผิดตำแหน่ง
 */
function parseLoopNumber(val) {
  if (val === null || val === undefined || val === '') return null;
  if (typeof val === 'number') {
    const n = Math.floor(val);
    return n > 0 ? n : null;
  }
  const s = String(val).trim();
  // ลองแปลงเป็นตัวเลขก่อน — รองรับ "1", "1.0", "2.5" → floor → 1, 1, 2
  const asNum = Number(s);
  if (!isNaN(asNum)) {
    const n = Math.floor(asNum);
    return n > 0 ? n : null;
  }
  // สตริงที่มีคำนำหน้า เช่น "Loop 12", "loop1", "Step 2 Loop 1", "Loop 1 Rev"
  // → เก็บตัวเลขทั้งหมดในสตริง แล้วเอาตัวสุดท้าย
  // ใช้ match(/\d+/g) แทน /(\d+)\s*$/ เพื่อรองรับตัวอักษรต่อท้ายตัวเลข เช่น "Loop 1 Final"
  const allNums = s.match(/\d+/g);
  if (!allNums) return null;
  const n = parseInt(allNums[allNums.length - 1], 10);
  return (!isNaN(n) && n > 0) ? n : null;
}

function cleanCell(v) {
  if (v === null || v === undefined) return '';
  return String(v).trim();
}
